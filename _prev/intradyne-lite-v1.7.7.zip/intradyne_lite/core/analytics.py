
from __future__ import annotations
from typing import Dict, Any, List, Tuple, Optional
import sqlite3, datetime as dt, os, math

def _connect(cfg: dict):
    db = ((cfg.get("storage") or {}).get("sqlite_path")) or "/app/data/trades.sqlite"
    os.makedirs(os.path.dirname(db), exist_ok=True)
    con = sqlite3.connect(db)
    return con

def trades_recent(cfg: dict, limit: int = 100) -> List[Dict[str, Any]]:
    con = _connect(cfg); cur = con.cursor()
    try:
        cur.execute("CREATE TABLE IF NOT EXISTS trades (ts TEXT, account TEXT, symbol TEXT, side TEXT, qty REAL, price REAL, pnl REAL)")
        cur.execute("SELECT ts, account, symbol, side, qty, price, pnl FROM trades ORDER BY ts DESC LIMIT ?", (int(limit),))
        rows = cur.fetchall()
        return [ {"ts":r[0],"account":r[1],"symbol":r[2],"side":r[3],"qty":float(r[4]),"price":float(r[5]),"pnl":float(r[6])} for r in rows ]
    finally:
        con.close()

def daily_pnl_series(cfg: dict, days: int = 90) -> List[Tuple[str,float]]:
    con = _connect(cfg); cur = con.cursor()
    try:
        cur.execute("CREATE TABLE IF NOT EXISTS trades (ts TEXT, account TEXT, symbol TEXT, side TEXT, qty REAL, price REAL, pnl REAL)")
        since = (dt.datetime.utcnow().date() - dt.timedelta(days=int(days))).isoformat()
        cur.execute("SELECT substr(ts,1,10) d, COALESCE(SUM(pnl),0) FROM trades WHERE substr(ts,1,10) >= ? GROUP BY d ORDER BY d ASC", (since,))
        return [(r[0], float(r[1])) for r in cur.fetchall()]
    finally:
        con.close()

def summary(cfg: dict, start_capital: Optional[float] = None, days: int = 90) -> Dict[str, Any]:
    dps = daily_pnl_series(cfg, days)
    cap = start_capital or float((cfg.get("risk") or {}).get("capital") or 10000.0)
    eq = cap
    eq_curve = []
    wins = losses = 0
    total_pnl = 0.0
    for d, pnl in dps:
        eq += pnl
        eq_curve.append((d, eq))
        total_pnl += pnl
        if pnl > 0: wins += 1
        elif pnl < 0: losses += 1
    # metrics
    ret = (eq - cap)/cap if cap else 0.0
    winrate = wins / max((wins+losses),1)
    # drawdown
    peak = -1e18
    max_dd = 0.0
    for _, v in eq_curve:
        if v > peak: peak = v
        if peak>0:
            dd = (peak - v)/peak
            if dd > max_dd: max_dd = dd
    return {"start_capital": cap, "equity": eq, "return_pct": ret, "wins": wins, "losses": losses, "winrate": winrate, "max_drawdown_pct": max_dd, "period_days": days, "total_pnl": total_pnl, "points": len(eq_curve)}
