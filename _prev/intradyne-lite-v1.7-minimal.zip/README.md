
# IntraDyne Lite v1.7 (Research Features)

Endpoints:
- POST /shariah/check?symbol=
- POST /sentiment/set?symbol=&score=
- GET  /sentiment/get?symbol=
- POST /strategy/toggle (JSON body with toggles)
- GET  /signals/preview?symbol=&timeframe=1h&ma_n=50
- GET  /strategy/suggest_qty?symbol=&risk_pct=0.01

Notes:
- This is a minimal skeleton to demonstrate research features. Integrate order routes and DB to enforce daily max loss and Shariah checks pre-trade.
