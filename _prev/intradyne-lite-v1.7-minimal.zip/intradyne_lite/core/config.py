
import os, yaml
def load_config(path: str | None = None):
    p = path or os.getenv("CONFIG","config.yaml")
    if os.path.exists(p):
        with open(p,"r") as f:
            return yaml.safe_load(f) or {}
    return {}
