
from fastapi import APIRouter, UploadFile, File, Depends, HTTPException
from sqlalchemy.orm import Session
from pathlib import Path
import csv, io, math
from ..db import get_db, Base, engine
from ..models import Order
from ..services.shariah import screen_symbol
from ..services.risk import pretrade_ok
from ..services.broker import make_adapter

router = APIRouter(prefix="/ai", tags=["ai"])
Base.metadata.create_all(bind=engine)

DATA_DIR = Path(__file__).resolve().parents[1] / "data" / "history"
DATA_DIR.mkdir(parents=True, exist_ok=True)

def _read_history(symbol: str):
    path = DATA_DIR / f"{symbol.upper()}.csv"
    if not path.exists():
        raise FileNotFoundError("No history for symbol")
    rows = []
    with open(path, "r", encoding="utf-8") as f:
        r = csv.DictReader(f)
        for row in r:
            if "date" in row and "close" in row:
                try:
                    c = float(row["close"])
                    rows.append({"date": row["date"], "close": c})
                except:
                    continue
    if not rows:
        raise ValueError("Empty or invalid history")
    return rows

def _ema(series, span):
    alpha = 2 / (span + 1)
    ema_vals = []
    prev = None
    for v in series:
        prev = v if prev is None else (alpha * v + (1 - alpha) * prev)
        ema_vals.append(prev)
    return ema_vals

def _rsi(closes, period=14):
    gains, losses = [], []
    for i in range(1, len(closes)):
        delta = closes[i] - closes[i-1]
        gains.append(max(0, delta))
        losses.append(abs(min(0, delta)))
    if len(gains) < period:
        return [50.0]*len(closes)
    avg_gain = sum(gains[:period]) / period
    avg_loss = sum(losses[:period]) / period
    rsis = [50.0]*(period+1)
    for i in range(period+1, len(closes)):
        gain = gains[i-1]
        loss = losses[i-1]
        avg_gain = (avg_gain*(period-1) + gain) / period
        avg_loss = (avg_loss*(period-1) + loss) / period
        rs = (avg_gain / avg_loss) if avg_loss != 0 else float('inf')
        rsi = 100 - (100 / (1 + rs))
        rsis.append(rsi)
    # pad to length
    while len(rsis) < len(closes):
        rsis.append(rsis[-1])
    return rsis

@router.post("/history/{symbol}")
async def upload_history(symbol: str, file: UploadFile = File(...)):
    content = await file.read()
    text = content.decode("utf-8")
    # validate simple CSV
    r = csv.DictReader(io.StringIO(text))
    if "date" not in r.fieldnames or "close" not in r.fieldnames:
        raise HTTPException(status_code=400, detail="CSV must have columns: date,close")
    out = DATA_DIR / f"{symbol.upper()}.csv"
    out.write_text(text, encoding="utf-8")
    return {"ok": True, "stored": out.name}

@router.get("/signal/{symbol}")
def signal(symbol: str):
    rows = _read_history(symbol)
    closes = [row["close"] for row in rows]
    if len(closes) < 30:
        raise HTTPException(status_code=400, detail="Not enough history (need >= 30 rows)")
    ema_fast = _ema(closes, 12)
    ema_slow = _ema(closes, 26)
    rsi = _rsi(closes, 14)
    last = len(closes)-1
    decision = "hold"
    if ema_fast[last] > ema_slow[last] and rsi[last] > 50:
        decision = "buy"
    elif ema_fast[last] < ema_slow[last] and rsi[last] < 50:
        decision = "sell"
    return {
        "symbol": symbol.upper(),
        "ema_fast": ema_fast[last],
        "ema_slow": ema_slow[last],
        "rsi": rsi[last],
        "decision": decision
    }

@router.post("/autotrade/{symbol}")
def autotrade(symbol: str, qty: float = 1, db: Session = Depends(get_db)):
    # get signal
    sig = signal(symbol)
    if sig["decision"] == "hold":
        raise HTTPException(status_code=400, detail="AI decision is HOLD; no trade")
    # shariah screen
    verdict, _ = screen_symbol(symbol.upper())
    if verdict != "PASS":
        raise HTTPException(status_code=400, detail=f"Shariah screen failed for {symbol}")
    # risk check
    ok, _ = pretrade_ok(db, {"symbol": symbol.upper(), "qty": qty, "side": sig["decision"]})
    if not ok:
        raise HTTPException(status_code=400, detail="Risk check failed")
    # create filled order via paper adapter
    from ..models import Order
    order = Order(client_order_id="AI"+symbol.upper(), symbol=symbol.upper(), side=sig["decision"], qty=qty, state="submitted", broker="paper")
    db.add(order); db.commit(); db.refresh(order)
    adapter = make_adapter("paper", {})
    adapter.submit(db, order)
    db.refresh(order)
    return {"order_id": order.id, "symbol": order.symbol, "side": order.side, "qty": order.qty, "price": order.price, "state": order.state}

@router.post("/backtest")
def backtest(symbol: str, initial_cash: float = 100000.0, qty: float = 1.0, ema_fast_span: int = 12, ema_slow_span: int = 26, rsi_thr: float = 50.0):
    rows = _read_history(symbol)
    closes = [row["close"] for row in rows]
    dates = [row["date"] for row in rows]
    if len(closes) < 30:
        raise HTTPException(status_code=400, detail="Not enough history (need >= 30 rows)")
    ema_fast = _ema(closes, ema_fast_span)
    ema_slow = _ema(closes, ema_slow_span)
    rsi = _rsi(closes, 14)
    cash = initial_cash
    pos = 0.0
    equity_series = []
    wins = 0; losses = 0; trades = 0
    last_equity_peak = initial_cash
    max_drawdown = 0.0
    for i in range(len(closes)):
        price = closes[i]
        decision = "hold"
        if ema_fast[i] > ema_slow[i] and rsi[i] > rsi_thr:
            decision = "buy"
        elif ema_fast[i] < ema_slow[i] and rsi[i] < rsi_thr:
            decision = "sell"
        # trade logic: on buy -> increase position; on sell -> decrease (close if long)
        if decision == "buy":
            # buy one unit qty
            cash -= qty * price
            pos += qty
            trades += 1
        elif decision == "sell" and pos > 0:
            # close position
            pnl = (price - closes[i-1]) * pos if i>0 else 0
            wins += 1 if pnl >= 0 else 0
            losses += 1 if pnl < 0 else 0
            cash += pos * price
            pos = 0.0
            trades += 1
        equity = cash + pos * price
        last_equity_peak = max(last_equity_peak, equity)
        dd = (last_equity_peak - equity) / last_equity_peak if last_equity_peak else 0.0
        max_drawdown = max(max_drawdown, dd)
        equity_series.append({"t": dates[i], "equity": round(equity,2)})
    win_rate = (wins / trades) * 100 if trades else 0.0
    return {"metrics": {"final_equity": round(equity_series[-1]["equity"],2), "trades": trades, "win_rate": round(win_rate,2), "max_drawdown": round(max_drawdown*100,2)}, "equity": equity_series}
