
import React, { useState } from 'react'
const API = import.meta.env.VITE_API_BASE || 'http://localhost:8080'

export default function AI(){
  const [symbol, setSymbol] = useState('AAPL')
  const [qty, setQty] = useState(1)
  const [signal, setSignal] = useState(null)
  const [bt, setBt] = useState(null)
  const [file, setFile] = useState(null)
  const upload = async () => {
    if(!file) return
    const form = new FormData()
    form.append('file', file)
    const r = await fetch(`${API}/ai/history/${symbol}`, {method:'POST', body: form})
    alert(r.ok ? 'History uploaded' : 'Upload failed')
  }
  const gen = async () => {
    const r = await fetch(`${API}/ai/signal/${symbol}`)
    const j = await r.json()
    if(!r.ok){ alert(j.detail||'Error'); return }
    setSignal(j)
  }
  const trade = async () => {
    const r = await fetch(`${API}/ai/autotrade/${symbol}?qty=${qty}`, {method:'POST'})
    const j = await r.json()
    if(!r.ok){ alert(j.detail||'Error'); return }
    alert('Order placed: ' + JSON.stringify(j))
  }
  const backtest = async () => {
    const r = await fetch(`${API}/ai/backtest?symbol=${symbol}&initial_cash=100000&qty=${qty}`, {method:'POST'})
    const j = await r.json()
    if(!r.ok){ alert(j.detail||'Error'); return }
    setBt(j)
  }
  return (
    <div>
      <h3>AI Signals & Backtest</h3>
      <div style={{display:'grid', gap:8, maxWidth:520}}>
        <label>Symbol <input value={symbol} onChange={e=>setSymbol(e.target.value.toUpperCase())} /></label>
        <label>Qty <input type="number" value={qty} onChange={e=>setQty(e.target.value)} /></label>
        <label>Upload Price History (CSV: date,close)
          <input type="file" accept=".csv" onChange={e=>setFile(e.target.files[0])} />
          <button onClick={upload}>Upload</button>
        </label>
        <div style={{display:'flex', gap:8}}>
          <button onClick={gen}>Generate Signal</button>
          <button onClick={trade}>Auto-Trade</button>
          <button onClick={backtest}>Run Backtest</button>
        </div>
      </div>
      {signal && <div style={{marginTop:12}}>
        <h4>Signal</h4>
        <pre style={{background:'#f5f5f5', padding:10}}>{JSON.stringify(signal, null, 2)}</pre>
      </div>}
      {bt && <div style={{marginTop:12}}>
        <h4>Backtest Metrics</h4>
        <ul>
          <li>Final Equity: {bt.metrics.final_equity}</li>
          <li>Trades: {bt.metrics.trades}</li>
          <li>Win Rate: {bt.metrics.win_rate}%</li>
          <li>Max Drawdown: {bt.metrics.max_drawdown}%</li>
        </ul>
        <BacktestChart data={bt.equity}/>
      </div>}
    </div>
  )
}

function BacktestChart({data}){
  if(!data || data.length===0) return null
  const width=520, height=160, pad=10
  const ys = data.map(p=>p.equity)
  const minY = Math.min(...ys), maxY = Math.max(...ys)
  const toX = (i)=> pad + (i/(data.length-1||1))*(width-2*pad)
  const toY = (y)=> height - pad - ((y-minY)/(maxY-minY||1))*(height-2*pad)
  const d = data.map((p,i)=> (i===0?'M':'L')+toX(i)+','+toY(p.equity)).join(' ')
  return (<svg width={width} height={height} style={{border:'1px solid #ddd', background:'#fafafa', marginTop:8}}>
    <path d={d} fill="none" stroke="black" strokeWidth="1.5" />
  </svg>)
}
