
import React, { useState } from 'react'
const API = import.meta.env.VITE_API_BASE || 'http://localhost:8080'
export default function BlacklistTools(){
  const [file, setFile] = useState(null)
  const upload = async () => {
    if(!file) return
    const form = new FormData()
    form.append('file', file)
    const r = await fetch(`${API}/compliance/blacklist.csv`, {method:'POST', body: form})
    if(r.ok) alert('Blacklist updated')
    setFile(null)
  }
  return (<div style={{display:'flex', gap:10, alignItems:'center'}}>
    <a href={`${API}/compliance/blacklist.csv`} target="_blank">Download current blacklist</a>
    <input type="file" accept=".csv" onChange={e=>setFile(e.target.files[0])}/>
    <button onClick={upload}>Upload CSV</button>
  </div>)
}
