
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from ..db import get_db, Base, engine
from ..models import Position
from ..schemas import PortfolioOverview

router = APIRouter(prefix="/portfolio", tags=["portfolio"])
Base.metadata.create_all(bind=engine)

@router.get("/overview", response_model=PortfolioOverview)
def overview(db: Session = Depends(get_db)):
    pos = db.query(Position).all()
    positions = [{"symbol": p.symbol, "qty": p.qty, "avg_price": p.avg_price} for p in pos]
    return {"positions": positions, "pnl_unrealized": 0.0, "cash": 100000.0}
