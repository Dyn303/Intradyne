
from fastapi import APIRouter, Depends
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session
from io import StringIO
import csv
from ..db import get_db, Base, engine
from ..models import Order

router = APIRouter(prefix="/reports", tags=["reports"])
Base.metadata.create_all(bind=engine)

@router.get("/orders.csv")
def export_orders_csv(db: Session = Depends(get_db)):
    f = StringIO()
    w = csv.writer(f)
    w.writerow(["id","client_order_id","symbol","side","qty","state","price","broker","ts_created"])
    for o in db.query(Order).order_by(Order.id.asc()).all():
        w.writerow([o.id,o.client_order_id,o.symbol,o.side,o.qty,o.state,o.price,o.broker,o.ts_created])
    f.seek(0)
    return StreamingResponse(f, media_type="text/csv", headers={"Content-Disposition":"attachment; filename=orders.csv"})
