
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from ..db import get_db, Base, engine
from ..models import KVSetting
from ..services.risk import is_killswitch_on, set_killswitch

router = APIRouter(prefix="/admin", tags=["admin"])
Base.metadata.create_all(bind=engine)

@router.get("/kill-switch")
def get_kill_switch(db: Session = Depends(get_db)):
    return {"kill_switch": "on" if is_killswitch_on(db) else "off"}

@router.post("/kill-switch")
def set_kill_switch(state: str, db: Session = Depends(get_db)):
    on = state.lower() in ("on","true","1","enable","enabled")
    set_killswitch(db, on)
    return {"kill_switch": "on" if on else "off"}
