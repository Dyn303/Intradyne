
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from ..db import get_db, Base, engine
from ..models import BrokerSettings
from ..schemas import BrokerSettingsIn, BrokerSettingsOut
from ..services.crypto import enc, dec

router = APIRouter(prefix="/settings", tags=["settings"])

# ensure tables
Base.metadata.create_all(bind=engine)

def mask(s: str | None) -> str | None:
    if not s:
        return None
    return s[:4] + "****" + s[-2:] if len(s) > 6 else "****"

@router.get("/broker", response_model=BrokerSettingsOut)
def get_broker_settings(db: Session = Depends(get_db)):
    row = db.query(BrokerSettings).first()
    if not row:
        row = BrokerSettings(name="paper")
        db.add(row)
        db.commit()
        db.refresh(row)
    api_key_plain = dec(row.api_key_enc)
    return BrokerSettingsOut(
        name=row.name,
        base_url=row.base_url,
        api_key_masked=mask(api_key_plain),
        has_secret = dec(row.api_secret_enc) is not None
    )

@router.post("/broker", response_model=BrokerSettingsOut)
def upsert_broker_settings(payload: BrokerSettingsIn, db: Session = Depends(get_db)):
    row = db.query(BrokerSettings).first()
    if not row:
        row = BrokerSettings()
        db.add(row)
    row.name = payload.name
    row.base_url = payload.base_url
    if payload.api_key is not None:
        row.api_key_enc = enc(payload.api_key)
    if payload.api_secret is not None:
        row.api_secret_enc = enc(payload.api_secret)
    db.commit()
    api_key_plain = payload.api_key or dec(row.api_key_enc)
    return BrokerSettingsOut(
        name=row.name, base_url=row.base_url,
        api_key_masked=mask(api_key_plain),
        has_secret = (payload.api_secret is not None) or (row.api_secret_enc is not None)
    )


@router.get("/broker/test")
def test_broker(db: Session = Depends(get_db)):
    from ..services.broker import make_adapter
    from ..services.crypto import dec
    row = db.query(BrokerSettings).first()
    if not row:
        return {"ok": True, "mode": "paper"}
    cfg = {
        "base_url": row.base_url,
        "api_key": dec(row.api_key_enc),
        "api_secret": dec(row.api_secret_enc),
    }
    adapter = make_adapter(row.name, cfg)
    return adapter.test()
