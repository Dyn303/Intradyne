
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from ..db import get_db, Base, engine
from ..models import Order, ComplianceVerdict, BrokerSettings
from ..schemas import SignalIn, OrderOut, PortfolioOverview
from ..services.shariah import screen_symbol
from ..services.risk import pretrade_ok
from ..services.broker import make_adapter
import uuid

router = APIRouter(prefix="/trades", tags=["trades"])
Base.metadata.create_all(bind=engine)

def _client_order_id() -> str:
    return uuid.uuid4().hex[:16]

@router.post("/signal", response_model=OrderOut)
def submit_signal(sig: SignalIn, db: Session = Depends(get_db)):
    # 1) Shariah screen
    verdict, evidence = screen_symbol(sig.symbol)
    db.add(ComplianceVerdict(symbol=sig.symbol, verdict=verdict, evidence_json=str(evidence)))
    if verdict != "PASS":
        db.commit()
        raise HTTPException(status_code=400, detail=f"Shariah screen failed for {sig.symbol}")

    # 2) Risk check (simplified)
    ok, _ = pretrade_ok(db, sig.model_dump())
    if not ok:
        db.commit()
        raise HTTPException(status_code=400, detail="Risk check failed")

    # 3) Create order
    order = Order(
        client_order_id=_client_order_id(),
        symbol=sig.symbol.upper(),
        side=sig.side.lower(),
        qty=float(sig.qty),
        state="submitted",
        broker="paper"
    )
    db.add(order)
    db.commit()
    db.refresh(order)

    # 4) Execute via paper adapter
    bs = db.query(BrokerSettings).first()
    broker_name = (bs.name if bs else 'paper')
    cfg = {'base_url': bs.base_url if bs else None}
    from ..services.crypto import dec
    cfg['api_key'] = dec(bs.api_key_enc) if bs else None
    cfg['api_secret'] = dec(bs.api_secret_enc) if bs else None
    adapter = make_adapter(broker_name, cfg)
    adapter.submit(db, order)
    db.refresh(order)

    return OrderOut(
        id=order.id, client_order_id=order.client_order_id, symbol=order.symbol,
        side=order.side, qty=order.qty, state=order.state, price=order.price, broker=order.broker
    )
