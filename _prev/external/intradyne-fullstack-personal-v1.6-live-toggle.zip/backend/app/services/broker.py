
from typing import Dict, Any
from sqlalchemy.orm import Session
from ..models import Order, Position
import random, requests

class BaseAdapter:
    def __init__(self, cfg: dict):
        self.cfg = cfg
    def submit(self, db: Session, order: Order) -> Dict[str, Any]:
        raise NotImplementedError
    def test(self) -> Dict[str, Any]:
        return {"ok": False, "detail": "not_implemented"}

class PaperAdapter(BaseAdapter):
    def submit(self, db: Session, order: Order) -> Dict[str, Any]:
        px = round(100 + random.random()*5, 2)
        order.price = px
        order.state = "filled"
        pos = db.query( Position ).filter_by(symbol=order.symbol).first()
        if not pos:
            pos = Position(symbol=order.symbol, qty=0.0, avg_price=0.0)
            db.add(pos)
        if order.side == "buy":
            new_qty = pos.qty + order.qty
            pos.avg_price = (pos.avg_price*pos.qty + px*order.qty) / new_qty if new_qty else px
            pos.qty = new_qty
        else:
            pos.qty = max(0.0, pos.qty - order.qty)
        db.commit()
        return {"status": "filled", "price": px}
    def test(self) -> Dict[str, Any]:
        return {"ok": True, "mode": "paper"}

class AlpacaAdapter(BaseAdapter):
    def _headers(self):
        return {
            "APCA-API-KEY-ID": self.cfg.get("api_key",""),
            "APCA-API-SECRET-KEY": self.cfg.get("api_secret",""),
            "Content-Type": "application/json"
        }
    def test(self) -> Dict[str, Any]:
        import json
        base = (self.cfg.get("base_url") or "").rstrip('/')
        if not base:
            return {"ok": False, "error": "missing_base_url"}
        try:
            r = requests.get(f"{base}/v2/account", headers=self._headers(), timeout=10)
            return {"ok": r.status_code==200, "status": r.status_code}
        except Exception as e:
            return {"ok": False, "error": str(e)}
    def submit(self, db: Session, order: Order) -> Dict[str, Any]:
        import json
        base = (self.cfg.get("base_url") or "").rstrip('/')
        payload = {
            "symbol": order.symbol,
            "qty": order.qty,
            "side": order.side,
            "type": "market",
            "time_in_force": "day",
            "client_order_id": order.client_order_id
        }
        r = requests.post(f"{base}/v2/orders", headers=self._headers(), json=payload, timeout=10)
        if r.status_code in (200,201):
            data = r.json()
            order.state = "submitted"
            # price unknown until filled; keep as is
            db.commit()
            return {"ok": True, "status": r.status_code, "id": data.get("id")}
        else:
            return {"ok": False, "status": r.status_code, "text": r.text}

class IBKRAdapter(BaseAdapter):
    # Requires IBKR Client Portal Gateway running locally and authenticated
    def test(self) -> Dict[str, Any]:
        base = (self.cfg.get("base_url") or "").rstrip('/')
        if not base:
            return {"ok": False, "error": "missing_base_url"}
        try:
            r = requests.get(f"{base}/iserver/accounts", timeout=10)
            return {"ok": r.status_code==200, "status": r.status_code}
        except Exception as e:
            return {"ok": False, "error": str(e)}
    def submit(self, db: Session, order: Order) -> Dict[str, Any]:
        # Minimal stub: IBKR flow is complex; here we just return not implemented
        return {"ok": False, "error": "IBKR live submit not implemented in personal build"}

def make_adapter(name: str, cfg: dict) -> BaseAdapter:
    name = (name or "paper").lower()
    if name == "alpaca":
        return AlpacaAdapter(cfg)
    if name == "ibkr":
        return IBKRAdapter(cfg)
    return PaperAdapter(cfg)
