import KillSwitch from '../components/KillSwitch.jsx'
import BlacklistTools from '../components/BlacklistTools.jsx'

import React, { useEffect, useState } from 'react'
const API = import.meta.env.VITE_API_BASE || 'http://localhost:8080'

export default function Settings(){
  const [form, setForm] = useState({name:'paper', base_url:'', api_key:'', api_secret:''})
  const [saved, setSaved] = useState(false)
  const [test, setTest] = useState(null)

  useEffect(()=>{
    fetch(`${API}/settings/broker`).then(r=>r.json()).then(data=>{
      setForm(f=>({...f, name:data.name, base_url:data.base_url||''}))
    }).catch(()=>{})
  },[])

  const save = async () => {
    setSaved(false)
    const payload = {...form}
    // do not send empty secrets unless user typed them
    if(!payload.api_key) delete payload.api_key
    if(!payload.api_secret) delete payload.api_secret
    const r = await fetch(`${API}/settings/broker`, {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify(payload)
    })
    if(r.ok){
      setSaved(true)
      setForm({...form, api_key:'', api_secret:''})
    }
  }

  return (
    <div>
      <h3>Broker Settings</h3>
      <div style={{display:'grid', gap:8, maxWidth:480}}>
        <label>Broker
          <select value={form.name} onChange={e=>setForm({...form, name:e.target.value})}>
            <option value="paper">Paper (Simulated)</option>
            <option value="ibkr">Interactive Brokers (IBKR)</option>
            <option value="alpaca">Alpaca</option>
          </select>
        </label>
        <label>Base URL
          <input value={form.base_url} onChange={e=>setForm({...form, base_url:e.target.value})} placeholder="https://..." />
        </label>
        <label>API Key
          <input value={form.api_key} onChange={e=>setForm({...form, api_key:e.target.value})} placeholder="enter to update" />
        </label>
        <label>API Secret
          <input type="password" value={form.api_secret} onChange={e=>setForm({...form, api_secret:e.target.value})} placeholder="enter to update" />
        </label>
        <button onClick={save}>Save</button>
        <button onClick={async()=>{const r=await fetch(`${API}/settings/broker/test`); const j=await r.json(); setTest(j)}}>Test Connection</button>
        {saved && <div style={{color:'green'}}>Saved.</div>}
        {test && <pre style={{background:'#f5f5f5', padding:8, marginTop:8}}>Test Result: {JSON.stringify(test,null,2)}</pre>}

      <h3 style={{marginTop:20}}>Kill Switch</h3>
      <KillSwitch/>

      <h3 style={{marginTop:20}}>Compliance Blacklist</h3>
      <BlacklistTools/>
    </div>
  )
}
