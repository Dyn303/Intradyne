
import React, { useEffect, useState } from 'react'
import Dashboard from './Dashboard.jsx'
import Settings from './Settings.jsx'
import Trades from './Trades.jsx'

export default function App(){
  const [tab, setTab] = useState('dashboard')
  return (
    <div style={{fontFamily:'system-ui', padding:20}}>
      <h2>IntraDyne – Personal</h2>
      <nav style={{display:'flex', gap:10, marginBottom:20}}>
        <button onClick={()=>setTab('dashboard')}>Dashboard</button>
        <button onClick={()=>setTab('trades')}>Trades</button>
        <button onClick={()=>setTab('settings')}>Settings</button>
      </nav>
      {tab==='dashboard' && <Dashboard/>}
      {tab==='trades' && <Trades/>}
      {tab==='settings' && <Settings/>}
      <footer style={{marginTop:30, opacity:.7}}>Local demo • API at /health</footer>
    </div>
  )
}
