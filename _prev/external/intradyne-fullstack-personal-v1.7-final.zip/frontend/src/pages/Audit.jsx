
import React, { useEffect, useState } from 'react'
const API = import.meta.env.VITE_API_BASE || 'http://localhost:8080'
export default function Audit(){
  const [rows, setRows] = useState([])
  useEffect(()=>{
    fetch(`${API}/audit/list?limit=200`).then(r=>r.json()).then(setRows).catch(()=>{})
  },[])
  return (
    <div>
      <h3>Audit Log</h3>
      <table border="1" cellPadding="6">
        <thead><tr><th>ID</th><th>Time</th><th>Type</th><th>Entity</th><th>Action</th><th>Detail</th></tr></thead>
        <tbody>
          {rows.map(r=>(<tr key={r.id}>
            <td>{r.id}</td><td>{r.ts}</td><td>{r.entity_type}</td><td>{r.entity_id}</td><td>{r.action}</td><td>{r.detail}</td>
          </tr>))}
        </tbody>
      </table>
    </div>
  )
}
