
from sqlalchemy.orm import Session
from ..models import Position, KVSetting

def is_killswitch_on(db: Session) -> bool:
    row = db.query(KVSetting).filter_by(k="kill_switch").first()
    return (row is not None) and (row.v == "on")

def set_killswitch(db: Session, on: bool):
    row = db.query(KVSetting).filter_by(k="kill_switch").first()
    if not row:
        row = KVSetting(k="kill_switch", v="on" if on else "off")
        db.add(row)
    else:
        row.v = "on" if on else "off"
    db.commit()

def pretrade_ok(db: Session, order: dict, limits: dict | None = None) -> tuple[bool, dict]:
    # Simple limits: position notional <= max_position_pct * equity
    limits = limits or {"max_position_pct": 0.05, "equity": 100000.0}
    if is_killswitch_on(db):
        return False, {"reason": "kill_switch_on"}
    max_notional = limits["equity"] * float(limits["max_position_pct"])
    # approximate price using avg_price; if none, assume 100
    sym = order.get("symbol","").upper()
    qty = float(order.get("qty", 0))
    # find existing avg price
    pos = db.query(Position).filter_by(symbol=sym).first()
    px = (pos.avg_price if pos and pos.avg_price else 100.0)
    notional = qty * px
    if notional > max_notional:
        return False, {"reason": "max_position_pct_exceeded", "notional": notional, "limit": max_notional}
    return True, {"max_notional": max_notional}
