
from typing import Dict, Any
from ..models import Order, Position
from sqlalchemy.orm import Session
import random

class BaseAdapter:
    def __init__(self, cfg: dict):
        self.cfg = cfg
    def submit(self, db: Session, order: Order) -> Dict[str, Any]:
        raise NotImplementedError

class PaperAdapter(BaseAdapter):
    def submit(self, db: Session, order: Order) -> Dict[str, Any]:
        # immediate fill at synthetic price
        px = round(100 + random.random()*5, 2)
        order.price = px
        order.state = "filled"
        # update position
        pos = db.query(Position).filter_by(symbol=order.symbol).first()
        if not pos:
            pos = Position(symbol=order.symbol, qty=0.0, avg_price=0.0)
            db.add(pos)
        if order.side == "buy":
            new_qty = pos.qty + order.qty
            pos.avg_price = (pos.avg_price*pos.qty + px*order.qty) / new_qty if new_qty else px
            pos.qty = new_qty
        else:
            pos.qty = max(0.0, pos.qty - order.qty)
        db.commit()
        return {"status": "filled", "price": px}

def make_adapter(name: str, cfg: dict) -> BaseAdapter:
    name = (name or "paper").lower()
    if name == "paper":
        return PaperAdapter(cfg)
    # stubs for ibkr/alpaca can be added here
    return PaperAdapter(cfg)
