
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from ..db import get_db, Base, engine
from ..models import Order
router = APIRouter(prefix="/metrics", tags=["metrics"])
Base.metadata.create_all(bind=engine)

@router.get("/equity")
def equity_series(db: Session = Depends(get_db)):
    # naive: sum of (buy negative, sell positive) * price -> proxy PnL trend
    points = []
    cum = 100000.0
    for o in db.query(Order).order_by(Order.id.asc()).all():
        if o.state != "filled" or not o.price:
            continue
        delta = (-o.qty * o.price) if o.side == "buy" else (o.qty * o.price)
        cum += delta * 0.001  # tiny scaled proxy just for visual
        points.append({"id": o.id, "equity": round(cum,2)})
    if not points:
        points = [{"id":0,"equity":100000.0}]
    return {"points": points}
