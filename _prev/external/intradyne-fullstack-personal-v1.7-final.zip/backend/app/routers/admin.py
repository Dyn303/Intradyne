
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from ..db import get_db, Base, engine
from ..models import KVSetting, AuditLog
from ..services.risk import is_killswitch_on, set_killswitch
from ..services import alerts

router = APIRouter(prefix="/admin", tags=["admin"])
Base.metadata.create_all(bind=engine)

@router.get("/kill-switch")
def get_kill_switch(db: Session = Depends(get_db)):
    return {"kill_switch": "on" if is_killswitch_on(db) else "off"}

@router.post("/kill-switch")
def set_kill_switch(state: str, db: Session = Depends(get_db)):
    on = state.lower() in ("on","true","1","enable","enabled")
    set_killswitch(db, on)
    db.add(AuditLog(entity_type='admin', entity_id='kill_switch', action='toggle', detail='on' if on else 'off'))
    db.commit()
    alerts.send_email('IntraDyne: Kill Switch', f'State changed to {"ON" if on else "OFF"}')
    return {"kill_switch": "on" if on else "off"}
