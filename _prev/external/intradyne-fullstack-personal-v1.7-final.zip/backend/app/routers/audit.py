
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from ..db import get_db, Base, engine
from ..models import AuditLog

router = APIRouter(prefix="/audit", tags=["audit"])
Base.metadata.create_all(bind=engine)

@router.get("/list")
def list_audit(limit: int = 200, db: Session = Depends(get_db)):
    rows = db.query(AuditLog).order_by(AuditLog.id.desc()).limit(limit).all()
    return [{"id": r.id, "entity_type": r.entity_type, "entity_id": r.entity_id, "action": r.action, "detail": r.detail, "ts": r.ts} for r in rows]
