
from fastapi import APIRouter
from ..services import ws_stream
from fastapi import BackgroundTasks

router = APIRouter(prefix="/ws", tags=["websocket"])

@router.post("/stream/start")
async def stream_start(mode: str = "sim", symbol: str = "AAPL"):
    await ws_stream.start(mode, symbol)
    return {"ok": True, "status": ws_stream.status()}

@router.post("/stream/stop")
async def stream_stop():
    await ws_stream.stop()
    return {"ok": True}

@router.get("/stream/status")
def stream_status():
    return ws_stream.status()

@router.get("/stream/last_bar")
def stream_last_bar():
    bar = ws_stream.last_bar()
    return bar or {}
