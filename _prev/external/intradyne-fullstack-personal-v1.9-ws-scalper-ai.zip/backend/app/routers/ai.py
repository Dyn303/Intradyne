
from fastapi import APIRouter, UploadFile, File, Depends, HTTPException
from sqlalchemy.orm import Session
from ..db import get_db, Base, engine
from ..models import Order
from ..services import ai as ai_svc
from ..services.shariah import screen_symbol
from ..services.risk import pretrade_ok
from ..services.broker import make_adapter

router = APIRouter(prefix="/ai", tags=["ai"])
Base.metadata.create_all(bind=engine)

@router.post("/history/{symbol}")
async def upload_history(symbol: str, file: UploadFile = File(...)):
    content = (await file.read()).decode("utf-8")
    path = ai_svc.save_history(symbol, content)
    return {"ok": True, "saved": path}

@router.get("/signal/{symbol}")
def get_signal(symbol: str):
    series = ai_svc.load_history(symbol)
    sig = ai_svc.compute_signal(series, ema_fast=3, ema_slow=12, rsi_period=7, buy_thresh=80, sell_thresh=20)
    return sig

@router.post("/autotrade/{symbol}")
def autotrade(symbol: str, qty: int = 1, db: Session = Depends(get_db)):
    series = ai_svc.load_history(symbol)
    sig = ai_svc.compute_signal(series, ema_fast=3, ema_slow=12, rsi_period=7, buy_thresh=80, sell_thresh=20)
    decision = sig.get("decision")
    if decision not in ("BUY","SELL"):
        raise HTTPException(status_code=400, detail="No actionable signal (HOLD)")
    # compliance
    verdict, _ = screen_symbol(symbol.upper())
    if verdict != "PASS":
        raise HTTPException(status_code=400, detail="Shariah screen failed")
    # risk
    ok, _ = pretrade_ok(db, {"symbol":symbol.upper(), "side":decision.lower(), "qty":qty})
    if not ok:
        raise HTTPException(status_code=400, detail="Risk check failed")
    # create + execute (paper adapter by default)
    order = Order(symbol=symbol.upper(), side=decision.lower(), qty=int(qty), state="submitted", broker="paper")
    adapter = make_adapter("paper", {})
    adapter.submit(db, order)
    db.refresh(order)
    return {"order_id": order.id, "symbol": order.symbol, "side": order.side, "qty": order.qty, "price": order.price, "state": order.state}

@router.post("/backtest")
def run_backtest(symbol: str, initial_cash: float = 200.0, qty: int = 1):
    series = ai_svc.load_history(symbol)
    res = ai_svc.backtest(series, ema_fast=3, ema_slow=12, rsi_period=7, buy_thresh=80, sell_thresh=20, initial_cash=initial_cash, qty=qty)
    if "error" in res:
        raise HTTPException(status_code=400, detail="No price history uploaded for this symbol")
    return res
