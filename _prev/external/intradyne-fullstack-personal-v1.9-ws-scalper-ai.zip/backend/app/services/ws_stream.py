
import asyncio, os, json, random, time
from typing import Optional, Dict, Any

STREAM_TASK: asyncio.Task | None = None
STREAM_STATE: Dict[str, Any] = {"mode": None, "symbol": None, "last_bar": None}

async def _sim_stream(symbol: str):
    # Generates a bar every 2 seconds to emulate 1m bars
    px = 100.0
    while True:
        o = px
        # random walk
        for _ in range(5):
            px += random.uniform(-0.2, 0.2)
            await asyncio.sleep(0.4)
        c = px
        h = max(o, c) + random.uniform(0, 0.1)
        l = min(o, c) - random.uniform(0, 0.1)
        ts = int(time.time())
        bar = {"t": ts, "o": round(o,2), "h": round(h,2), "l": round(l,2), "c": round(c,2), "symbol": symbol}
        STREAM_STATE["last_bar"] = bar

async def _alpaca_stream(symbol: str):
    # Skeleton (requires API keys and internet connectivity)
    # Provided for reference only; not executed in this environment.
    import websockets, json, os
    key = os.getenv("ALPACA_KEY") or ""
    sec = os.getenv("ALPACA_SECRET") or ""
    url = os.getenv("ALPACA_WSS", "wss://stream.data.alpaca.markets/v2/stocks")
    async with websockets.connect(url) as ws:
        await ws.send(json.dumps({"action":"auth","key":key,"secret":sec}))
        await ws.send(json.dumps({"action":"subscribe","bars":[symbol]}))
        async for msg in ws:
            data = json.loads(msg)
            for d in data:
                if d.get("T") == "b" and d.get("S") == symbol:
                    bar = {"t": d["t"], "o": d["o"], "h": d["h"], "l": d["l"], "c": d["c"], "symbol": symbol}
                    STREAM_STATE["last_bar"] = bar

async def start(mode: str, symbol: str):
    global STREAM_TASK
    await stop()
    STREAM_STATE["mode"] = mode
    STREAM_STATE["symbol"] = symbol.upper()
    if mode == "alpaca":
        STREAM_TASK = asyncio.create_task(_alpaca_stream(symbol.upper()))
    else:
        STREAM_TASK = asyncio.create_task(_sim_stream(symbol.upper()))

async def stop():
    global STREAM_TASK
    if STREAM_TASK and not STREAM_TASK.done():
        STREAM_TASK.cancel()
        try:
            await STREAM_TASK
        except Exception:
            pass
    STREAM_TASK = None
    STREAM_STATE["mode"] = None

def status():
    running = STREAM_TASK is not None and not STREAM_TASK.done()
    return {"running": running, "mode": STREAM_STATE.get("mode"), "symbol": STREAM_STATE.get("symbol")}

def last_bar():
    return STREAM_STATE.get("last_bar")
