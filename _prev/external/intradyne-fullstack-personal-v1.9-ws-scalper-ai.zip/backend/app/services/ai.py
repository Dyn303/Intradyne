
import csv, math
from pathlib import Path
from typing import List, Tuple, Dict

DATA_DIR = Path(__file__).resolve().parents[1] / "data" / "history"
DATA_DIR.mkdir(parents=True, exist_ok=True)

def save_history(symbol: str, content: str):
    p = DATA_DIR / f"{symbol.upper()}.csv"
    p.write_text(content, encoding="utf-8")
    return str(p)

def load_history(symbol: str) -> List[Tuple[str, float]]:
    p = DATA_DIR / f"{symbol.upper()}.csv"
    if not p.exists():
        return []
    rows = []
    with open(p, "r", encoding="utf-8") as f:
        r = csv.DictReader(f)
        # Expect columns: date, close
        for row in r:
            try:
                d = row.get("date") or row.get("Date") or row.get("timestamp") or ""
                c = float(row.get("close") or row.get("Close") or row.get("adj_close") or row.get("Adj Close"))
                rows.append((d, c))
            except Exception:
                continue
    return rows

def ema(prev: float | None, price: float, span: int) -> float:
    k = 2/(span+1)
    return price*k + (prev if prev is not None else price)*(1-k)

def rsi_update(prev_avg_gain: float | None, prev_avg_loss: float | None, delta: float, period: int=7):
    gain = max(delta, 0.0)
    loss = max(-delta, 0.0)
    avg_gain = (prev_avg_gain*(period-1) + gain)/period if prev_avg_gain is not None else gain
    avg_loss = (prev_avg_loss*(period-1) + loss)/period if prev_avg_loss is not None else loss
    rs = avg_gain/(avg_loss + 1e-9)
    rsi = 100 - (100/(1+rs))
    return rsi, avg_gain, avg_loss

def compute_signal(series: List[Tuple[str, float]], ema_fast=3, ema_slow=12, rsi_period=7, buy_thresh=80, sell_thresh=20) -> Dict:
    if not series:
        return {"decision": "HOLD", "reason": "no_history"}
    ema_f = ema_s = None
    prev = None
    avg_g = avg_l = None
    last = None
    for d, px in series:
        ema_f = ema(ema_f, px, ema_fast)
        ema_s = ema(ema_s, px, ema_slow)
        rsi = 50.0
        if prev is not None:
            rsi, avg_g, avg_l = rsi_update(avg_g, avg_l, px - prev, rsi_period)
        prev = px
        last = {"date": d, "price": px, "ema_fast": ema_f, "ema_slow": ema_s, "rsi": rsi}
    decision = "HOLD"
    if last:
        if ema_f > ema_s and last["rsi"] < buy_thresh:
            decision = "BUY"
        elif ema_f < ema_s and last["rsi"] > sell_thresh:
            decision = "SELL"
    last["decision"] = decision
    return last

def backtest(series: List[Tuple[str, float]], ema_fast=3, ema_slow=12, rsi_period=7, buy_thresh=80, sell_thresh=20, initial_cash=200.0, qty=1):
    if not series:
        return {"error": "no_history"}
    cash = float(initial_cash)
    position = 0
    equity_curve = []
    trades = []
    ema_f = ema_s = None
    prev = None
    avg_g = avg_l = None
    for d, px in series:
        ema_f = ema(ema_f, px, ema_fast)
        ema_s = ema(ema_s, px, ema_slow)
        rsi = 50.0
        if prev is not None:
            rsi, avg_g, avg_l = rsi_update(avg_g, avg_l, px - prev, rsi_period)
        prev = px
        decision = "HOLD"
        if ema_f and ema_s:
            if ema_f > ema_s and rsi < buy_thresh and cash >= px*qty:
                cash -= px*qty; position += qty; trades.append({"date": d, "side":"buy", "price": px})
                decision = "BUY"
            elif ema_f < ema_s and rsi > sell_thresh and position >= qty:
                cash += px*qty; position -= qty; trades.append({"date": d, "side":"sell", "price": px})
                decision = "SELL"
        equity_curve.append({"date": d, "equity": round(cash + position*px, 2)})
    final_equity = equity_curve[-1]["equity"]
    pnl = round(final_equity - initial_cash, 2)
    # max drawdown
    peak = -1e9
    max_dd = 0.0
    for pt in equity_curve:
        if pt["equity"] > peak: peak = pt["equity"]
        dd = (peak - pt["equity"])/peak if peak > 0 else 0.0
        if dd > max_dd: max_dd = dd
    return {
        "final_equity": final_equity,
        "pnl": pnl,
        "trades": trades,
        "max_drawdown_pct": round(max_dd*100, 2),
        "equity_curve": equity_curve
    }
