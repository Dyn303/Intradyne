
import React, { useEffect, useState } from 'react'

const API = import.meta.env.VITE_API_BASE || 'http://localhost:8080'

export default function Dashboard(){
  const [portfolio, setPortfolio] = useState({positions:[], cash:0, pnl_unrealized:0})
  useEffect(()=>{
    fetch(`${API}/portfolio/overview`).then(r=>r.json()).then(setPortfolio).catch(()=>{})
  },[])
  return (
    <div>
      <h3>Overview</h3><div><a href={(import.meta.env.VITE_API_BASE||'http://localhost:8080') + '/reports/orders.csv'} target='_blank'>Export Orders CSV</a> | <a href={(import.meta.env.VITE_API_BASE||'http://localhost:8080') + '/compliance/blacklist.csv'} target='_blank'>Download Blacklist CSV</a></div>
      <div>Cash: {portfolio.cash}</div>
      <div>Unrealized PnL: {portfolio.pnl_unrealized}</div>
      <h4>Positions</h4>
      <table border="1" cellPadding="6">
        <thead><tr><th>Symbol</th><th>Qty</th><th>Avg Price</th></tr></thead>
        <tbody>
        {portfolio.positions.map((p,i)=>(
          <tr key={i}><td>{p.symbol}</td><td>{p.qty}</td><td>{p.avg_price}</td></tr>
        ))}
        </tbody>
      </table>

      <h4 style={{marginTop:20}}>Equity Curve</h4>
      <EquityChart/>

</div>
  )
}
