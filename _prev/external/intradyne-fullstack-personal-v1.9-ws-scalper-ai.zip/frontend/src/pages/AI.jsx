
import React, { useState } from 'react'
const API = import.meta.env.VITE_API_BASE || 'http://localhost:8080'

export default function AIPage(){
  const [symbol, setSymbol] = useState('AAPL')
  const [qty, setQty] = useState(1)
  const [file, setFile] = useState(null)
  const [signal, setSignal] = useState(null)
  const [bt, setBt] = useState(null)

  const upload = async () => {
    if(!file) return
    const form = new FormData()
    form.append('file', file)
    const r = await fetch(`${API}/ai/history/${symbol}`, {method:'POST', body: form})
    if(r.ok) alert('History uploaded')
  }

  const getSignal = async () => {
    const r = await fetch(`${API}/ai/signal/${symbol}`)
    const j = await r.json()
    setSignal(j)
  }

  const autotrade = async () => {
    const r = await fetch(`${API}/ai/autotrade/${symbol}?qty=${qty}`, {method:'POST'})
    const j = await r.json()
    if(r.ok) alert(`Order ${j.side} ${j.symbol} @ ${j.price}`)
    else alert(j.detail || 'Error')
  }

  const backtest = async () => {
    const r = await fetch(`${API}/ai/backtest?symbol=${symbol}&initial_cash=200&qty=1`, {method:'POST'})
    const j = await r.json()
    setBt(j)
  }

  return (
    <div>
      <h3>AI Strategy (EMA3/12 + RSI7)</h3>
      <div style={{display:'grid', gap:10, maxWidth:600}}>
        <label>Symbol <input value={symbol} onChange={e=>setSymbol(e.target.value)}/></label>
        <div>
          <input type="file" accept=".csv" onChange={e=>setFile(e.target.files[0])}/>{' '}
          <button onClick={upload}>Upload Price History CSV</button>
        </div>
        <div>
          <button onClick={getSignal}>Generate Signal</button>{' '}
          <button onClick={autotrade}>Auto‑Trade (Paper)</button>
        </div>
        {signal && <pre style={{background:'#f5f5f5', padding:10}}>{JSON.stringify(signal,null,2)}</pre>}

        <div>
          <button onClick={backtest}>Run Backtest ($200, qty 1)</button>
        </div>
        {bt && <div>
          <div>Final Equity: ${bt.final_equity}</div>
          <div>PnL: ${bt.pnl}</div>
          <div>Max Drawdown: {bt.max_drawdown_pct}%</div>
          <h4>Equity Curve</h4>
          <EquityCurve points={bt.equity_curve}/>
        </div>}
      </div>
    </div>
  )
}

function EquityCurve({points}){
  const width=520, height=140, pad=10
  if(!points || points.length===0) return null
  const ys = points.map(p=>p.equity)
  const minY = Math.min(...ys), maxY = Math.max(...ys)
  const xs = points.map((_,i)=>i)
  const toX = (i)=> pad + (i/(xs.length-1||1))*(width-2*pad)
  const toY = (y)=> height - pad - ((y-minY)/(maxY-minY||1))*(height-2*pad)
  const d = points.map((p,i)=> (i===0?'M':'L')+toX(i)+','+toY(p.equity)).join(' ')
  return (<svg width={width} height={height} style={{border:'1px solid #ddd', background:'#fafafa'}}>
    <path d={d} fill="none" stroke="black" strokeWidth="1.5" />
  </svg>)
}
