
import React, { useEffect, useState } from 'react'
const API = import.meta.env.VITE_API_BASE || 'http://localhost:8080'

export default function Realtime(){
  const [symbol, setSymbol] = useState('AAPL')
  const [qty, setQty] = useState(1)
  const [tp, setTp] = useState(30)
  const [sl, setSl] = useState(20)
  const [bar, setBar] = useState(null)
  const [wsStatus, setWsStatus] = useState({})
  const [scStatus, setScStatus] = useState({})

  const refresh = async () => {
    const s = await fetch(`${API}/ws/stream/status`).then(r=>r.json())
    setWsStatus(s)
    const b = await fetch(`${API}/ws/stream/last_bar`).then(r=>r.json())
    setBar(b)
    const sc = await fetch(`${API}/scalper/status`).then(r=>r.json())
    setScStatus(sc)
  }

  useEffect(()=>{
    const id = setInterval(refresh, 1000)
    return ()=>clearInterval(id)
  }, [])

  const startStream = async () => {
    await fetch(`${API}/ws/stream/start?mode=sim&symbol=${symbol}`, {method:'POST'})
    refresh()
  }
  const stopStream = async () => {
    await fetch(`${API}/ws/stream/stop`, {method:'POST'})
    refresh()
  }
  const startScalper = async () => {
    await fetch(`${API}/scalper/start?symbol=${symbol}&qty=${qty}&tp_bps=${tp}&sl_bps=${sl}`, {method:'POST'})
    refresh()
  }
  const stopScalper = async () => {
    await fetch(`${API}/scalper/stop`, {method:'POST'})
    refresh()
  }

  return (
    <div>
      <h3>Realtime Stream & Scalper</h3>
      <div style={{display:'grid', gap:8, maxWidth:500}}>
        <label>Symbol <input value={symbol} onChange={e=>setSymbol(e.target.value)}/></label>
        <div>
          <button onClick={startStream}>Start Stream (SIM)</button>{' '}
          <button onClick={stopStream}>Stop Stream</button>
          <div style={{opacity:.7, marginTop:4}}>Stream: {wsStatus.running ? 'ON' : 'OFF'} ({wsStatus.mode || '-'})</div>
        </div>
        <div style={{display:'grid', gridTemplateColumns:'1fr 1fr 1fr 1fr', gap:8}}>
          <label>Qty <input type="number" min="1" value={qty} onChange={e=>setQty(e.target.value)} /></label>
          <label>TP (bps) <input type="number" min="5" value={tp} onChange={e=>setTp(e.target.value)} /></label>
          <label>SL (bps) <input type="number" min="5" value={sl} onChange={e=>setSl(e.target.value)} /></label>
        </div>
        <div>
          <button onClick={startScalper}>Start Scalper</button>{' '}
          <button onClick={stopScalper}>Stop Scalper</button>
          <div style={{opacity:.7, marginTop:4}}>Scalper: {scStatus.running ? 'ON' : 'OFF'} • {scStatus.last_signal || '-'}</div>
        </div>
        <div style={{marginTop:10}}>
          <b>Last Bar:</b>
          <pre style={{background:'#f5f5f5', padding:10}}>{bar ? JSON.stringify(bar, null, 2) : '—'}</pre>
        </div>
      </div>
    </div>
  )
}
