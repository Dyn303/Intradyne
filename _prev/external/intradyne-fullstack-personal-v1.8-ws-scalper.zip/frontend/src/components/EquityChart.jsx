
import React, { useEffect, useState } from 'react'
const API = import.meta.env.VITE_API_BASE || 'http://localhost:8080'
export default function EquityChart(){
  const [pts, setPts] = useState([])
  useEffect(()=>{ fetch(`${API}/metrics/equity`).then(r=>r.json()).then(d=>setPts(d.points||[])).catch(()=>{}) },[])
  const width=500, height=120, pad=10
  if(pts.length===0) return null
  const xs = pts.map(p=>p.id), ys = pts.map(p=>p.equity)
  const minY = Math.min(...ys), maxY = Math.max(...ys)
  const toX = (i)=> pad + (i/(xs.length-1||1))*(width-2*pad)
  const toY = (y)=> height - pad - ((y-minY)/(maxY-minY||1))*(height-2*pad)
  const d = pts.map((p,i)=> (i===0?'M':'L')+toX(i)+','+toY(p.equity)).join(' ')
  return (<svg width={width} height={height} style={{border:'1px solid #ddd', background:'#fafafa'}}>
    <path d={d} fill="none" stroke="black" strokeWidth="1.5" />
  </svg>)
}
