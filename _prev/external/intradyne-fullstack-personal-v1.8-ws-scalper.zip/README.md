
# IntraDyne – Full‑Stack Personal Edition (No‑Code)
This package gives you a **local web app + API** you can run in minutes. Add your broker API key later from **Settings**.

## Requirements
- Docker & Docker Compose

## Quick Start
```bash
# 1) Copy env
cp backend/.env.example backend/.env
# 2) Start
docker compose up --build -d
# 3) Open UI
#   http://localhost:5173
# 4) Go to Settings and set broker (Paper by default). Add API key/secret later.
```

## What You Get
- **Backend (FastAPI)** on port 8080
  - `/settings/broker` – save broker name + API key/secret (encrypted locally)
  - `/trades/signal` – submit a paper order (with Shariah + risk checks)
  - `/portfolio/overview` – positions snapshot
- **Frontend (React/Vite)** on port 5173
  - Tabs: **Dashboard**, **Trades**, **Settings**

## Notes
- Data stored in `backend/intradyne.db` (SQLite).
- Secrets encrypted with a key derived from `SECRET_KEY` in `.env` (personal-use simple scheme).
- Paper trading fills instantly with synthetic prices. Live brokers can be wired later.


## v1.2 Upgrades
- **Kill Switch** (Admin → Settings) with backend enforcement.
- **Risk limit**: blocks orders exceeding max position % of equity (demo).
- **Reports**: export **orders.csv** from Dashboard.
- **Compliance**: upload/download **blacklist.csv**.
- **Equity curve** chart on Dashboard (demo metric).


## v1.8 – WebSocket Stream + Scalper (SIM)
- **WebSocket stream (simulated)**: start/stop from **Realtime** tab; emits bars every ~2s.
- **Scalper autopilot**: EMA9/21 + RSI7 with TP/SL (bps) — trades on the paper adapter.
- To use a real broker stream (e.g., **Alpaca**), set env `ALPACA_KEY`, `ALPACA_SECRET`, `ALPACA_WSS` and switch mode in `/ws/stream/start?mode=alpaca` (code included for reference).
