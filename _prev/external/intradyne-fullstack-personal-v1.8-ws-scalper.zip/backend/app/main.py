
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from .config import settings
from .routers import settings as r_settings, trades as r_trades, portfolio as r_portfolio, ws as r_ws, scalper as r_scalper, admin as r_admin, reports as r_reports, compliance as r_compliance, metrics as r_metrics

app = FastAPI(title="IntraDyne Personal API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/health")
def health():
    return {"ok": True}

@app.get("/meta/version")
def version():
    return {"version": "1.0.0", "env": settings.app_env}

app.include_router(r_settings.router)
app.include_router(r_trades.router)
app.include_router(r_portfolio.router)

app.include_router(r_ws.router)
app.include_router(r_scalper.router)
