
import asyncio, math, time
from typing import Optional, Dict
from sqlalchemy.orm import Session
from ..models import Position, Order
from .ws_stream import last_bar
from .broker import make_adapter
from .shariah import screen_symbol
from .risk import pretrade_ok

def _ema(prev, price, span):
    k = 2/(span+1)
    return price*k + prev*(1-k) if prev is not None else price

def _rsi(prev_avg_gain, prev_avg_loss, delta, period=7):
    gain = max(delta, 0.0)
    loss = max(-delta, 0.0)
    avg_gain = (prev_avg_gain*(period-1) + gain) / period if prev_avg_gain is not None else gain
    avg_loss = (prev_avg_loss*(period-1) + loss) / period if prev_avg_loss is not None else loss
    rs = (avg_gain / (avg_loss + 1e-9))
    rsi = 100 - (100/(1+rs))
    return rsi, avg_gain, avg_loss

class ScalperState:
    def __init__(self):
        self.running = False
        self.symbol = None
        self.qty = 1
        self.tp_bps = 30   # 0.30%
        self.sl_bps = 20   # 0.20%
        self.ema_fast = None
        self.ema_slow = None
        self.prev_price = None
        self.avg_gain = None
        self.avg_loss = None
        self.position = 0
        self.entry_price = None
        self.last_signal = "HOLD"
        self.trades = 0

STATE = ScalperState()

async def start(db: Session, symbol: str, qty: int = 1, tp_bps: int = 30, sl_bps: int = 20):
    STATE.running = True
    STATE.symbol = symbol.upper()
    STATE.qty = int(qty)
    STATE.tp_bps = int(tp_bps)
    STATE.sl_bps = int(sl_bps)
    STATE.ema_fast = STATE.ema_slow = STATE.prev_price = STATE.avg_gain = STATE.avg_loss = None
    STATE.position = 0
    STATE.entry_price = None
    STATE.last_signal = "HOLD"
    STATE.trades = 0

    adapter = make_adapter("paper", {})  # uses paper by default

    while STATE.running:
        bar = last_bar()
        if not bar or bar.get("symbol") != STATE.symbol:
            await asyncio.sleep(0.2)
            continue
        price = float(bar["c"])
        # update ema
        STATE.ema_fast = _ema(STATE.ema_fast, price, 9)
        STATE.ema_slow = _ema(STATE.ema_slow, price, 21)
        # update rsi
        if STATE.prev_price is not None:
            rsi, ag, al = _rsi(STATE.avg_gain, STATE.avg_loss, price - STATE.prev_price, 7)
            STATE.avg_gain, STATE.avg_loss = ag, al
        else:
            rsi = 50.0
            STATE.avg_gain, STATE.avg_loss = 0.0, 0.0
        STATE.prev_price = price

        # exit logic if in position
        if STATE.position > 0 and STATE.entry_price is not None:
            gain = (price/STATE.entry_price - 1.0)*10000  # bps
            if gain >= STATE.tp_bps:
                # take profit -> sell
                order = Order(symbol=STATE.symbol, side="sell", qty=STATE.qty, state="submitted", broker="paper")
                ok, _ = pretrade_ok(db, {"symbol":STATE.symbol, "side":"sell", "qty":STATE.qty})
                if ok:
                    adapter.submit(db, order)
                    STATE.position = 0; STATE.entry_price = None; STATE.trades += 1
                    STATE.last_signal = f"TP SELL @{round(price,2)}"
            elif gain <= -STATE.sl_bps:
                # stop loss -> sell
                order = Order(symbol=STATE.symbol, side="sell", qty=STATE.qty, state="submitted", broker="paper")
                ok, _ = pretrade_ok(db, {"symbol":STATE.symbol, "side":"sell", "qty":STATE.qty})
                if ok:
                    adapter.submit(db, order)
                    STATE.position = 0; STATE.entry_price = None; STATE.trades += 1
                    STATE.last_signal = f"SL SELL @{round(price,2)}"

        # entry logic
        if STATE.position == 0 and STATE.ema_fast and STATE.ema_slow and STATE.ema_fast > STATE.ema_slow and rsi < 80:
            verdict, ev = screen_symbol(STATE.symbol)
            ok, _ = pretrade_ok(db, {"symbol":STATE.symbol, "side":"buy", "qty":STATE.qty})
            if verdict == "PASS" and ok:
                order = Order(symbol=STATE.symbol, side="buy", qty=STATE.qty, state="submitted", broker="paper")
                adapter.submit(db, order)
                STATE.position = STATE.qty
                STATE.entry_price = price
                STATE.trades += 1
                STATE.last_signal = f"BUY @{round(price,2)}"
        await asyncio.sleep(0.2)

def stop():
    STATE.running = False

def status() -> Dict:
    return {
        "running": STATE.running, "symbol": STATE.symbol, "qty": STATE.qty,
        "tp_bps": STATE.tp_bps, "sl_bps": STATE.sl_bps, "position": STATE.position,
        "entry_price": STATE.entry_price, "trades": STATE.trades, "last_signal": STATE.last_signal
    }
