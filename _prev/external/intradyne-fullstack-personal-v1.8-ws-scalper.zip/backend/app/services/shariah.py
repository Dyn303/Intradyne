
import yaml, json
from pathlib import Path

RULES_PATH = Path(__file__).resolve().parent.parent / "data" / "shariah_rules.yaml"

def load_rules() -> dict:
    with open(RULES_PATH, "r", encoding="utf-8") as f:
        return yaml.safe_load(f) or {}

def screen_symbol(symbol: str) -> tuple[str, dict]:
    # Minimal stub: block a few tickers if listed in rules
    rules = load_rules()
    blocked = set(rules.get("blocked_symbols", []))
    if symbol.upper() in blocked:
        return "FAIL", {"reason": "blocked_symbol", "symbol": symbol}
    return "PASS", {"reason": "ok", "symbol": symbol, "rules": rules.get("notes","")}
