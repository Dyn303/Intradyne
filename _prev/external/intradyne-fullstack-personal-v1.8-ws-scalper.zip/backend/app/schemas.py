
from pydantic import BaseModel, Field
from typing import Optional, List, Any

class BrokerSettingsIn(BaseModel):
    name: str = Field(description="paper | ibkr | alpaca")
    api_key: Optional[str] = None
    api_secret: Optional[str] = None
    base_url: Optional[str] = None

class BrokerSettingsOut(BaseModel):
    name: str
    base_url: Optional[str] = None
    api_key_masked: Optional[str] = None
    has_secret: bool = False

class SignalIn(BaseModel):
    symbol: str
    side: str  # buy/sell
    qty: float

class OrderOut(BaseModel):
    id: int
    client_order_id: str
    symbol: str
    side: str
    qty: float
    state: str
    price: float | None
    broker: str

class PortfolioOverview(BaseModel):
    positions: list[dict]
    pnl_unrealized: float = 0.0
    cash: float = 100000.0

class ComplianceVerdictOut(BaseModel):
    symbol: str
    verdict: str
    evidence: dict
