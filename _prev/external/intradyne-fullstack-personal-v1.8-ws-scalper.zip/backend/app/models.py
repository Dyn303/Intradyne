
from sqlalchemy import Column, Integer, String, Float, DateTime, JSON, Boolean, Text
from sqlalchemy.sql import func
from .db import Base

class BrokerSettings(Base):
    __tablename__ = "broker_settings"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(50), default="paper")  # paper | ibkr | alpaca
    api_key_enc = Column(Text, nullable=True)
    api_secret_enc = Column(Text, nullable=True)
    base_url = Column(String(255), nullable=True)
    updated_at = Column(DateTime, server_default=func.now(), onupdate=func.now())

class Order(Base):
    __tablename__ = "orders"
    id = Column(Integer, primary_key=True, index=True)
    client_order_id = Column(String(64), unique=True, index=True)
    symbol = Column(String(32))
    side = Column(String(8))   # buy/sell
    qty = Column(Float)
    state = Column(String(16), default="submitted")  # submitted/filled/cancelled/rejected
    price = Column(Float, nullable=True)
    broker = Column(String(50), default="paper")
    ts_created = Column(DateTime, server_default=func.now())

class Position(Base):
    __tablename__ = "positions"
    id = Column(Integer, primary_key=True)
    symbol = Column(String(32), index=True)
    qty = Column(Float, default=0.0)
    avg_price = Column(Float, default=0.0)

class ComplianceVerdict(Base):
    __tablename__ = "compliance_verdicts"
    id = Column(Integer, primary_key=True)
    symbol = Column(String(32), index=True)
    verdict = Column(String(16))  # PASS/FAIL
    evidence_json = Column(Text)
    ts = Column(DateTime, server_default=func.now())

class AuditLog(Base):
    __tablename__ = "audit_logs"
    id = Column(Integer, primary_key=True)
    entity_type = Column(String(32))
    entity_id = Column(String(64))
    action = Column(String(64))
    detail = Column(Text)
    ts = Column(DateTime, server_default=func.now())


class KVSetting(Base):
    __tablename__ = "kv_settings"
    id = Column(Integer, primary_key=True)
    k = Column(String(64), unique=True, index=True)
    v = Column(Text)
