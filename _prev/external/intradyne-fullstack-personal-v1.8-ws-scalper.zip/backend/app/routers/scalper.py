
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from ..db import get_db
from ..services import scalper
import asyncio

router = APIRouter(prefix="/scalper", tags=["scalper"])

@router.post("/start")
async def scalper_start(symbol: str = "AAPL", qty: int = 1, tp_bps: int = 30, sl_bps: int = 20, db: Session = Depends(get_db)):
    asyncio.create_task(scalper.start(db, symbol, qty, tp_bps, sl_bps))
    return {"ok": True, "status": scalper.status()}

@router.post("/stop")
def scalper_stop():
    scalper.stop()
    return {"ok": True, "status": scalper.status()}

@router.get("/status")
def scalper_status():
    return scalper.status()
