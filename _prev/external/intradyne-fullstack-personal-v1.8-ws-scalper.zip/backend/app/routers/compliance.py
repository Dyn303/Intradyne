
from fastapi import APIRouter, UploadFile, File
from fastapi.responses import StreamingResponse
import csv, io, yaml
from pathlib import Path

router = APIRouter(prefix="/compliance", tags=["compliance"])
RULES_PATH = Path(__file__).resolve().parents[1] / "data" / "shariah_rules.yaml"

@router.get("/blacklist.csv")
def download_blacklist():
    data = yaml.safe_load(open(RULES_PATH, "r", encoding="utf-8")) or {}
    blocked = data.get("blocked_symbols", [])
    f = io.StringIO()
    w = csv.writer(f)
    w.writerow(["symbol"])
    for s in blocked:
        w.writerow([s])
    f.seek(0)
    return StreamingResponse(f, media_type="text/csv", headers={"Content-Disposition":"attachment; filename=blacklist.csv"})

@router.post("/blacklist.csv")
async def upload_blacklist(file: UploadFile = File(...)):
    content = await file.read()
    text = content.decode("utf-8")
    r = csv.reader(io.StringIO(text))
    header = next(r, None)
    blocked = []
    for row in r:
        if not row: continue
        blocked.append(row[0].strip().upper())
    data = yaml.safe_load(open(RULES_PATH, "r", encoding="utf-8")) or {}
    data["blocked_symbols"] = sorted(set(blocked))
    with open(RULES_PATH, "w", encoding="utf-8") as f:
        yaml.safe_dump(data, f, sort_keys=False)
    return {"updated": len(blocked)}
