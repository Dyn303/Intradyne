
import argparse
from intradyne_lite.utils.logging import log
from intradyne_lite.utils.ohlcv import load_csv
from intradyne_lite.core.engine import load_config, build
from intradyne_lite.strategies.ema_rsi_atr import Strategy
from intradyne_lite.backtest.simulate import run as sim_run
from intradyne_lite.live.trader import run_live

def _build_connector(name, cfg):
    if name == "ccxt_spot":
        from intradyne_lite.connectors.ccxt_spot import CCXTSpot
        return CCXTSpot(cfg)
    if name == "alpaca":
        from intradyne_lite.connectors.alpaca import Alpaca
        return Alpaca(cfg)
    if name == "ibkr":
        from intradyne_lite.connectors.ibkr import IBKR
        return IBKR(cfg)
    raise ValueError(f"Unknown connector: {name}")

def cmd_backtest(args):
    cfg = load_config(args.config)
    storage, risk_cfg, shariah = build(cfg)

    df = load_csv(args.csv)
    prepared = Strategy(cfg["strategy"]["params"]).prepare(df)

    # backtest using prepared indicators
    strategy = Strategy(cfg["strategy"]["params"])
    state, trades = sim_run(prepared, strategy, {
        "max_r_per_trade": cfg["risk"]["max_r_per_trade"],
        "atr_mult_sl": cfg["strategy"]["params"]["atr_mult_sl"],
        "atr_mult_tp": cfg["strategy"]["params"]["atr_mult_tp"],
    })

    log("Finished. Equity:", round(state.equity,2), "Trades:", len(trades))
    wins = sum(1 for t in trades if t[0] in ("take","close") and t[-1]>0)
    losses = sum(1 for t in trades if t[0] in ("stop","close") and t[-1]<=0)
    log("Wins:", wins, "Losses:", losses)

def cmd_broker_smoke(args):
    cfg = load_config(args.config)
    connector_name = cfg.get("connector", "none")
    if connector_name == "none":
        log("Connector is 'none'. Set connector and connector_cfg in config.yaml.")
        return
    conn = _build_connector(connector_name, cfg.get("connector_cfg", {}))
    price = conn.get_price(args.symbol)
    log(f"{connector_name} price {args.symbol} ->", price)
    if args.side:
        qty = float(args.qty)
        resp = conn.place_order(args.symbol, args.side, qty, None, None, None)
        log("Order resp:", resp)


def cmd_live(args):
    # args.config used by run_live
    run_live(args.config)

def main():

    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd")

    ap_b = sub.add_parser("backtest")
    ap_b.add_argument("--config", required=True)
    ap_b.add_argument("--csv", required=True)
    ap_b.set_defaults(func=cmd_backtest)

    ap_s = sub.add_parser("broker_smoke", help="Check connector price and optionally place a small market order")
    ap_s.add_argument("--config", required=True)
    ap_s.add_argument("--symbol", required=True, help="e.g., BTC/USDT for ccxt, AAPL for alpaca/ibkr")
    ap_s.add_argument("--side", choices=["buy","sell"], help="If set, will place a market order")
    ap_s.add_argument("--qty", default="0", help="Order quantity when --side is set")
    ap_s.set_defaults(func=cmd_broker_smoke)

    
    ap_l = sub.add_parser("live", help="Run safe live loop (dry-run by default)")
    ap_l.add_argument("--config", required=True)
    ap_l.set_defaults(func=cmd_live)
args = ap.parse_args()
    if not args.cmd:
        ap.print_help()
        return
    args.func(args)

if __name__ == "__main__":
    main()
