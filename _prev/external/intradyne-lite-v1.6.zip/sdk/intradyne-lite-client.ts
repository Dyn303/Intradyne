/**
 * IntraDyne Lite minimal client (TypeScript)
 * Use in React Native / Expo / web.
 */
export interface ClientOpts {
  baseUrl: string;           // e.g., "http://localhost:8000"
  apiKey?: string;           // optional X-API-Key
  jwt?: string;              // optional Bearer token
}

export class IntraDyneClient {
  constructor(private opts: ClientOpts) {}

  private headers(extra: Record<string,string> = {}) {
    const h: Record<string,string> = { "Content-Type": "application/json", ...extra };
    if (this.opts.jwt) h["Authorization"] = `Bearer ${this.opts.jwt}`;
    if (this.opts.apiKey) h["X-API-Key"] = this.opts.apiKey;
    return h;
  }

  async health() {
    const r = await fetch(`${this.opts.baseUrl}/health`, { headers: this.headers() });
    return r.json();
    }
  async config() {
    const r = await fetch(`${this.opts.baseUrl}/config`, { headers: this.headers() });
    return r.json();
  }
  async price(symbol: string, account?: string) {
    const r = await fetch(`${this.opts.baseUrl}/price?symbol=${encodeURIComponent(symbol)}${account?`&account=${account}`:''}`, { headers: this.headers() });
    return r.json();
  }
  async positions(account?: string) {
    const r = await fetch(`${this.opts.baseUrl}/positions${account?`?account=${account}`:''}`, { headers: this.headers() });
    return r.json();
  }
  async orders(limit=100, account?: string) {
    const r = await fetch(`${this.opts.baseUrl}/orders?limit=${limit}${account?`&account=${account}`:''}`, { headers: this.headers() });
    return r.json();
  }
  async order(symbol: string, side: "buy"|"sell", qty: number, account?: string) {
    const r = await fetch(`${this.opts.baseUrl}/order`, { method: "POST", headers: this.headers(), body: JSON.stringify({ symbol, side, qty, account }) });
    return r.json();
  }
  async orderBracket(symbol: string, side: "buy"|"sell", qty: number, sl: number, tp: number, account?: string) {
    const r = await fetch(`${this.opts.baseUrl}/order/bracket`, { method: "POST", headers: this.headers(), body: JSON.stringify({ symbol, side, qty, sl, tp, account }) });
    return r.json();
  }
  async pnl() {
    const r = await fetch(`${this.opts.baseUrl}/pnl`, { headers: this.headers() });
    return r.json();
  }
  async kill() {
    const r = await fetch(`${this.opts.baseUrl}/kill`, { method: "POST", headers: this.headers() });
    return r.json();
  }
  async backtest(csv: File | Blob) {
    const form = new FormData();
    form.append("file", csv, "data.csv");
    const r = await fetch(`${this.opts.baseUrl}/backtest`, { method: "POST", headers: this.headers({}), body: form as any });
    return r.json();
  }
  async updateConfig(patch: object) {
    const r = await fetch(`${this.opts.baseUrl}/config/update`, { method: "POST", headers: this.headers(), body: JSON.stringify(patch) });
    return r.json();
  }
}
