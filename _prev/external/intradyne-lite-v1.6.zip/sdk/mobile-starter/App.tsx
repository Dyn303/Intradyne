
import React, { useEffect, useState } from "react";
import { SafeAreaView, Text, Button, ScrollView, TextInput, View } from "react-native";

const BASE = "http://localhost:8000";
const API_KEY = "changeme";

export default function App() {
  const [health, setHealth] = useState<any>(null);
  const [price, setPrice] = useState<any>(null);
  const [symbol, setSymbol] = useState("BTC/USDT");
  const [qty, setQty] = useState("0.001");
  const [ticks, setTicks] = useState<any[]>([]);
  const [pnl, setPnl] = useState<any>(null);

  useEffect(() => {
    fetch(`${BASE}/health`, { headers: { "X-API-Key": API_KEY }}).then(r=>r.json()).then(setHealth);
    fetch(`${BASE}/price?symbol=${encodeURIComponent(symbol)}`, { headers: { "X-API-Key": API_KEY }}).then(r=>r.json()).then(setPrice);

    const wsTicks = new WebSocket(`${BASE.replace("http","ws")}/ws/ticks`);
    wsTicks.onmessage = (e) => setTicks(t => [JSON.parse(e.data), ...t].slice(0,50));
    const wsPnl = new WebSocket(`${BASE.replace("http","ws")}/ws/pnl`);
    wsPnl.onmessage = (e) => setPnl(JSON.parse(e.data));
    return () => { wsTicks.close(); wsPnl.close(); }
  }, []);

  const placeOrder = async (side: "buy"|"sell") => {
    await fetch(`${BASE}/order`, {
      method:"POST",
      headers: { "X-API-Key": API_KEY, "Content-Type":"application/json" },
      body: JSON.stringify({ symbol, side, qty: Number(qty) })
    });
  };

  return (
    <SafeAreaView style={{ flex: 1, padding: 16 }}>
      <ScrollView>
        <Text style={{ fontSize: 24, fontWeight: "bold" }}>IntraDyne Lite Mobile Starter</Text>
        <Text>health: {JSON.stringify(health)}</Text>
        <Text>price: {JSON.stringify(price)}</Text>

        <View style={{ flexDirection:"row", marginVertical: 8 }}>
          <TextInput style={{ borderWidth:1, flex:1, marginRight:8, padding:8 }} value={symbol} onChangeText={setSymbol} />
          <TextInput style={{ borderWidth:1, width:100, marginRight:8, padding:8 }} value={qty} onChangeText={setQty} keyboardType="numeric" />
          <Button title="Buy" onPress={()=>placeOrder("buy")} />
          <View style={{ width: 8 }} />
          <Button title="Sell" onPress={()=>placeOrder("sell")} />
        </View>

        <Button title="Kill-switch" onPress={()=>{
          fetch(`${BASE}/kill`, { method:"POST", headers: { "X-API-Key": API_KEY }})
        }} />

        <Text style={{ marginTop: 16, fontWeight:"bold" }}>Recent ticks:</Text>
        {ticks.map((t, i) => <Text key={i}>{JSON.stringify(t)}</Text>)}

        <Text style={{ marginTop: 16, fontWeight:"bold" }}>PnL snapshot:</Text>
        <Text>{JSON.stringify(pnl)}</Text>
      </ScrollView>
    </SafeAreaView>
  );
}
