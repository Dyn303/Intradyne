
# IntraDyne Lite Mobile Starter (Expo)

> Minimal client for testing the backend API. Not production-ready.

## Run
```bash
npm i -g expo-cli
npm i
npx expo start
```
Edit `App.tsx` to point to your API base URL and auth.
