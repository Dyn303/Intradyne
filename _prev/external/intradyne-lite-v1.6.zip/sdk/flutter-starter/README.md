
# IntraDyne Lite Flutter Starter

Minimal Flutter app to talk to the backend API and WS.

## Run
- Install Flutter SDK
- `flutter pub get`
- `flutter run`

Edit `lib/main.dart` to set your API base and credentials.
