
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:web_socket_channel/web_socket_channel.dart';

const base = 'http://localhost:8000';
const apiKey = 'changeme';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      home: HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  String health = '';
  String price = '';
  final symbolCtrl = TextEditingController(text: 'BTC/USDT');
  final qtyCtrl = TextEditingController(text: '0.001');
  final ticks = <String>[];
  late final WebSocketChannel wsTicks;
  late final WebSocketChannel wsPnl;

  @override
  void initState() {
    super.initState();
    http.get(Uri.parse('$base/health'), headers: {'X-API-Key': apiKey}).then((r){
      setState(()=> health = r.body);
    });
    http.get(Uri.parse('$base/price?symbol=BTC/USDT'), headers: {'X-API-Key': apiKey}).then((r){
      setState(()=> price = r.body);
    });
    wsTicks = WebSocketChannel.connect(Uri.parse(base.replaceFirst('http','ws') + '/ws/ticks'));
    wsTicks.stream.listen((msg){
      setState(()=> ticks.insert(0, msg));
      if (ticks.length > 50) ticks.removeLast();
    });
    wsPnl = WebSocketChannel.connect(Uri.parse(base.replaceFirst('http','ws') + '/ws/pnl'));
    wsPnl.stream.listen((msg){ /* show somewhere if desired */ });
  }

  @override
  void dispose() {
    wsTicks.sink.close();
    wsPnl.sink.close();
    super.dispose();
  }

  Future<void> placeOrder(String side) async {
    await http.post(Uri.parse('$base/order'),
      headers: {'X-API-Key': apiKey, 'Content-Type': 'application/json'},
      body: jsonEncode({'symbol': symbolCtrl.text, 'side': side, 'qty': double.tryParse(qtyCtrl.text) ?? 0}));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('IntraDyne Lite Flutter Starter')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('health: $health'),
            Text('price: $price'),
            const SizedBox(height: 8),
            Row(children: [
              Flexible(child: TextField(controller: symbolCtrl, decoration: const InputDecoration(labelText: 'Symbol'))),
              const SizedBox(width: 8),
              SizedBox(width: 120, child: TextField(controller: qtyCtrl, decoration: const InputDecoration(labelText: 'Qty'), keyboardType: TextInputType.number)),
              const SizedBox(width: 8),
              ElevatedButton(onPressed: ()=>placeOrder('buy'), child: const Text('Buy')),
              const SizedBox(width: 8),
              ElevatedButton(onPressed: ()=>placeOrder('sell'), child: const Text('Sell')),
            ]),
            const SizedBox(height: 12),
            const Text('Recent ticks:'),
            Expanded(child: ListView(children: ticks.map((t)=>Text(t)).toList())),
          ],
        ),
      ),
    );
  }
}
