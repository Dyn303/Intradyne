# IntraDyne Lite

A small-footprint, desktop-friendly trading bot scaffold designed to **avoid large datasets and AI retraining**.
It uses rule-based signals with lightweight analytics, a simple backtester on CSV OHLCV, Shariah screening, and
an exchange adapter interface you can connect to your broker later.

> **Scope**: reference implementation for education/paper trading. Use at your own risk.

## Install
```bash
python -m venv .venv && source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

## Quick Start (Backtest on CSV)
1) Drop a CSV file like `data/BTCUSDT_1h.csv` (columns: timestamp, open, high, low, close, volume).
2) Edit `config.yaml` (symbols, timeframes, cash, risk, filters).
3) Run:
```bash
python main.py backtest --config config.yaml --csv data/BTCUSDT_1h.csv
```

## Live/Paper (Connector Stub)
- Fill out `connectors/alpaca.py` or `connectors/ccxt_spot.py` with your keys.
- Switch `mode: live` in `config.yaml` and set `connector: alpaca` (or ccxt_spot).
- Use testnet where available.

## Shariah Screening
- Excludes prohibited sectors by keyword.
- Simple financial ratio heuristics (no debt/interest parsing—placeholder for your feed).

## Strategy
- Default: EMA cross + RSI gate + ATR-based position sizing and stops.
- No ML training required. Parameters are human-readable in `config.yaml`.

## Safety
- Daily max loss guard, per-trade R cap, cooldown after losses, and circuit breaker.
- Dry-run & paper modes available.

## Folder Map
```
intradyne_lite/
  __init__.py
  core/
    engine.py
    risk.py
    shariah.py
    storage.py
  strategies/
    ema_rsi_atr.py
  connectors/
    base.py
    ccxt_spot.py
    alpaca.py
  backtest/
    simulate.py
  utils/
    ohlcv.py
    logging.py
config.yaml
main.py
requirements.txt
data/   # put CSV here
```

## Roadmap
- Add broker adapters (IBKR, TDA, Futu) as needed.
- Plug-in sentiment toggle (optional tiny embedders, no retrain).
- Expand Shariah ratios if you add fundamentals feed.


---

## Live Loop (safe by default)
- Dry-run (`live.dry_run: true`) simulates entries/exits and PnL using live prices.
- Switch to live trading by setting `dry_run: false` after testing.

**Run:**
```bash
python main.py live --config config.yaml
```
Edit `live:` in `config.yaml`:
```yaml
live:
  symbol: "BTC/USDT"     # AAPL for stocks
  timeframe_sec: 60
  loop_sleep_sec: 2
  dry_run: true
  qty_mode: "risk"       # or "fixed"
  fixed_qty: 0.001
  equity_start: 10000
  bracket: true
```


---

## Dockerized Backend (no app yet)

**Build (choose extras you need only):**
```bash
# Crypto only
EXTRAS="ccxt" docker compose build

# Alpaca only
EXTRAS="alpaca-trade-api" docker compose build

# IBKR only
EXTRAS="ib-insync" docker compose build
```

**Backtest in Docker:**
```bash
# Put your CSV into ./data/, ensure config.yaml is set
MODE=backtest CSV=/app/data/BTCUSDT_1h.csv docker compose up
```

**Live (dry-run by default):**
```bash
# Edit config.yaml (connector, connector_cfg, live.dry_run=true initially)
MODE=live docker compose up
```

**Broker smoke test:**
```bash
MODE=broker_smoke SYMBOL=BTC/USDT EXTRAS="ccxt" docker compose up --build
```

Environment variables can also be put in `.env` (copy from `.env.example`).

**Note (IBKR):** you must run TWS or IB Gateway on the host and allow API connections; network access from the container must reach that host/port.


---

## Minimal HTTP API (backend-only, for your future mobile app)

**Run the API:**
```bash
# Build with the extras you need (e.g., ccxt)
EXTRAS="ccxt" docker compose build
MODE=api API_KEY=changeme docker compose up
```

**Call it:**
```bash
curl -H "X-API-Key: changeme" http://localhost:8000/health
curl -H "X-API-Key: changeme" http://localhost:8000/config
curl -H "X-API-Key: changeme" "http://localhost:8000/price?symbol=BTC/USDT"
curl -H "X-API-Key: changeme" -X POST http://localhost:8000/order   -H "Content-Type: application/json" -d '{"symbol":"AAPL","side":"buy","qty":1}'
curl -H "X-API-Key: changeme" http://localhost:8000/positions
```
Security: set `API_KEY` env and send `X-API-Key` header. Secrets in `/config` are redacted.


### API additions
- `GET /pnl` — last 30 ledger entries from SQLite metrics table.
- `POST /order/bracket` — native brackets when supported (Alpaca).

**Examples:**
```bash
curl -H "X-API-Key: changeme" http://localhost:8000/pnl

curl -H "X-API-Key: changeme" -X POST http://localhost:8000/order/bracket   -H "Content-Type: application/json"   -d '{"symbol":"AAPL","side":"buy","qty":1,"sl":175,"tp":185}'
```


### Auth & WebSockets
- **Auth**: either send `X-API-Key` **or** `Authorization: Bearer <JWT>`.
- Get a JWT token (when `JWT_SECRET` is set) via:
```bash
curl -H "X-API-Key: $API_KEY" -X POST http://localhost:8000/auth/token
```
- **WebSockets**:
  - `ws://localhost:8000/ws/ticks` → `{"t": 1736020000, "symbol":"BTC/USDT", "price": 60000.0}`
  - `ws://localhost:8000/ws/pnl` → `{"day":"2025-09-04","equity":10150.42}`

### Backtest runner API
```bash
curl -H "X-API-Key: changeme" -F "file=@data/BTCUSDT_1h.csv" http://localhost:8000/backtest
```

### Order audit
- API logs orders into SQLite `trades` with `order_id` when available.
- Alpaca sync: `POST /orders/sync/alpaca` pulls recent fills and updates records.


### New in v0.8
- `GET /orders?limit=100` — recent orders from SQLite `trades`.
- `POST /config/update` — shallow-merge config updates (**JWT required**).
- `WS /ws/positions` — streaming positions.
- Stubs: `POST /orders/sync/ccxt`, `POST /orders/sync/ibkr` (informative placeholders).
- **SDK**: `sdk/intradyne-lite-client.ts` for React Native / web.

**WS usage (browser example):**
```js
const ticks = new WebSocket("ws://localhost:8000/ws/ticks");
ticks.onmessage = (e) => console.log("tick", e.data);

const pnl = new WebSocket("ws://localhost:8000/ws/pnl");
pnl.onmessage = (e) => console.log("pnl", e.data);

const pos = new WebSocket("ws://localhost:8000/ws/positions");
pos.onmessage = (e) => console.log("positions", e.data);
```

**Config update (JWT required):**
```bash
curl -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json"   -d '{"live":{"dry_run":false}}' http://localhost:8000/config/update
```


### Webhooks (JWT required)
Register:
```bash
curl -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json"   -d '{"event":"order_placed","url":"https://webhook.site/your-id","secret":"abc"}'   http://localhost:8000/webhooks/register
```
List:
```bash
curl -H "Authorization: Bearer $TOKEN" http://localhost:8000/webhooks
```
Unregister:
```bash
curl -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json"   -d '{"event":"order_placed","url":"https://webhook.site/your-id"}'   http://localhost:8000/webhooks/unregister
```

Events: `order_placed`, `order_filled`, `kill`.

### Risk API
```bash
curl -H "Authorization: Bearer $TOKEN" http://localhost:8000/risk/limits
curl -H "Authorization: Bearer $TOKEN" http://localhost:8000/risk/summary
```

### Fills sync
```bash
# CCXT
curl -H "Authorization: Bearer $TOKEN" -X POST http://localhost:8000/orders/sync/ccxt
# IBKR
curl -H "Authorization: Bearer $TOKEN" -X POST http://localhost:8000/orders/sync/ibkr
```

### Positions WebSocket
- `ws://localhost:8000/ws/positions` → stream of connector `positions()`



### Webhook signatures
- We send `X-IntraDyne-Signature: <hex>` (HMAC-SHA256 over JSON body) if a webhook `secret` was provided.
- Verify on your receiver: compute HMAC of the raw body with the shared secret and compare.

### New endpoints
- `GET /orders/{id}` — lookup a single order by `order_id`
- `GET /positions/{symbol}` — filter positions
- `GET /risk/recent?days=14` — recent equity path

### CCXT fills (exchange-aware)
`POST /orders/sync/ccxt` now handles Binance/Bybit/Kraken param quirks and updates fills from both trades and orders.


### Order management
```bash
# Cancel by order id
curl -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json"   -d '{"order_id":"12345","symbol":"BTC/USDT"}' http://localhost:8000/orders/cancel

# Close position
curl -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json"   -d '{"symbol":"AAPL"}' http://localhost:8000/positions/close
```

### Push notifications (FCM)
- Set `FCM_SERVER_KEY` env.
- Register tokens (JWT required):
```bash
curl -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json"   -d '{"token":"<device-token>"}' http://localhost:8000/push/fcm/register
```
Events sent: `order_placed`, `order_filled`, `kill`.


### Paper / Live toggles
- Set `connector_cfg.paper: true` to use sandbox/testnet where supported:
  - **CCXT**: enables `set_sandbox_mode(True)` (for supported exchanges like Binance/Bybit testnets)
  - **Alpaca**: switches base URL to `https://paper-api.alpaca.markets`
  - **IBKR**: uses paper port `7497` (live `7496`)

### Rate limiting & API logs
- Env vars: `RL_RPS` (default 5), `RL_BURST` (default 10)
- Requests are logged to stdout with method/path/status/duration.

### Backtest artifacts
- Upload via `POST /backtest` and get `artifacts.trades_csv` & `artifacts.equity_png` links.
- List history: `GET /backtest/artifacts`
- Files are exposed under `/files/backtests/<run_id>/...`



## Multi-account / multi-broker (one device)
In `config.yaml`:
```yaml
accounts:
  - id: binance1
    type: ccxt_spot
    cfg:
      exchange_id: binance
      apiKey: "..."
      secret: "..."
      paper: true
    default_symbol: BTC/USDT
  - id: alpaca1
    type: alpaca
    cfg:
      key_id: "..."
      secret_key: "..."
      paper: true
    default_symbol: AAPL

# optional: which accounts to run in parallel for live trading
live_multi:
  accounts: [binance1, alpaca1]
```

### API usage with accounts
- `GET /accounts`
- `GET /price?symbol=BTC/USDT&account=binance1`
- `GET /positions?account=alpaca1`
- `POST /order {symbol, side, qty, account}`
- `POST /order/bracket {symbol, side, qty, sl, tp, account}`
- `GET /orders?account=alpaca1`

**WebSockets** (filter by account via query):
- `ws://localhost:8000/ws/ticks?account=binance1`
- `ws://localhost:8000/ws/positions?account=alpaca1`

### Live trading (multi-runner)
```bash
# run one container that spawns one live loop per listed account
MODE=live_multi docker compose up
```


### One device, many exchanges/brokers
- Define multiple **accounts** in `config.yaml` (see example above).
- Use `?account=<id>` (or `X-Account: <id>`) to route any request to that connector.
- WebSocket payloads include `account` so your mobile app can multiplex streams.



## v1.4 Additions
- **Per-account risk**: `GET /risk/summary?account=<id>` → risk/strategy per account.
- **Unified portfolio view**: `GET /portfolio` → aggregates positions across all accounts.
- **Account-scoped backtests**: `POST /backtest?account=<id>` (returns account in payload).
- **Health checks**: `GET /accounts/health` → tests all connectors, reports ok/error.


### v1.5 additions
- **Close all positions**: `POST /positions/close_all?account=<id>` closes every open symbol.
- **Unified equity dashboard**: `GET /equity/summary?days=30` → daily PnL rollups per account.
- **Request logs**: persisted in SQLite; view via `GET /admin/logs?limit=200`.
- **Portfolio refresh**: `POST /portfolio/refresh` → clears connector pool, next /portfolio rebuilds state.


### New in v1.5
- **Close everything**: `POST /positions/close_all?account=<id>`
- **Daily PnL & Equity**: `GET /pnl/daily?account=<id>&days=90&png=true`
- **Admin request logs (JWT only)**: `GET /admin/logs?limit=200&days=7&account=<id>`
- **Per-account rate limits**: limiter keys include `X-Account`/`?account=`
- **Portfolio refresh**: `GET /portfolio/refresh`


### Estimated daily profit % (returns)
- **Daily series**: `GET /pnl/daily?account=<id>&days=90&base=10000`  
  Returns `daily_pct` computed as `pnl_t / (base + cumulative_pnl_{t-1}) * 100`. If `base` not provided, tries `risk.starting_equity` or `capital.base` in config, else defaults to 10,000.
- **Summary stats**: `GET /pnl/summary?account=<id>&days=90&base=10000`  
  Returns `avg_daily_pct`, `median_daily_pct`, `stdev_daily_pct`, `win_rate_pct`, `cum_return_pct`, and a rough `estimated_CAGR_pct` (assumes 252 trading days).



### Estimated daily profit % (v1.6)
- **Capital inference**: uses `accounts[*].risk.capital`, else global `risk.capital`, else `10000` default.
- `GET /pnl/summary?account=<id>&days=60` → daily PnL & **daily %**, plus mean/stdev & Sharpe-like metric.
- `GET /pnl/estimate?account=<id>&days=60&ewma_lambda=0.94` → EWMA-based expected **daily %** and a volatility band.
