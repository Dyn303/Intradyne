
# IntraDyne Lite Changelog

## v1.6 — 2025-09-04
- **Estimated daily profit %** endpoints:
  - `/pnl/summary?account=&days=` → daily % with stats (mean/stdev/Sharpe-like).
  - `/pnl/estimate?account=&days=&ewma_lambda=` → EWMA mean/vol for daily % with 68% band.
- Capital inference: per-account `risk.capital` → global `risk.capital` → default 10,000.
- Carry-forward: bundles **v1.5** in `/_prev/v1.5/`.
