#!/usr/bin/env bash
set -euo pipefail

# MODE chooses which command to run:
# - backtest: needs CONFIG and CSV
# - live: needs CONFIG
MODE="${MODE:-help}"
CONFIG="${CONFIG:-config.yaml}"
CSV="${CSV:-}"
EXTRA_ARGS="${EXTRA_ARGS:-}"

echo "[entrypoint] MODE=$MODE CONFIG=$CONFIG CSV=$CSV"

case "$MODE" in
  live_multi)
    python -c "from intradyne_lite.live.multi import run_multi; run_multi('${CONFIG:-config.yaml}')" ;;

  api)
    exec uvicorn intradyne_lite.api.server:app --host 0.0.0.0 --port 8000
    ;;

  backtest)
    if [ -z "$CSV" ]; then
      echo "CSV not set. Use -e CSV=/app/data/YourFile.csv"; exit 2;
    fi
    exec python main.py backtest --config "$CONFIG" --csv "$CSV" $EXTRA_ARGS
    ;;
  live)
    exec python main.py live --config "$CONFIG" $EXTRA_ARGS
    ;;
  broker_smoke)
    SYMBOL="${SYMBOL:-AAPL}"
    SIDE_OPT=""
    if [ -n "${SIDE:-}" ]; then SIDE_OPT="--side $SIDE --qty ${QTY:-1}"; fi
    exec bash -lc "python main.py broker_smoke --config \"$CONFIG\" --symbol \"$SYMBOL\" $SIDE_OPT"
    ;;
  *)
    echo "Usage (env): MODE=backtest|live|broker_smoke CONFIG=config.yaml [CSV=...] [SYMBOL=...] [SIDE=buy|sell QTY=1]"
    ;;
esac
