
import math
from dataclasses import dataclass

@dataclass
class SimState:
    equity: float
    have_pos: bool=False
    entry: float=0.0
    qty: float=0.0
    sl: float=0.0
    tp: float=0.0

def size_by_risk(price, atr, equity, max_r, atr_mult_sl):
    risk_per_trade = equity * max_r
    stop_dist = atr * atr_mult_sl
    if stop_dist <= 0:
        return 0.0
    qty = risk_per_trade / stop_dist
    return max(0.0, qty)

def run(df, strat, risk_cfg):
    st = SimState(equity=10000.0)
    trades = []
    last_day = None

    for i, row in df.iterrows():
        day = row.timestamp.date()
        if last_day != day:
            last_day = day
            # Reset guards per day if needed

        # exit checks
        if st.have_pos:
            # SL/TP checks
            if row.low <= st.sl:
                pnl = (st.sl - st.entry) * st.qty
                st.equity += pnl
                trades.append(("stop", row.timestamp, st.entry, st.sl, st.qty, pnl))
                st.have_pos = False
                strat.stopped_out()
            elif row.high >= st.tp:
                pnl = (st.tp - st.entry) * st.qty
                st.equity += pnl
                trades.append(("take", row.timestamp, st.entry, st.tp, st.qty, pnl))
                st.have_pos = False

        # entry/exit signals
        action = strat.decide(row, st.have_pos)
        if action and action[0]=="buy" and not st.have_pos and row.atr>0:
            qty = size_by_risk(row.close, row.atr, st.equity, risk_cfg["max_r_per_trade"], risk_cfg["atr_mult_sl"])
            if qty>0:
                st.have_pos = True
                st.entry = row.close
                st.qty = qty
                st.sl = row.close - row.atr * risk_cfg["atr_mult_sl"]
                st.tp = row.close + row.atr * risk_cfg["atr_mult_tp"]
        elif action and action[0]=="sell" and st.have_pos:
            pnl = (row.close - st.entry) * st.qty
            st.equity += pnl
            trades.append(("close", row.timestamp, st.entry, row.close, st.qty, pnl))
            st.have_pos = False

    return st, trades
