
import pandas as pd
import numpy as np

def ema(series, span):
    return series.ewm(span=span, adjust=False).mean()

def rsi(series, length=14):
    delta = series.diff()
    up = delta.clip(lower=0)
    down = -delta.clip(upper=0)
    roll_up = up.ewm(alpha=1/length, adjust=False).mean()
    roll_down = down.ewm(alpha=1/length, adjust=False).mean()
    rs = roll_up / (roll_down + 1e-12)
    return 100 - (100 / (1 + rs))

def atr(df, length=14):
    high, low, close = df["high"], df["low"], df["close"]
    prev_close = close.shift(1)
    tr = np.maximum(high - low, np.maximum((high - prev_close).abs(), (low - prev_close).abs()))
    return tr.rolling(length).mean()

class Strategy:
    def __init__(self, params):
        self.p = params
        self.cooldown = 0

    def prepare(self, df):
        df = df.copy()
        df["ema_fast"] = ema(df["close"], self.p["fast_ema"])
        df["ema_slow"] = ema(df["close"], self.p["slow_ema"])
        df["rsi"] = rsi(df["close"], self.p["rsi_len"])
        df["atr"] = atr(df, self.p["atr_len"])
        return df

    def decide(self, row, have_pos):
        # Cooldown after stopped-out
        if self.cooldown > 0:
            self.cooldown -= 1
            return None

        buy = (row.ema_fast > row.ema_slow) and (row.rsi < self.p["rsi_buy_below"]) and not have_pos
        sell = (row.ema_fast < row.ema_slow) and (row.rsi > self.p["rsi_sell_above"]) and have_pos
        if buy:
            return ("buy", None)
        if sell:
            return ("sell", None)
        return None

    def stopped_out(self):
        self.cooldown = int(self.p.get("cooldown_bars_after_stop", 3))
