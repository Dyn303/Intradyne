
from fastapi import FastAPI, HTTPException, Header, Depends, Request
from starlette.middleware.base import BaseHTTPMiddleware
import sqlite3
from fastapi import WebSocket, WebSocketDisconnect, UploadFile, File, BackgroundTasks
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
import asyncio, time, jwt
import httpx
import hmac, hashlib as _hashlib, json as _json
from math import isnan
from datetime import datetime, timedelta, timezone
from intradyne_lite.backtest.simulate import run as sim_run
from intradyne_lite.strategies.ema_rsi_atr import Strategy
import pandas as pd
from pydantic import BaseModel
from typing import Optional
import os

from intradyne_lite.core.engine import load_config
from intradyne_lite.core.storage import Storage
from intradyne_lite.core.accounts import get_account, list_account_ids
from intradyne_lite.utils.logging import log

app = FastAPI(title="IntraDyne Lite API", version="0.1")

class RateLimitMiddleware(BaseHTTPMiddleware):
    def __init__(self, app):
        super().__init__(app)
        self.allowance = {}
    async def dispatch(self, request: Request, call_next):
        import time
        key = request.headers.get('X-API-Key') or request.headers.get('Authorization') or request.client.host
        rps = float(os.getenv('RL_RPS','5'))
        burst = float(os.getenv('RL_BURST','10'))
        now = time.time()
        bucket = self.allowance.get(key, {'allow': burst, 'ts': now})
        elapsed = now - bucket['ts']
        bucket['allow'] = min(burst, bucket['allow'] + elapsed * rps)
        bucket['ts'] = now
        if bucket['allow'] < 1.0:
            return FastAPI().Response(status_code=429, content='Rate limit exceeded')
        bucket['allow'] -= 1.0
        self.allowance[key] = bucket
        # request logging
        start = now
        response = await call_next(request)
        dur_ms = int((time.time()-start)*1000)
        print(f"[api] {request.method} {request.url.path} -> {response.status_code} ({dur_ms}ms)")
        # persist log
        try:
            cfg = load_config(os.getenv('CONFIG','config.yaml'))
            st = Storage(cfg['storage']['sqlite_path'])
            import hashlib
            raw_key = request.headers.get('X-API-Key') or request.headers.get('Authorization') or ''
            api_key_hash = hashlib.sha256(raw_key.encode('utf-8')).hexdigest() if raw_key else None
            acc = request.headers.get('X-Account') or request.query_params.get('account')
            from datetime import datetime, timezone
            st.log_request(datetime.now(timezone.utc).isoformat(), request.client.host if request.client else None, request.method, request.url.path, int(response.status_code), dur_ms, acc, api_key_hash)
        except Exception:
            pass
        return response
app.add_middleware(RateLimitMiddleware)

@app.middleware("http")
async def log_requests(request: Request, call_next):
    cfg = load_config(os.getenv("CONFIG","config.yaml"))
    path = request.url.path
    method = request.method
    aid = request.query_params.get('account') or request.headers.get('X-Account')
    start = dt.datetime.utcnow().isoformat()
    response = await call_next(request)
    status = response.status_code
    try:
        con = sqlite3.connect(cfg["storage"]["sqlite_path"])
        con.execute('''CREATE TABLE IF NOT EXISTS logs(ts TEXT, method TEXT, path TEXT, status INT, account TEXT)''')
        con.execute('INSERT INTO logs(ts,method,path,status,account) VALUES(?,?,?,?,?)', (start,method,path,status,aid))
        con.commit()
        con.close()
    except Exception as e:
        print('log error', e)
    return response



API_KEY = os.getenv("API_KEY","")



def _cfg_accounts(cfg: dict):
    # Returns list of accounts from config. Supports both single-connector legacy config and new multi-account structure.
    if isinstance(cfg.get("accounts"), list) and cfg["accounts"]:
        return cfg["accounts"]
    # legacy fallback: synthesize a single default account from top-level connector fields
    return [{
        "id": cfg.get("account_id", "default"),
        "connector": cfg.get("connector"),
        "connector_cfg": cfg.get("connector_cfg", {}),
        "live": cfg.get("live", {}),
    }]

def _choose_account_id(cfg: dict, account_id: str | None):
    accs = _cfg_accounts(cfg)
    if account_id:
        for a in accs:
            if a.get("id") == account_id:
                return account_id
        raise HTTPException(status_code=404, detail=f"Unknown account: {account_id}")
    if len(accs) == 1:
        return accs[0].get("id")
    # if multiple and none specified
    raise HTTPException(status_code=400, detail="Multiple accounts configured; specify ?account= or X-Account")

class BrokerPool:
    def __init__(self):
        self._lock = RLock()
        self._conns = {}  # account_id -> connector instance
        self._cfg_sig = None

    def _sig(self, cfg: dict):
        try:
            import hashlib, json
            return hashlib.sha256(json.dumps(cfg, sort_keys=True, default=str).encode("utf-8")).hexdigest()
        except Exception:
            return str(dt.datetime.now())

    def reload_if_changed(self, cfg: dict):
        sig = self._sig(_cfg_accounts(cfg))
        with self._lock:
            if sig != self._cfg_sig:
                self._cfg_sig = sig
                self._conns.clear()

    def get(self, cfg: dict, account_id: str):
        self.reload_if_changed(cfg)
        with self._lock:
            if account_id in self._conns:
                return self._conns[account_id]
            # build new connector from account section
            acc = next(a for a in _cfg_accounts(cfg) if a.get("id")==account_id)
            name = acc.get("connector")
            ccfg = acc.get("connector_cfg", {})
            conn = _build_connector(name, ccfg)
            self._conns[account_id] = conn
            return conn

    def list_accounts(self, cfg: dict):
        return [{"id": a.get("id"), "connector": a.get("connector"), "symbol": (a.get("live") or {}).get("symbol")} for a in _cfg_accounts(cfg)]

broker_pool = BrokerPool()

JWT_SECRET = os.getenv("JWT_SECRET","")
JWT_ALGO = "HS256"

def sign_jwt(sub: str, expires_minutes: int = 60):
    if not JWT_SECRET:
        raise HTTPException(status_code=500, detail="JWT_SECRET not configured")
    now = datetime.now(timezone.utc)
    payload = {"sub": sub, "iat": int(now.timestamp()), "exp": int((now + timedelta(minutes=expires_minutes)).timestamp())}
    return jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGO)

def verify_jwt(auth_header: str | None):
    if not JWT_SECRET:
        return True  # if not configured, skip JWT requirement
    if not auth_header or not auth_header.startswith("Bearer "):
        return False
    token = auth_header.split(" ",1)[1].strip()
    try:
        jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGO])
        return True
    except Exception:
        return False

def require_auth(x_api_key: Optional[str], authorization: Optional[str]):
    # either API key or valid JWT
    if API_KEY and x_api_key == API_KEY:
        return
    if verify_jwt(authorization):
        return
    raise HTTPException(status_code=401, detail="Unauthorized")


def require_key(x_api_key: Optional[str]):
    if not API_KEY:
        return
    if x_api_key != API_KEY:
        raise HTTPException(status_code=401, detail="Unauthorized")

def _build_connector(name, cfg):
    if name == "ccxt_spot":
        from intradyne_lite.connectors.ccxt_spot import CCXTSpot
        return CCXTSpot(cfg)
    if name == "alpaca":
        from intradyne_lite.connectors.alpaca import Alpaca
        return Alpaca(cfg)
    if name == "ibkr":
        from intradyne_lite.connectors.ibkr import IBKR
        return IBKR(cfg)
    raise HTTPException(status_code=400, detail=f"Unknown connector: {name}")

def _get_accounts(cfg: dict):
    accs = cfg.get("accounts")
    if accs and isinstance(accs, list):
        return accs
    # synthesize from legacy
    return [{
        "id": "default",
        "type": cfg.get("connector","none"),
        "cfg": cfg.get("connector_cfg", {}),
        "default_symbol": (cfg.get("live") or {}).get("symbol")
    }]

def _get_conn(cfg: dict, account_id: str | None):
    accs = _get_accounts(cfg)
    if account_id is None:
        if len(accs)==1:
            acc = accs[0]
        else:
            raise HTTPException(status_code=400, detail="account required (multiple accounts configured)")
    else:
        acc = next((a for a in accs if a.get("id")==account_id), None)
        if not acc:
            raise HTTPException(status_code=404, detail=f"account not found: {account_id}")
    return _build_connector(acc.get("type"), acc.get("cfg")), acc

class OrderReq(BaseModel):
    symbol: str
    side: str
    qty: float

class OrderBracketReq(BaseModel):
    symbol: str
    side: str
    qty: float
    sl: float
    tp: float
    account: Optional[str] = None
    account: Optional[str] = None

    symbol: str
    side: str   # "buy" or "sell"
    qty: float

@app.get("/health")
def health(x_api_key: Optional[str] = Header(None), authorization: Optional[str] = Header(None)):
    require_auth(x_api_key, authorization)
    return {"ok": True}

@app.get("/config")
def get_config(x_api_key: Optional[str] = Header(None), authorization: Optional[str] = Header(None)):
    require_auth(x_api_key, authorization)
    cfg_path = os.getenv("CONFIG","config.yaml")
    cfg = load_config(cfg_path)
    # redact secrets
    if "connector_cfg" in cfg:
        for k in ("apiKey","secret","password","key_id","secret_key"):
            if k in cfg["connector_cfg"]:
                cfg["connector_cfg"][k] = "***"
    return cfg

@app.get("/price")
def price(symbol: str, account: Optional[str] = None, x_api_key: Optional[str] = Header(None), authorization: Optional[str] = Header(None)):
    require_auth(x_api_key, authorization)
    cfg_path = os.getenv("CONFIG","config.yaml")
    cfg = load_config(cfg_path)
    conn, acc = _get_conn(cfg, account)
    p = conn.get_price(symbol)
    return {"symbol": symbol, "price": float(p), "account": acc.get('id')}

@app.get("/positions")
def positions(account: Optional[str] = None, x_api_key: Optional[str] = Header(None), authorization: Optional[str] = Header(None)):
    require_auth(x_api_key, authorization)
    cfg_path = os.getenv("CONFIG","config.yaml")
    cfg = load_config(cfg_path)
    conn, acc = _get_conn(cfg, account)
    return {"positions": conn.positions(), "account": acc.get('id')}

@app.post("/order")
def order(req: OrderReq, x_api_key: Optional[str] = Header(None), authorization: Optional[str] = Header(None)):
    require_auth(x_api_key, authorization)
    if req.side not in ("buy","sell"):
        raise HTTPException(status_code=400, detail="side must be 'buy' or 'sell'")
    cfg_path = os.getenv("CONFIG","config.yaml")
    cfg = load_config(cfg_path)
    conn, acc = _get_conn(cfg, account)
    resp = conn.place_order(req.symbol, req.side, float(req.qty), None, None, None)
    log_order_to_db(cfg, resp, req.symbol, req.side, float(req.qty))
    log_order_to_db(cfg, resp, req.symbol, req.side, float(req.qty), None, float(req.sl), float(req.tp))
    asyncio.create_task(dispatch_webhooks(cfg, "order_placed", {"resp": resp, "symbol": req.symbol, "side": req.side, "qty": float(req.qty)}))
    asyncio.create_task(dispatch_push_fcm(cfg, "Order placed", f"{req.side} {req.symbol}", {"qty": float(req.qty)}))
    return {"ok": True, "resp": resp}

KILL_FILE = "/tmp/intradyne_kill"

@app.post("/kill")
def kill(x_api_key: Optional[str] = Header(None), authorization: Optional[str] = Header(None)):
    require_auth(x_api_key, authorization)
    # create a file that the live loop could check in future refinement
    open(KILL_FILE,"w").write("1")
    cfg = load_config(os.getenv("CONFIG","config.yaml"))
    asyncio.create_task(dispatch_webhooks(cfg, "kill", {"ts": int(time.time())}))
    asyncio.create_task(dispatch_push_fcm(cfg, "Kill-switch", "Live loop stopped", {}))
    return {"ok": True}

@app.get("/pnl")
def pnl(x_api_key: Optional[str] = Header(None)):
    require_auth(x_api_key, authorization)
    cfg_path = os.getenv("CONFIG","config.yaml")
    cfg = load_config(cfg_path)
    st = Storage(cfg["storage"]["sqlite_path"])
    # Return last 30 metrics rows
    import sqlite3
    con = sqlite3.connect(cfg["storage"]["sqlite_path"])
    cur = con.cursor()
    cur.execute("SELECT day, equity, drawdown, notes FROM metrics ORDER BY id DESC LIMIT 30")
    rows = [{"day": d, "equity": e, "drawdown": dd, "notes": n} for (d,e,dd,n) in cur.fetchall()]
    con.close()
    return {"metrics": rows}

@app.post("/order/bracket")
def order_bracket(req: OrderBracketReq, x_api_key: Optional[str] = Header(None)):
    require_auth(x_api_key, authorization)
    if req.side not in ("buy","sell"):
        raise HTTPException(status_code=400, detail="side must be 'buy' or 'sell'")
    cfg_path = os.getenv("CONFIG","config.yaml")
    cfg = load_config(cfg_path)
    conn, acc = _get_conn(cfg, account)
    resp = conn.place_order(req.symbol, req.side, float(req.qty), None, float(req.sl), float(req.tp))
    log_order_to_db(cfg, resp, req.symbol, req.side, float(req.qty), None, float(req.sl), float(req.tp))
    asyncio.create_task(dispatch_webhooks(cfg, "order_placed", {"resp": resp, "symbol": req.symbol, "side": req.side, "qty": float(req.qty)}))
    asyncio.create_task(dispatch_push_fcm(cfg, "Order placed", f"{req.side} {req.symbol}", {"qty": float(req.qty)}))
    return {"ok": True, "resp": resp}

@app.post("/auth/token")
def issue_token(x_api_key: Optional[str] = Header(None)):
    if not API_KEY:
        raise HTTPException(status_code=400, detail="API_KEY not set on server")
    if x_api_key != API_KEY:
        raise HTTPException(status_code=401, detail="Unauthorized")
    return {"token": sign_jwt("mobile")}

def log_order_to_db(cfg, resp, symbol, side, qty, price=None, sl=None, tp=None):
    try:
        st = Storage(cfg["storage"]["sqlite_path"])
        ts = datetime.now(timezone.utc).isoformat()
        # best-effort order_id extraction
        order_id = None
        if isinstance(resp, dict):
            order_id = resp.get("id") or resp.get("orderId") or resp.get("client_order_id")
        st.log_trade_order(ts=ts, symbol=symbol, side=side, qty=qty, price=price, sl=sl, tp=tp, notes="placed", order_id=order_id)
    except Exception as e:
        log("DB order log failed:", str(e))

@app.post("/backtest")
async def backtest(x_api_key: Optional[str] = Header(None), authorization: Optional[str] = Header(None), file: UploadFile = File(...), account: Optional[str] = None):
    require_auth(x_api_key, authorization)
    import io
    data = await file.read()
    df = pd.read_csv(io.BytesIO(data))
    # normalize columns
    df.columns = [c.lower() for c in df.columns]
    for c in ("timestamp","open","high","low","close","volume"):
        if c not in df.columns:
            raise HTTPException(status_code=400, detail=f"CSV missing column: {c}")
    df["timestamp"] = pd.to_datetime(df["timestamp"], utc=True, errors="coerce")
    df = df.dropna(subset=["timestamp"]).sort_values("timestamp").reset_index(drop=True)
    cfg_path = os.getenv("CONFIG","config.yaml")
    cfg = load_config(cfg_path)
    prepared = Strategy(cfg["strategy"]["params"]).prepare(df)
    strategy = Strategy(cfg["strategy"]["params"])
    state, trades = sim_run(prepared, strategy, {
        "max_r_per_trade": cfg["risk"]["max_r_per_trade"],
        "atr_mult_sl": cfg["strategy"]["params"]["atr_mult_sl"],
        "atr_mult_tp": cfg["strategy"]["params"]["atr_mult_tp"],
    })
    wins = sum(1 for t in trades if t[0] in ("take","close") and t[-1]>0)
    losses = sum(1 for t in trades if t[0] in ("stop","close") and t[-1]<=0)
    # Save artifacts
    import os, matplotlib.pyplot as plt
    run_id = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    outdir = f"/app/data/backtests/{run_id}"
    os.makedirs(outdir, exist_ok=True)
    # trades CSV
    import csv
    with open(f"{outdir}/trades.csv","w",newline="") as fcsv:
        w = csv.writer(fcsv)
        w.writerow(["event","ts","price","qty","pnl"])
        for ev in trades:
            w.writerow(list(ev))
    # equity curve (naive cumulative PnL)
    eq = [0.0]
    for ev in trades:
        try:
            eq.append(eq[-1] + float(ev[-1]))
        except Exception:
            eq.append(eq[-1])
    plt.figure()
    plt.plot(eq)
    plt.title('Equity (cumulative PnL events)')
    plt.xlabel('Trade #')
    plt.ylabel('PnL')
    plt.tight_layout()
    plt.savefig(f"{outdir}/equity.png")
    plt.close()
    links = {
        "trades_csv": f"/files/backtests/{run_id}/trades.csv",
        "equity_png": f"/files/backtests/{run_id}/equity.png"
    }
    return {"equity": float(state.equity), "trades": len(trades), "wins": wins, "losses": losses, "artifacts": links, "run_id": run_id, "account": account}

@app.post("/orders/sync/alpaca")
def orders_sync_alpaca(x_api_key: Optional[str] = Header(None), authorization: Optional[str] = Header(None), account: Optional[str] = None):
    require_auth(x_api_key, authorization)
    cfg_path = os.getenv("CONFIG","config.yaml")
    cfg = load_config(cfg_path)
    acc_conn, acc = _get_conn(cfg, account)
    if acc.get("type") != "alpaca":
        raise HTTPException(status_code=400, detail="Connector is not Alpaca")
    from intradyne_lite.connectors.alpaca import Alpaca
    conn = Alpaca(acc.get("cfg", {}))
    orders = conn.list_orders(status="all", limit=50)
    st = Storage(cfg["storage"]["sqlite_path"])
    updated = 0
    if isinstance(orders, list):
        for o in orders:
            oid = o.get("id") if isinstance(o, dict) else None
            filled_qty = float(o.get("filled_qty", 0) or 0) if isinstance(o, dict) else 0.0
            avg_price = float(o.get("filled_avg_price", 0) or 0) if isinstance(o, dict) else None
            status = o.get("status") if isinstance(o, dict) else ""
            if oid and avg_price and filled_qty:
                try:
                    st.update_trade_fill(order_id=oid, fill_price=avg_price, filled_qty=filled_qty, notes=f"fill:{status}", account=acc.get('id'))
                    updated += 1
                except Exception:
                    pass
    if updated>0:
        asyncio.create_task(dispatch_webhooks(cfg, "order_filled", {"updated": updated}))
        asyncio.create_task(dispatch_push_fcm(cfg, "Order filled", "fills updated", {"updated": updated}))
    return {"updated": updated, "count": len(orders) if isinstance(orders, list) else 0}

class Hub:
    def __init__(self):
        self.clients = {}
    async def connect(self, ws: WebSocket, filt: dict | None = None):
        await ws.accept()
        self.clients[ws] = filt or {}
    def disconnect(self, ws: WebSocket):
        self.clients.pop(ws, None)
    async def broadcast(self, payload: dict):
        for ws, filt in list(self.clients.items()):
            try:
                if filt and 'account' in filt and payload.get('account') != filt.get('account'):
                    continue
                await ws.send_json(payload)
            except Exception:
                self.clients.pop(ws, None)

ticks_hub = Hub()
pnl_hub = Hub()
positions_hub = Hub()

@app.websocket("/ws/ticks")
async def ws_ticks(ws: WebSocket):
    q = dict([p.split('=') for p in (ws.url.query or '').split('&') if '=' in p])
    await ticks_hub.connect(ws, {'account': q.get('account')})
    try:
        while True:
            await asyncio.sleep(3600)  # keep alive; actual data comes from background
    except WebSocketDisconnect:
        ticks_hub.disconnect(ws)

@app.websocket("/ws/pnl")
async def ws_pnl(ws: WebSocket):
    q = dict([p.split('=') for p in (ws.url.query or '').split('&') if '=' in p])
    await pnl_hub.connect(ws, {'account': q.get('account')})
    try:
        while True:
            await asyncio.sleep(3600)
    except WebSocketDisconnect:
        pnl_hub.disconnect(ws)

async def bg_broadcast_task():
    await asyncio.sleep(1.0)
    cfg_path = os.getenv("CONFIG","config.yaml")
    cfg = load_config(cfg_path)
    try:
        conn, acc = _get_conn(cfg, account)
    except Exception:
        conn = None
    symbol = (cfg.get("live") or {}).get("symbol") or (cfg.get("symbols") or ["BTC/USDT"])[0]
    st = Storage(cfg["storage"]["sqlite_path"])
    while True:
        try:
            if conn and symbol:
                p = conn.get_price(symbol)
                await ticks_hub.broadcast({"t": int(time.time()), "symbol": symbol, "price": float(p), \"account\": acct_id})
        except Exception:
            pass
        # PnL metrics (last row)
        # Positions
        try:
            if conn:
                poss = conn.positions()
                await positions_hub.broadcast({"account": acct_id, "positions": poss})
        except Exception:
            pass

        # PnL metrics (last row)
        try:
            import sqlite3
            con = sqlite3.connect(cfg["storage"]["sqlite_path"])
            cur = con.cursor()
            cur.execute("SELECT day, equity FROM metrics ORDER BY id DESC LIMIT 1")
            row = cur.fetchone()
            con.close()
            if row:
                await pnl_hub.broadcast({"day": row[0], "equity": row[1]})
        except Exception:
            pass
        await asyncio.sleep(2.0)

app.mount('/files', StaticFiles(directory='/app/data'), name='files')

@app.on_event("startup")
async def on_start():
    asyncio.create_task(bg_broadcast_task())

@app.post("/config/update")
def config_update(payload: dict, x_api_key: Optional[str] = Header(None), authorization: Optional[str] = Header(None)):
    # Require JWT (stronger auth) to allow config writes
    if not verify_jwt(authorization or ""):
        raise HTTPException(status_code=401, detail="JWT required")
    cfg_path = os.getenv("CONFIG","config.yaml")
    # Load, shallow merge, and write back
    import yaml
    with open(cfg_path,"r") as f:
        cfg = yaml.safe_load(f)
    if not isinstance(payload, dict):
        raise HTTPException(status_code=400, detail="Invalid payload")
    # shallow merge
    for k,v in payload.items():
        if isinstance(v, dict) and isinstance(cfg.get(k), dict):
            cfg[k].update(v)
        else:
            cfg[k] = v
    with open(cfg_path,"w") as f:
        yaml.safe_dump(cfg, f, sort_keys=False)
    return {"ok": True}

@app.websocket("/ws/positions")
async def ws_positions(ws: WebSocket):
    q = dict([p.split('=') for p in (ws.url.query or '').split('&') if '=' in p])
    await positions_hub.connect(ws, {'account': q.get('account')})
    try:
        while True:
            await asyncio.sleep(3600)
    except WebSocketDisconnect:
        positions_hub.disconnect(ws)

@app.post("/orders/sync/ccxt")
def orders_sync_ccxt(x_api_key: Optional[str] = Header(None), authorization: Optional[str] = Header(None), account: Optional[str] = None):
    require_auth(x_api_key, authorization)
    # Not all CCXT exchanges support unified fetchMyTrades/fetchOrders consistently.
    # This is a placeholder that returns an informative message.
    
cfg_path = os.getenv("CONFIG","config.yaml")
cfg = load_config(cfg_path)
acc_conn, acc = _get_conn(cfg, account)
    if acc.get("type") != "ccxt_spot":
    raise HTTPException(status_code=400, detail="Connector is not CCXT Spot")
from intradyne_lite.connectors.ccxt_spot import CCXTSpot
conn = CCXTSpot(acc.get("cfg", {}))
symbol = (acct.get("live") or {}).get("symbol") or None
updated = 0
# Try trades first
try:
    trades = conn.ex.fetch_my_trades(symbol) if symbol else conn.ex.fetch_my_trades()
except Exception:
    trades = []
st = Storage(cfg["storage"]["sqlite_path"])
for tr in (trades or []):
    oid = tr.get("order")
    price = float(tr.get("price") or 0)
    amount = float(tr.get("amount") or 0)
    if oid and price and amount:
        try:
            st.update_trade_fill(order_id=str(oid), fill_price=price, filled_qty=amount, notes="fill:ccxt")
            updated += 1
        except Exception:
            pass
# Then closed orders if available
try:
    orders = conn.ex.fetch_orders(symbol) if symbol else conn.ex.fetch_orders()
except Exception:
    orders = []
for o in (orders or []):
    oid = o.get("id")
    filled = float(o.get("filled") or 0)
    avg = o.get("average")
    if oid and filled and avg:
        try:
            st.update_trade_fill(order_id=str(oid), fill_price=float(avg), filled_qty=filled, notes=f"fill:{o.get('status','closed')}")
            updated += 1
        except Exception:
            pass
if updated>0:
    asyncio.create_task(dispatch_webhooks(cfg, "order_filled", {"updated": updated}))
        asyncio.create_task(dispatch_push_fcm(cfg, "Order filled", "fills updated", {"updated": updated}))
return {"updated": updated, "trades_checked": len(trades or []), "orders_checked": len(orders or [])}


@app.post("/orders/sync/ibkr")
def orders_sync_ibkr(x_api_key: Optional[str] = Header(None), authorization: Optional[str] = Header(None), account: Optional[str] = None):
    require_auth(x_api_key, authorization)
    # ib_insync requires event-driven fills; Lite build does not run a persistent IB event loop here.
    
cfg_path = os.getenv("CONFIG","config.yaml")
cfg = load_config(cfg_path)
acc_conn, acc = _get_conn(cfg, account)
    if acc.get("type") != "ibkr":
    raise HTTPException(status_code=400, detail="Connector is not IBKR")
from intradyne_lite.connectors.ibkr import IBKR
ib = IBKR(acc.get("cfg", {}))
# Fetch today's executions
try:
    fills = ib.ib.fills()
except Exception:
    fills = []
st = Storage(cfg["storage"]["sqlite_path"])
updated = 0
for f in (fills or []):
    oid = getattr(f.execution, "orderId", None)
    price = getattr(f.execution, "price", None)
    shares = getattr(f.execution, "shares", None)
    if oid and price and shares:
        try:
            st.update_trade_fill(order_id=str(oid), fill_price=float(price), filled_qty=float(shares), notes="fill:ibkr", account=acc.get('id'))
            updated += 1
        except Exception:
            pass
if updated>0:
    asyncio.create_task(dispatch_webhooks(cfg, "order_filled", {"updated": updated}))
        asyncio.create_task(dispatch_push_fcm(cfg, "Order filled", "fills updated", {"updated": updated}))
return {"updated": updated, "fills_checked": len(fills or [])}


async def dispatch_webhooks(cfg, event: str, payload: dict):
    st = Storage(cfg["storage"]["sqlite_path"])
    subs = st.list_webhooks(event)
    async with httpx.AsyncClient(timeout=10) as client:
        for sub in subs:
            try:
                body = {"event": event, "payload": payload}
                secret = (sub.get("secret","") or "").encode("utf-8")
                raw = _json.dumps(body, separators=(",",":")).encode("utf-8")
                sig = hmac.new(secret, raw, _hashlib.sha256).hexdigest() if secret else ""
                headers = {"X-IntraDyne-Signature": sig} if sig else {}
                await client.post(sub["url"], json=body, headers=headers)
                await client.post(sub["url"], json=data)
            except Exception as e:
                log("Webhook dispatch failed", sub["url"], str(e))

@app.post("/webhooks/register")
def webhook_register(payload: dict, x_api_key: Optional[str] = Header(None), authorization: Optional[str] = Header(None)):
    if not verify_jwt(authorization or ""):
        raise HTTPException(status_code=401, detail="JWT required")
    event = payload.get("event"); url = payload.get("url"); secret = payload.get("secret","")
    if not event or not url:
        raise HTTPException(status_code=400, detail="event and url required")
    cfg_path = os.getenv("CONFIG","config.yaml")
    cfg = load_config(cfg_path)
    st = Storage(cfg["storage"]["sqlite_path"])
    st.register_webhook(event, url, secret)
    return {"ok": True}

@app.post("/webhooks/unregister")
def webhook_unregister(payload: dict, x_api_key: Optional[str] = Header(None), authorization: Optional[str] = Header(None)):
    if not verify_jwt(authorization or ""):
        raise HTTPException(status_code=401, detail="JWT required")
    event = payload.get("event"); url = payload.get("url")
    if not event or not url:
        raise HTTPException(status_code=400, detail="event and url required")
    cfg_path = os.getenv("CONFIG","config.yaml")
    cfg = load_config(cfg_path)
    st = Storage(cfg["storage"]["sqlite_path"])
    st.unregister_webhook(event, url)
    return {"ok": True}

@app.get("/webhooks")
def webhook_list(x_api_key: Optional[str] = Header(None), authorization: Optional[str] = Header(None)):
    if not verify_jwt(authorization or ""):
        raise HTTPException(status_code=401, detail="JWT required")
    cfg_path = os.getenv("CONFIG","config.yaml")
    cfg = load_config(cfg_path)
    st = Storage(cfg["storage"]["sqlite_path"])
    return {"webhooks": st.list_webhooks()}

@app.get("/risk/limits")
def risk_limits(x_api_key: Optional[str] = Header(None), authorization: Optional[str] = Header(None)):
    require_auth(x_api_key, authorization)
    cfg = load_config(os.getenv("CONFIG","config.yaml"))
    return {"risk": cfg.get("risk", {}), "strategy": cfg.get("strategy", {})}

@app.get("/risk/summary")
def risk_summary(x_api_key: Optional[str] = Header(None), authorization: Optional[str] = Header(None)):
    require_auth(x_api_key, authorization)
    cfg_path = os.getenv("CONFIG","config.yaml")
    cfg = load_config(cfg_path)
    # Realized PnL (sum of trades with pnl field) - simplistic for Lite
    import sqlite3
    con = sqlite3.connect(cfg["storage"]["sqlite_path"])
    cur = con.cursor()
    cur.execute("SELECT COALESCE(SUM(pnl),0) FROM trades WHERE pnl IS NOT NULL")
    realized = cur.fetchone()[0] or 0.0
    # Equity path & MDD from metrics table
    cur.execute("SELECT equity FROM metrics ORDER BY id ASC")
    rows = [r[0] for r in cur.fetchall() if r[0] is not None]
    con.close()
    max_equity = 0.0
    mdd = 0.0
    for e in rows:
        if e>max_equity: max_equity = e
        dd = (max_equity - e) / max_equity if max_equity>0 else 0
        if dd>mdd: mdd = dd
    # Exposure placeholder via connector positions notional if available
    try:
        conn, acc = _get_conn(cfg, account)
        poss = conn.positions()
    except Exception:
        poss = {}
    return {"realized_pnl": realized, "max_drawdown": mdd, "positions": poss}

@app.get("/positions/{symbol}")
def position_by_symbol(symbol: str, account: Optional[str] = None, x_api_key: Optional[str] = Header(None), authorization: Optional[str] = Header(None)):
    require_auth(x_api_key, authorization)
    cfg = load_config(os.getenv("CONFIG","config.yaml"))
    conn, acc = _get_conn(cfg, account)
    poss = conn.positions()
    # try to filter
    if isinstance(poss, list):
        out = [p for p in poss if (p.get("symbol") == symbol or p.get("asset") == symbol or p.get("contract",{}).get("symbol")==symbol)]
        return {"positions": out}
    return {"positions": poss}

@app.get("/risk/recent")
def risk_recent(days: int = 14, x_api_key: Optional[str] = Header(None), authorization: Optional[str] = Header(None)):
    require_auth(x_api_key, authorization)
    cfg = load_config(os.getenv("CONFIG","config.yaml"))
    import sqlite3, datetime as _dt
    since = (_dt.datetime.utcnow() - _dt.timedelta(days=days)).strftime("%Y-%m-%d")
    con = sqlite3.connect(cfg["storage"]["sqlite_path"])
    cur = con.cursor()
    cur.execute("SELECT day, equity, drawdown FROM metrics WHERE day>=? ORDER BY day ASC", (since,))
    rows = [{"day": d, "equity": e, "drawdown": dd} for (d,e,dd) in cur.fetchall()]
    con.close()
    return {"metrics": rows}

def ensure_push_fcm(st: Storage):
    st.ensure_webhooks()
    # also ensure push_fcm table
    import sqlite3
    with st._conn() as con:
        con.execute('''CREATE TABLE IF NOT EXISTS push_fcm(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            token TEXT,
            created_ts TEXT
        )''')

@app.post("/push/fcm/register")
def fcm_register(payload: dict, x_api_key: Optional[str] = Header(None), authorization: Optional[str] = Header(None)):
    if not verify_jwt(authorization or ""):
        raise HTTPException(status_code=401, detail="JWT required")
    token = payload.get("token")
    if not token:
        raise HTTPException(status_code=400, detail="token required")
    cfg = load_config(os.getenv("CONFIG","config.yaml"))
    st = Storage(cfg["storage"]["sqlite_path"])
    ensure_push_fcm(st)
    from datetime import datetime, timezone
    with st._conn() as con:
        con.execute("INSERT INTO push_fcm(token,created_ts) VALUES(?,?)", (token, datetime.now(timezone.utc).isoformat()))
    return {"ok": True}

@app.get("/push/fcm")
def fcm_list(x_api_key: Optional[str] = Header(None), authorization: Optional[str] = Header(None)):
    if not verify_jwt(authorization or ""):
        raise HTTPException(status_code=401, detail="JWT required")
    cfg = load_config(os.getenv("CONFIG","config.yaml"))
    st = Storage(cfg["storage"]["sqlite_path"])
    ensure_push_fcm(st)
    with st._conn() as con:
        rows = con.execute("SELECT token, created_ts FROM push_fcm ORDER BY id DESC").fetchall()
    return {"tokens": [{"token": r[0], "created_ts": r[1]} for r in rows]}

async def dispatch_push_fcm(cfg, title: str, body: str, data: dict):
    key = os.getenv("FCM_SERVER_KEY","")
    if not key:
        return
    st = Storage(cfg["storage"]["sqlite_path"])
    ensure_push_fcm(st)
    tokens = []
    with st._conn() as con:
        tokens = [r[0] for r in con.execute("SELECT token FROM push_fcm").fetchall()]
    if not tokens:
        return
    payload = {
        "registration_ids": tokens,
        "notification": {"title": title, "body": body},
        "data": data,
    }
    headers = {"Authorization": f"key={key}", "Content-Type": "application/json"}
    async with httpx.AsyncClient(timeout=10) as client:
        try:
            await client.post("https://fcm.googleapis.com/fcm/send", json=payload, headers=headers)
        except Exception as e:
            log("FCM push failed:", str(e))

class CancelReq(BaseModel):
    order_id: str
    symbol: Optional[str] = None
    account: Optional[str] = None

@app.post("/orders/cancel")
def orders_cancel(req: CancelReq, x_api_key: Optional[str] = Header(None), authorization: Optional[str] = Header(None)):
    require_auth(x_api_key, authorization)
    cfg = load_config(os.getenv("CONFIG","config.yaml"))
    conn, acc = _get_conn(cfg, account)
    if hasattr(conn, "cancel_order"):
        return conn.cancel_order(req.order_id, req.symbol) if req.symbol is not None else conn.cancel_order(req.order_id)
    raise HTTPException(status_code=400, detail="Connector does not support cancel_order")

class CloseReq(BaseModel):
    symbol: str
    account: Optional[str] = None

@app.post("/positions/close")
def positions_close(req: CloseReq, x_api_key: Optional[str] = Header(None), authorization: Optional[str] = Header(None)):
    require_auth(x_api_key, authorization)
    cfg = load_config(os.getenv("CONFIG","config.yaml"))
    conn, acc = _get_conn(cfg, account)
    if hasattr(conn, "close_position"):
        return conn.close_position(req.symbol)
    raise HTTPException(status_code=400, detail="Connector does not support close_position")

@app.get("/backtest/artifacts")
def backtest_artifacts(x_api_key: Optional[str] = Header(None), authorization: Optional[str] = Header(None)):
    require_auth(x_api_key, authorization)
    root = "/app/data/backtests"
    out = []
    try:
        for d in sorted(os.listdir(root)):
            p = os.path.join(root, d)
            if os.path.isdir(p):
                out.append({"run_id": d, "trades_csv": f"/files/backtests/{d}/trades.csv", "equity_png": f"/files/backtests/{d}/equity.png"})
    except Exception:
        pass
    return {"runs": out}


def _pick_account(x_api_key: Optional[str], authorization: Optional[str], account: Optional[str] = None, x_account: Optional[str] = None):
    # auth is validated by route; we just read account hints
    aid = x_account or account
    cfg_path = os.getenv("CONFIG","config.yaml")
    cfg = load_config(cfg_path)
    return cfg, _choose_account_id(cfg, aid)

@app.get("/accounts")
def accounts(x_api_key: Optional[str] = Header(None), authorization: Optional[str] = Header(None)):
    require_auth(x_api_key, authorization)
    cfg = load_config(os.getenv("CONFIG","config.yaml"))
    return {"accounts": _get_accounts(cfg)}

def _choose_conn(cfg, account_id: Optional[str]):
    acct = get_account(cfg, account_id)
    return _build_connector(acct.get("connector"), acct.get("connector_cfg")), acct

@app.get("/risk/summary")
def risk_summary(x_api_key: Optional[str] = Header(None), authorization: Optional[str] = Header(None), account: Optional[str] = None):
    require_auth(x_api_key, authorization)
    cfg = load_config(os.getenv("CONFIG","config.yaml"))
    from intradyne_lite.core.accounts import get_account, normalize_accounts
    if account:
        acct = get_account(cfg, account)
        # stub risk per account
        return {"account": acct.get("id"), "risk": cfg.get("risk", {}), "strategy": cfg.get("strategy", {})}
    else:
        accts = normalize_accounts(cfg)
        out = []
        for a in accts:
            out.append({"account": a.get("id"), "risk": cfg.get("risk", {}), "strategy": cfg.get("strategy", {})})
        return {"accounts": out}

@app.get("/portfolio")
def portfolio(x_api_key: Optional[str] = Header(None), authorization: Optional[str] = Header(None)):
    require_auth(x_api_key, authorization)
    cfg = load_config(os.getenv("CONFIG","config.yaml"))
    from intradyne_lite.core.accounts import normalize_accounts
    summary = []
    for a in normalize_accounts(cfg):
        try:
            conn = _build_connector(a.get("connector"), a.get("connector_cfg"))
            poss = conn.positions()
            summary.append({"account": a.get("id"), "positions": poss})
        except Exception as e:
            summary.append({"account": a.get("id"), "error": str(e)})
    return {"portfolio": summary}

@app.get("/accounts/health")
async def account_health(x_api_key: Optional[str] = Header(None), authorization: Optional[str] = Header(None)):
    require_auth(x_api_key, authorization)
    cfg = load_config(os.getenv("CONFIG","config.yaml"))
    from intradyne_lite.core.accounts import normalize_accounts
    health = []
    for a in normalize_accounts(cfg):
        try:
            conn = _build_connector(a.get("connector"), a.get("connector_cfg"))
            _ = conn.get_price((a.get("live") or {}).get("symbol"))
            health.append({"account": a.get("id"), "ok": True})
        except Exception as e:
            health.append({"account": a.get("id"), "ok": False, "error": str(e)})
    return {"health": health}


@app.post("/positions/close_all")
def positions_close_all(x_api_key: Optional[str] = Header(None), authorization: Optional[str] = Header(None), account: Optional[str] = None):
    require_auth(x_api_key, authorization)
    cfg = load_config(os.getenv("CONFIG","config.yaml"))
    conn, acct = _choose_conn(cfg, account)
    results = []
    try:
        poss = conn.positions()
        for p in poss or []:
            sym = p.get("symbol") or p.get("asset") or (p.get("contract") or {}).get("symbol")
            if not sym:
                continue
            try:
                res = conn.close_position(sym)
            except Exception as e:
                res = {"error": str(e)}
            results.append({"symbol": sym, "result": res})
    except Exception as e:
        return {"account": acct.get("id"), "error": str(e)}
    return {"account": acct.get("id"), "closed": results}


@app.get("/equity/summary")
def equity_summary(x_api_key: Optional[str] = Header(None), authorization: Optional[str] = Header(None), days: int = 30):
    require_auth(x_api_key, authorization)
    cfg = load_config(os.getenv("CONFIG","config.yaml"))
    import sqlite3, datetime as _dt
    con = sqlite3.connect(cfg["storage"]["sqlite_path"])
    cur = con.cursor()
    cut = (_dt.datetime.utcnow() - _dt.timedelta(days=days)).isoformat()
    cur.execute("SELECT ts, account, COALESCE(pnl,0) FROM trades WHERE ts>=?", (cut,))
    rows = cur.fetchall()
    # aggregate daily by account
    from collections import defaultdict
    dmap = defaultdict(lambda: defaultdict(float))
    for ts, aid, pnl in rows:
        d = ts.split("T")[0]
        dmap[aid][d] += pnl
    out = {aid: [{"day": day, "pnl": val} for day,val in sorted(dm.items())] for aid,dm in dmap.items()}
    return {"days": days, "equity": out}


@app.get("/admin/logs")
def admin_logs(x_api_key: Optional[str] = Header(None), authorization: Optional[str] = Header(None), limit: int = 100):
    require_auth(x_api_key, authorization)
    cfg = load_config(os.getenv("CONFIG","config.yaml"))
    con = sqlite3.connect(cfg["storage"]["sqlite_path"])
    cur = con.cursor()
    cur.execute("SELECT ts, method, path, status, account FROM logs ORDER BY ts DESC LIMIT ?", (limit,))
    rows = cur.fetchall()
    return {"logs": [dict(ts=r[0],method=r[1],path=r[2],status=r[3],account=r[4]) for r in rows]}


@app.post("/portfolio/refresh")
def portfolio_refresh(x_api_key: Optional[str] = Header(None), authorization: Optional[str] = Header(None)):
    require_auth(x_api_key, authorization)
    # Clears pool so next /portfolio call re-builds connectors
    broker_pool.invalidate(None)
    return {"ok": True}


@app.get("/pnl/daily")
def pnl_daily(account: Optional[str] = None, days: int = 90, png: bool = False, base: float = None, x_api_key: Optional[str] = Header(None), authorization: Optional[str] = Header(None)):
    require_auth(x_api_key, authorization)
    cfg = load_config(os.getenv("CONFIG","config.yaml"))
    import sqlite3, datetime as _dt
    con = sqlite3.connect(cfg["storage"]["sqlite_path"])
    cur = con.cursor()
    since = (_dt.datetime.utcnow() - _dt.timedelta(days=days)).date().isoformat()
    if account:
        cur.execute("SELECT substr(ts,1,10) as day, COALESCE(SUM(pnl),0) FROM trades WHERE day>=? AND account=? GROUP BY day ORDER BY day ASC", (since, account))
    else:
        cur.execute("SELECT substr(ts,1,10) as day, COALESCE(SUM(pnl),0) FROM trades WHERE day>=? GROUP BY day ORDER BY day ASC", (since,))
    rows = cur.fetchall()
    con.close()
    days_list = [r[0] for r in rows]
    pnl_list = [float(r[1] or 0) for r in rows]
    # compute cumulative
    eq = []
    s = 0.0
    for x in pnl_list:
        s += x
        eq.append(s)
    # daily % returns using rolling equity: r_t = pnl_t / (base + equity_{t-1})
    # pick a base equity: query ?base=, or try config hints, else default 10000
    base_equity = None
    if base is not None:
        try:
            base_equity = float(base)
        except Exception:
            base_equity = None
    if base_equity is None:
        try:
            cfg2 = load_config(os.getenv("CONFIG","config.yaml"))
            # common places: cfg['risk']['starting_equity'] or cfg['capital']['base']
            base_equity = float((cfg2.get('risk') or {}).get('starting_equity') or (cfg2.get('capital') or {}).get('base') or 10000)
        except Exception:
            base_equity = 10000.0
    daily_pct = []
    rolling = base_equity
    for i, pnl in enumerate(pnl_list):
        denom = rolling if rolling not in (None, 0) else base_equity
        daily_pct.append((pnl / denom) * 100.0 if denom else 0.0)
        rolling += pnl
    out = {"account": account, "days": days_list, "daily_pnl": pnl_list, "equity_curve": eq, "daily_pct": daily_pct, "base_equity": base_equity}
    if png:
        try:
            import matplotlib.pyplot as plt, os
            from datetime import datetime, timezone
            run_id = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
            acct = account or 'all'
            outdir = f"/app/data/pnl/{acct}"
            os.makedirs(outdir, exist_ok=True)
            fp = f"{outdir}/equity_{run_id}.png"
            plt.figure()
            plt.plot(eq)
            plt.title(f'Equity ({acct})')
            plt.xlabel('Day idx')
            plt.ylabel('Cum PnL')
            plt.tight_layout()
            plt.savefig(fp)
            plt.close()
            out["equity_png"] = fp.replace("/app/data","/files")
        except Exception:
            pass
    return out


@app.get("/pnl/summary")
def pnl_summary(account: Optional[str] = None, days: int = 90, base: float = None, x_api_key: Optional[str] = Header(None), authorization: Optional[str] = Header(None)):
    require_auth(x_api_key, authorization)
    # Reuse pnl_daily logic to get daily pnl and percent series
    data = pnl_daily(account=account, days=days, png=False, base=base, x_api_key=x_api_key, authorization=authorization)
    pnl = data.get("daily_pnl") or []
    pct = data.get("daily_pct") or []
    import math, statistics as stats
    n = len(pct)
    avg = (sum(pct)/n) if n else 0.0
    med = (stats.median(pct) if n else 0.0)
    stdev = (stats.pstdev(pct) if n else 0.0)
    win = (sum(1 for x in pct if x > 0) / n * 100.0) if n else 0.0
    # cumulative % return over window (relative to base + running pnl)
    total_pnl = sum(pnl)
    base_equity = float(data.get("base_equity") or 10000.0)
    cum_pct = (total_pnl / base_equity * 100.0) if base_equity else 0.0
    # crude CAGR from daily avg (assuming 252 trading days): (1+avg/100)^(min(n,252)) -1 scaled to annual
    # If n>0, estimate mean daily return r, annualize: (1+r)^(252) -1
    r = avg/100.0
    cagr = ((1.0 + r)**252 - 1.0) if n else 0.0
    return {
        "account": account,
        "days_count": n,
        "avg_daily_pct": avg,
        "median_daily_pct": med,
        "stdev_daily_pct": stdev,
        "win_rate_pct": win,
        "cum_return_pct": cum_pct,
        "estimated_CAGR_pct": cagr*100.0,
        "base_equity": base_equity
    }


def _infer_capital(cfg: dict, account: str | None):
    # Priority: per-account risk.capital -> global risk.capital -> 10_000 default
    cap = None
    try:
        if account and isinstance(cfg.get("accounts"), list):
            for a in cfg["accounts"]:
                if a.get("id")==account:
                    cap = ((a.get("risk") or {}).get("capital"))
                    break
    except Exception:
        pass
    if cap is None:
        cap = (cfg.get("risk") or {}).get("capital")
    try:
        cap = float(cap) if cap is not None else None
    except Exception:
        cap = None
    return cap or 10000.0


@app.get("/pnl/estimate")
def pnl_estimate(account: Optional[str] = None, days: int = 60, ewma_lambda: float = 0.94, x_api_key: Optional[str] = Header(None), authorization: Optional[str] = Header(None)):
    require_auth(x_api_key, authorization)
    cfg = load_config(os.getenv("CONFIG","config.yaml"))
    import sqlite3, datetime as _dt, math
    cap = _infer_capital(cfg, account)
    con = sqlite3.connect(cfg["storage"]["sqlite_path"])
    cur = con.cursor()
    since = (_dt.datetime.utcnow() - _dt.timedelta(days=days)).date().isoformat()
    if account:
        cur.execute("SELECT substr(ts,1,10) as day, COALESCE(SUM(pnl),0.0) FROM trades WHERE day>=? AND account=? GROUP BY day ORDER BY day ASC", (since, account))
    else:
        cur.execute("SELECT substr(ts,1,10) as day, COALESCE(SUM(pnl),0.0) FROM trades WHERE day>=? GROUP BY day ORDER BY day ASC", (since,))
    rows = cur.fetchall()
    con.close()
    pct = [ (float(r[1] or 0.0) / cap) for r in rows ]
    if not pct:
        return {"account": account, "estimated_daily_pct": 0.0, "vol_daily_pct": 0.0, "ewma_lambda": ewma_lambda, "samples": 0}
    # EWMA mean & variance (RiskMetrics-style)
    lam = float(ewma_lambda)
    mu = 0.0
    var = 0.0
    w = 0.0
    for x in pct:
        w = lam*w + 1.0
        mu = lam*mu + (1-lam)*x
    # EWMA variance around the EWMA mean
    m = 0.0
    for x in pct:
        m = lam*m + (1-lam)*(x - mu)**2
    var = m
    vol = math.sqrt(max(var, 0.0))
    # Expected daily % ≈ EWMA mean; also provide 1σ band
    return {
        "account": account,
        "estimated_daily_pct": mu,
        "vol_daily_pct": vol,
        "ci68_low": mu - vol,
        "ci68_high": mu + vol,
        "samples": len(pct),
        "ewma_lambda": lam
    }
