import os, copy, yaml, threading
from intradyne_lite.live.trader import run_live

def _run_one(cfg_path, account_id):
    with open(cfg_path,'r') as f:
        base = yaml.safe_load(f)
    accounts = base.get('accounts') or []
    acc = next((a for a in accounts if a.get('id')==account_id), None)
    if not acc:
        raise RuntimeError(f'account not found: {account_id}')
    cfg = copy.deepcopy(base)
    cfg['connector'] = acc.get('type')
    cfg['connector_cfg'] = acc.get('cfg')
    # pick symbol if provided
    if 'live' not in cfg: cfg['live'] = {}
    if acc.get('default_symbol'):
        cfg['live']['symbol'] = acc['default_symbol']
    # write temp
    temp = f"/tmp/intradyne_{account_id}.yaml"
    with open(temp,'w') as f: yaml.safe_dump(cfg, f, sort_keys=False)
    run_live(temp)

def run_multi(cfg_path):
    with open(cfg_path,'r') as f:
        base = yaml.safe_load(f)
    multi = (base.get('live_multi') or {}).get('accounts') or [a.get('id') for a in (base.get('accounts') or [])]
    threads = []
    for aid in multi:
        t = threading.Thread(target=_run_one, args=(cfg_path, aid), daemon=True)
        t.start()
        threads.append(t)
    for t in threads:
        t.join()
