
import time, math, statistics
from datetime import datetime, timezone
from intradyne_lite.utils.logging import log
from intradyne_lite.strategies.ema_rsi_atr import Strategy
from intradyne_lite.utils.ohlcv import load_csv  # reuse structures
from intradyne_lite.core.engine import build, load_config
from intradyne_lite.core.storage import Storage
from intradyne_lite.core.validate import validate
from intradyne_lite.core.risk import RiskCfg
from intradyne_lite.strategies.ema_rsi_atr import atr
from collections import deque

def _build_connector(name, cfg):
    if name == "ccxt_spot":
        from intradyne_lite.connectors.ccxt_spot import CCXTSpot
        return CCXTSpot(cfg)
    if name == "alpaca":
        from intradyne_lite.connectors.alpaca import Alpaca
        return Alpaca(cfg)
    if name == "ibkr":
        from intradyne_lite.connectors.ibkr import IBKR
        return IBKR(cfg)
    raise ValueError(f"Unknown connector: {name}")

def _try_bracket(connector_name, conn, symbol, side, qty, entry, sl, tp, allow_native=True):
    # Native brackets: Alpaca supports bracket orders; CCXT/IBKR vary by venue.
    if connector_name == "alpaca" and allow_native:
        try:
            # Alpaca bracket uses separate API args; to keep Lite footprint small, emulate with market entry then rely on risk exits.
            # A full native bracket would require 'order_class="bracket"', 'take_profit', 'stop_loss' params.
            pass
        except Exception as e:
            log("Bracket native failed; falling back to risk-managed exits.", str(e))
    # Fallback: just do a market order; exits managed by strategy signals / ATR exits in this Lite build.
    return conn.place_order(symbol, side, qty, None, None, None)

def _size_qty(cfg, equity, last_atr):
    lv = cfg["live"]
    if lv.get("qty_mode","risk") == "fixed":
        return float(lv.get("fixed_qty", 0))
    # risk-based sizing by ATR distance
    risk = cfg["risk"]["max_r_per_trade"]
    atr_mult_sl = cfg["strategy"]["params"]["atr_mult_sl"]
    risk_amt = equity * risk
    stop_dist = last_atr * atr_mult_sl if last_atr and last_atr>0 else None
    if not stop_dist:
        return 0.0
    qty = risk_amt / stop_dist
    return max(0.0, qty)

def _agg_to_bars(buffer, tf_sec):
    # Buffer holds tuples (ts, price, high, low, open, close, volapprox)
    # We maintain current candle by wall-clock buckets of tf_sec
    if not buffer:
        return None
    return buffer

KILL_FILE = "/tmp/intradyne_kill"

def run_live(config_path):
    cfg = load_config(config_path)
    validate(cfg)
    storage, risk_cfg, shariah = build(cfg)
    lv = cfg["live"]
    con = cfg["connector"]
    dry = lv.get("dry_run", True)
    conn = _build_connector(con, cfg.get("connector_cfg", {}))
    symbol = lv["symbol"]
    tf = int(lv.get("timeframe_sec", 60))
    sleep_s = int(lv.get("loop_sleep_sec", 2))
    equity = float(lv.get("equity_start", 10000.0))

    # rolling arrays for building candles
    cur_bucket = None
    open_p = high_p = low_p = close_p = None
    vol = 0.0
    bars = []  # list of dicts
    max_bars = 1000

    strat = Strategy(cfg["strategy"]["params"])
    have_pos = False
    entry_price = 0.0
    qty = 0.0
    last_atr_val = None

    log("LIVE start", dict(symbol=symbol, timeframe_sec=tf, dry_run=dry, connector=con))
    try:
        while True:
    # Daily PnL ledger setup
    cur_utc_day = None

            t = int(time.time())
            # Kill-switch check
            try:
                if os.path.exists(KILL_FILE):
                    log('Kill-switch file detected; stopping live loop.')
                    break
            except Exception:
                pass

            # Daily ledger (UTC)
            utc_day = time.strftime('%Y-%m-%d', time.gmtime(t))
            if cur_utc_day is None:
                cur_utc_day = utc_day
            elif utc_day != cur_utc_day:
                try:
                    storage.log_metric(day=cur_utc_day, equity=equity, drawdown=0.0, notes='live-dry' if dry else 'live')
                except Exception as e:
                    log('Ledger write failed:', str(e))
                cur_utc_day = utc_day

            # Determine bucket start
            b = t - (t % tf)
            price = conn.get_price(symbol)
            if cur_bucket is None:
                cur_bucket = b
                open_p = high_p = low_p = close_p = price
                vol = 0.0
            if b == cur_bucket:
                # update candle
                close_p = price
                high_p = max(high_p, price)
                low_p = min(low_p, price)
            else:
                # finalize previous candle
                bars.append({
                    "timestamp": datetime.fromtimestamp(cur_bucket, tz=timezone.utc),
                    "open": open_p, "high": high_p, "low": low_p, "close": close_p, "volume": vol
                })
                if len(bars) > max_bars:
                    bars = bars[-max_bars:]
                # start new bucket
                cur_bucket = b
                open_p = high_p = low_p = close_p = price
                vol = 0.0

                # Compute indicators on the fly once we have enough bars
                import pandas as pd
                df = pd.DataFrame(bars)
                if len(df) >= max(cfg["strategy"]["params"]["slow_ema"], cfg["strategy"]["params"]["atr_len"])+2:
                    prepared = Strategy(cfg["strategy"]["params"]).prepare(df)
                    last = prepared.iloc[-1]
                    last_atr_val = float(last.atr) if not pd.isna(last.atr) else None
                    # Decide
                    action = strat.decide(last, have_pos)
                    if action:
                        # sizing
                        use_qty = _size_qty(cfg, equity, last_atr_val)
                        if use_qty <= 0:
                            log("Sizing returned 0; skipping trade")
                        else:
                            if action[0] == "buy" and not have_pos:
                                if dry:
                                    have_pos = True
                                    entry_price = float(last.close)
                                    qty = use_qty
                                    log("DRY BUY", dict(price=entry_price, qty=qty))
                                else:
                                    sl = last.close - (last_atr_val or 0)*cfg["strategy"]["params"]["atr_mult_sl"]
                                    tp = last.close + (last_atr_val or 0)*cfg["strategy"]["params"]["atr_mult_tp"]
                                    resp = _try_bracket(con, conn, symbol, "buy", use_qty, float(last.close), sl, tp, allow_native=lv.get("bracket", True))
                                    have_pos = True
                                    entry_price = float(last.close)
                                    qty = use_qty
                                    log("LIVE BUY", dict(resp=resp, price=entry_price, qty=qty))
                            elif action[0] == "sell" and have_pos:
                                if dry:
                                    pnl = (float(last.close) - entry_price) * qty
                                    equity += pnl
                                    have_pos = False
                                    log("DRY SELL", dict(price=float(last.close), qty=qty, pnl=pnl, equity=equity))
                                    qty = 0.0
                                else:
                                    resp = conn.place_order(symbol, "sell", qty, None, None, None)
                                    pnl = (float(last.close) - entry_price) * qty
                                    equity += pnl
                                    have_pos = False
                                    log("LIVE SELL", dict(resp=resp, price=float(last.close), qty=qty, pnl=pnl, equity=equity))
                                    qty = 0.0

                    # Daily loss guard (approx by comparing to starting equity in dry-run)
                    max_dd = cfg["risk"]["max_daily_loss"]
                    if equity <= (1.0 - max_dd) * float(lv.get("equity_start", 10000.0)):
                        log("Daily loss guard triggered; stopping live loop.")
                        break

            time.sleep(sleep_s)
    except KeyboardInterrupt:
        log("LIVE stopped by user")
