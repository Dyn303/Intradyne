
from datetime import datetime

def log(*args):
    ts = datetime.now().isoformat(timespec="seconds")
    print(f"[{ts}]", *args)
