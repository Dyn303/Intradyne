
import pandas as pd

REQUIRED = ["timestamp","open","high","low","close","volume"]

def load_csv(path):
    df = pd.read_csv(path)
    cols = [c.lower() for c in df.columns]
    df.columns = cols
    for c in REQUIRED:
        if c not in df.columns:
            raise ValueError(f"CSV missing column: {c}")
    # Ensure timestamp is datetime
    df["timestamp"] = pd.to_datetime(df["timestamp"], utc=True, errors="coerce")
    df = df.dropna(subset=["timestamp"]).sort_values("timestamp").reset_index(drop=True)
    return df
