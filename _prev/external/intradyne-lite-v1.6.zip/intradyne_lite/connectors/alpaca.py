
from .base import BaseConnector

try:
    from alpaca_trade_api import REST  # type: ignore
except Exception as e:
    REST = None
    _alpaca_err = e

class Alpaca(BaseConnector):
    """
    Simple Alpaca connector for stocks/ETFs.
    Uses market orders and last trade price.
    """
    def __init__(self, config):
        super().__init__(config)
        if REST is None:
            raise RuntimeError(f"alpaca-trade-api not installed: {_alpaca_err}")
        key_id = config.get("key_id")
        secret_key = config.get("secret_key")
        base_url = config.get("base_url", "https://paper-api.alpaca.markets")
        if not key_id or not secret_key:
            raise ValueError("Alpaca requires key_id and secret_key")
        self.api = REST(key_id, secret_key, base_url=base_url)

    def get_price(self, symbol: str) -> float:
        lt = self.api.get_latest_trade(symbol)
        return float(lt.price)

    def place_order(self, symbol: str, side: str, qty: float, price=None, sl=None, tp=None):
        order = self.api.submit_order(
            symbol=symbol,
            side=side,
            type="market",
            qty=str(qty),
            time_in_force="day"
        )
        return getattr(order, "_raw", str(order))

    def positions(self):
        poss = self.api.list_positions()
        return [getattr(p, "_raw", str(p)) for p in poss]


def list_orders(self, status="all", limit=50):
    try:
        orders = self.api.list_orders(status=status, limit=limit)
        return [getattr(o, "_raw", str(o)) for o in orders]
    except Exception as e:
        return {"error": str(e)}


def cancel_order(self, order_id: str):
    try:
        self.api.cancel_order(order_id)
        return {"ok": True}
    except Exception as e:
        return {"error": str(e)}

def close_position(self, symbol: str):
    try:
        resp = self.api.close_position(symbol)
        return getattr(resp, "_raw", str(resp))
    except Exception as e:
        return {"error": str(e)}


def close_all(self):
    try:
        resp = self.api.close_all_positions(cancel_orders=True)
        return {"ok": True, "count": len(resp) if hasattr(resp, "__len__") else None}
    except Exception as e:
        return {"error": str(e)}
