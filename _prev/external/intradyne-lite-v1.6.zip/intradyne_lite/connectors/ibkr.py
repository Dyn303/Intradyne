
from .base import BaseConnector

try:
    from ib_insync import IB, Stock, Crypto, MarketOrder  # type: ignore
except Exception as e:
    IB = None
    _ib_err = e

class IBKR(BaseConnector):
    """
    Minimal IBKR connector via ib_insync.
    Requires TWS or IB Gateway running with API enabled.
    Supports market orders and last traded price.
    """
    def __init__(self, config):
        super().__init__(config)
        if IB is None:
            raise RuntimeError(f"ib-insync not installed: {_ib_err}")
        self.cfg = config
        self.ib = IB()
        host = config.get("host","127.0.0.1")
        port = int(config.get("port", 7497))
        clientId = int(config.get("clientId", 777))
        self.ib.connect(host, port, clientId=clientId, readonly=False)

    def _contract(self, symbol: str):
        secType = self.cfg.get("secType", "STK")
        currency = self.cfg.get("currency", "USD")
        exchange = self.cfg.get("exchange", "SMART")
        if secType.upper() == "CRYPTO":
            return Crypto(symbol, exchange=exchange, currency=currency)
        else:
            return Stock(symbol, exchange=exchange, currency=currency)

    def get_price(self, symbol: str) -> float:
        c = self._contract(symbol)
        ticker = self.ib.reqMktData(c, "", False, False)
        self.ib.sleep(1.0)
        last = ticker.last or ticker.marketPrice()
        if last is None:
            raise RuntimeError("No market data received (check permissions or market hours)")
        return float(last)

    def place_order(self, symbol: str, side: str, qty: float, price=None, sl=None, tp=None):
        c = self._contract(symbol)
        o = MarketOrder("BUY" if side.lower()=="buy" else "SELL", qty)
        trade = self.ib.placeOrder(c, o)
        self.ib.sleep(0.5)
        return {
            "orderId": getattr(trade.order, "orderId", None),
            "status": str(getattr(trade.orderStatus, "status", "")),
            "filled": getattr(trade.orderStatus, "filled", None),
            "avgFillPrice": getattr(trade.orderStatus, "avgFillPrice", None),
        }

    def positions(self):
        poss = self.ib.positions()
        return [{
            "account": p.account,
            "symbol": p.contract.symbol,
            "position": p.position,
            "avgCost": p.avgCost
        } for p in poss]


        def cancel_order(self, order_id: str):
            try:
                # Find open order by ID
                for tr in self.ib.openTrades():
                    if getattr(tr.order, "orderId", None) == int(order_id):
                        self.ib.cancelOrder(tr.order)
                        return {"ok": True}
                return {"ok": False, "detail": "Order not found among open trades"}
            except Exception as e:
                return {"error": str(e)}

        def close_position(self, symbol: str):
            try:
                poss = self.ib.positions()
                qty = 0.0
                for p in poss:
                    if p.contract.symbol == symbol:
                        qty = float(p.position)
                        break
"
                if qty == 0.0:
                    return {"ok": False, "detail": "No position to close"}
                side = "SELL" if qty > 0 else "BUY"
                o = MarketOrder(side, abs(qty))
                c = self._contract(symbol)
                tr = self.ib.placeOrder(c, o)
"
                self.ib.sleep(0.5)
"
                return {
"
                    "orderId": getattr(tr.order, "orderId", None),
"
                    "status": str(getattr(tr.orderStatus, "status", ""))
"
                }
"
            except Exception as e:
"
                return {"error": str(e)}
"


def close_all(self):
    try:
        poss = self.ib.positions()
        actions = []
        for p in poss:
            try:
                qty = float(p.position)
                if qty == 0: 
                    continue
                side = "SELL" if qty > 0 else "BUY"
                o = MarketOrder(side, abs(qty))
                tr = self.ib.placeOrder(p.contract, o)
                actions.append({"symbol": p.contract.symbol, "qty": qty, "orderId": getattr(tr.order, "orderId", None)})
            except Exception as e:
                actions.append({"symbol": getattr(p.contract,'symbol',None), "error": str(e)})
        return {"ok": True, "actions": actions}
    except Exception as e:
        return {"error": str(e)}
