
class BaseConnector:
    def __init__(self, config):
        self.config = config
    def get_price(self, symbol):
        raise NotImplementedError
    def place_order(self, symbol, side, qty, price=None, sl=None, tp=None):
        raise NotImplementedError
    def positions(self):
        return {}
