
from .base import BaseConnector

try:
    import ccxt  # type: ignore
except Exception as e:
    ccxt = None
    _ccxt_err = e

class CCXTSpot(BaseConnector):
    """
    Minimal CCXT spot connector: market orders only and last price polling.
    Symbols use the exchange's syntax (e.g., 'BTC/USDT').
    """
    def __init__(self, config):
        super().__init__(config)
        if ccxt is None:
            raise RuntimeError(f"ccxt not installed: {_ccxt_err}")
        ex_id = config.get("exchange_id", "binance")
        klass = getattr(ccxt, ex_id, None)
        if not klass:
            raise ValueError(f"Unknown CCXT exchange id: {ex_id}")
        keys = {k: config.get(k) for k in ("apiKey","secret","password") if config.get(k)}
        self.ex = klass(keys or {})
        self.ex.options = {"defaultType": "spot"}
        self.ex.load_markets()

    def get_price(self, symbol: str) -> float:
        try:
            t = self.ex.fetch_ticker(symbol)
            last = t.get("last") or t.get("close")
            if last:
                return float(last)
        except Exception:
            pass
        ob = self.ex.fetch_order_book(symbol, limit=5)
        bid = ob["bids"][0][0] if ob["bids"] else None
        ask = ob["asks"][0][0] if ob["asks"] else None
        if bid and ask:
            return (bid + ask) / 2.0
        raise RuntimeError("Unable to fetch price")

    def place_order(self, symbol: str, side: str, qty: float, price=None, sl=None, tp=None):
        ord_type = "market" if price is None else "limit"
        params = {}
        if ord_type == "limit":
            resp = self.ex.create_order(symbol, ord_type, side, qty, price, params)
        else:
            resp = self.ex.create_order(symbol, ord_type, side, qty, None, params)
        return resp

    def positions(self):
        try:
            bal = self.ex.fetch_balance()
            return bal
        except Exception as e:
            return {"error": str(e)}


def cancel_order(self, order_id: str, symbol: str = None):
    try:
        if symbol:
            return self.ex.cancel_order(order_id, symbol)
        # try without symbol if exchange supports it
        return self.ex.cancel_order(order_id)
    except Exception as e:
        return {"error": str(e)}

def close_position(self, symbol: str):
    # Spot "position" == holding base asset; sell base free balance
    try:
        self.ex.load_markets()
        m = self.ex.market(symbol)
        base = m["base"]
        bal = self.ex.fetch_balance()
        amt = bal.get(base, {}).get("free") or 0.0
        amt = float(amt)
        if amt > 0:
            return self.ex.create_order(symbol, "market", "sell", amt)
        return {"ok": False, "detail": "No free balance to close"}
    except Exception as e:
        return {"error": str(e)}


def close_all(self):
    try:
        self.ex.load_markets()
        bal = self.ex.fetch_balance()
        quotes = ["USDT","USD","BUSD","USDC"]
        actions = []
        for asset, info in (bal or {}).items():
            try:
                free = float((info or {}).get("free") or 0)
            except Exception:
                continue
            if not free or asset in quotes:
                continue
            # try an asset/USDT market first
            sym = None
            for q in quotes:
                maybe = f"{asset}/{q}"
                if maybe in self.ex.markets:
                    sym = maybe
                    break
            if not sym:
                continue
            try:
                actions.append(self.ex.create_order(sym, "market", "sell", free))
            except Exception as e:
                actions.append({"symbol": sym, "error": str(e)})
        return {"ok": True, "actions": actions}
    except Exception as e:
        return {"error": str(e)}
