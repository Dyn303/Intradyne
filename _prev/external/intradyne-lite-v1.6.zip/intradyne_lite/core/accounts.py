from __future__ import annotations
from typing import Dict, Any, List, Optional
from intradyne_lite.core.engine import load_config

def normalize_accounts(cfg: Dict[str, Any]) -> List[Dict[str, Any]]:
    # Back-compat: if no 'accounts', synthesize one from legacy keys
    if 'accounts' in cfg and isinstance(cfg['accounts'], list) and cfg['accounts']:
        # ensure each has id/connector/connector_cfg
        out = []
        for i, a in enumerate(cfg['accounts']):
            aid = a.get('id') or f'acct{i+1}'
            out.append({**a, 'id': aid})
        return out
    # legacy single connector
    return [{
        'id': 'default',
        'connector': cfg.get('connector', 'ccxt_spot'),
        'connector_cfg': cfg.get('connector_cfg', {}),
        'live': (cfg.get('live') or {}),
    }]

def get_account(cfg: Dict[str, Any], account_id: Optional[str]) -> Dict[str, Any]:
    accts = normalize_accounts(cfg)
    if account_id:
        for a in accts:
            if a.get('id') == account_id:
                return a
    # default: first account
    return accts[0]

def list_account_ids(cfg: Dict[str, Any]) -> List[str]:
    return [a.get('id') for a in normalize_accounts(cfg)]
