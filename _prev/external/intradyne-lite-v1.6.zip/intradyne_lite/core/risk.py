
from dataclasses import dataclass

@dataclass
class RiskCfg:
    max_r_per_trade: float
    max_daily_loss: float
    max_open_positions: int
    slip_bps: float
    fees_bps: float

class RiskMgr:
    def __init__(self, cfg: RiskCfg):
        self.cfg = cfg
        self.day_start_equity = None
        self.day_loss = 0.0
        self.open_positions = 0

    def on_new_day(self, equity):
        self.day_start_equity = equity
        self.day_loss = 0.0
        self.open_positions = 0

    def allow_new_trade(self, equity):
        if self.day_start_equity is None:
            self.day_start_equity = equity
        dd = (self.day_start_equity - equity) / self.day_start_equity
        return dd < self.cfg.max_daily_loss and self.open_positions < self.cfg.max_open_positions

    def register_open(self):
        self.open_positions += 1

    def register_close(self):
        self.open_positions = max(0, self.open_positions - 1)

    def apply_costs(self, price):
        slip = price * (self.cfg.slip_bps / 10000.0)
        fee  = price * (self.cfg.fees_bps / 10000.0)
        return price + slip + fee
