
from dataclasses import dataclass
from typing import List

@dataclass
class ShariahCfg:
    enabled: bool
    banned_sectors: List[str]
    debt_ratio_max: float
    cash_interest_income_max: float

class ShariahFilter:
    def __init__(self, cfg: ShariahCfg):
        self.cfg = cfg

    def is_compliant(self, symbol_info: dict) -> bool:
        if not self.cfg.enabled:
            return True
        # Very simple heuristic placeholders
        sector = (symbol_info or {}).get("sector","").lower()
        for bad in self.cfg.banned_sectors:
            if bad in sector:
                return False
        debt_ratio = (symbol_info or {}).get("debt_ratio")
        if debt_ratio is not None and debt_ratio > self.cfg.debt_ratio_max:
            return False
        interest_income = (symbol_info or {}).get("interest_income_ratio")
        if interest_income is not None and interest_income > self.cfg.cash_interest_income_max:
            return False
        return True
