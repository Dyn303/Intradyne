
import yaml
from .storage import Storage
from .risk import RiskCfg
from .shariah import ShariahCfg, ShariahFilter

def load_config(path):
    with open(path, "r") as f:
        return yaml.safe_load(f)

def build(cfg):
    storage = Storage(cfg["storage"]["sqlite_path"])
    risk_cfg = RiskCfg(**cfg["risk"])
    sh_cfg = ShariahCfg(**cfg["shariah"])
    shariah = ShariahFilter(sh_cfg)
    return storage, risk_cfg, shariah
