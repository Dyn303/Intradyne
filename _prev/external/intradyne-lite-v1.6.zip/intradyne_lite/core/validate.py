
from dataclasses import dataclass

class ConfigError(Exception):
    pass

def require_keys(d, keys, path="root"):
    for k in keys:
        if k not in d:
            raise ConfigError(f"Missing key '{k}' in {path}")

def validate(cfg: dict):
    require_keys(cfg, ["mode","connector","strategy","risk","shariah","storage"], "config")
    if cfg["connector"] not in ("none","ccxt_spot","alpaca","ibkr"):
        raise ConfigError("connector must be one of: none, ccxt_spot, alpaca, ibkr")
    s = cfg["strategy"]["params"]
    for k in ["fast_ema","slow_ema","rsi_len","atr_len","atr_mult_sl","atr_mult_tp"]:
        if k not in s:
            raise ConfigError(f"strategy.params missing '{k}'")
    r = cfg["risk"]
    for k in ["max_r_per_trade","max_daily_loss","max_open_positions"]:
        if k not in r:
            raise ConfigError(f"risk missing '{k}'")
    if "live" in cfg:
        lv = cfg["live"]
        require_keys(lv, ["symbol","timeframe_sec","loop_sleep_sec","dry_run","qty_mode"], "live")
        if lv["qty_mode"] not in ("risk","fixed"):
            raise ConfigError("live.qty_mode must be 'risk' or 'fixed'")
