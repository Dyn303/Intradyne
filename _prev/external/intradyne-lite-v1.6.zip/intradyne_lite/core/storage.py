
import sqlite3, json, os
from contextlib import contextmanager

class Storage:
    def __init__(self, path):
        self.path = path
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        with self._conn() as con:
            con.execute('''CREATE TABLE IF NOT EXISTS trades(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ts TEXT, symbol TEXT, side TEXT, qty REAL,
                price REAL, sl REAL, tp REAL, pnl REAL, notes TEXT
            )''')
            con.execute('''CREATE TABLE IF NOT EXISTS metrics(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                day TEXT, equity REAL, drawdown REAL, notes TEXT
            )''')

    @contextmanager
    def _conn(self):
        con = sqlite3.connect(self.path)
        try:
            yield con
        finally:
            con.commit()
            con.close()

    def log_trade(self, **kw):
        with self._conn() as con:
            con.execute('''INSERT INTO trades(ts,symbol,side,qty,price,sl,tp,pnl,notes)
                           VALUES(:ts,:symbol,:side,:qty,:price,:sl,:tp,:pnl,:notes)''', kw)

    def log_metric(self, **kw):
        with self._conn() as con:
            con.execute('''INSERT INTO metrics(day,equity,drawdown,notes)
                           VALUES(:day,:equity,:drawdown,:notes)''', kw)


def log_trade_order(self, ts, symbol, side, qty, price=None, sl=None, tp=None, notes="", order_id=None, account: str | None = None):
    with self._conn() as con:
        con.execute('''INSERT INTO trades(ts,symbol,side,qty,price,sl,tp,pnl,notes,order_id)
                       VALUES(?,?,?,?,?,?,?,?,?,?,?)''',
                    (ts,symbol,side,qty,price,sl,tp,None,notes,order_id,account))

def update_trade_fill(self, order_id: str, fill_price: float, filled_qty: float, notes: str = "", account: str | None = None):
    # simplistic: update the most recent matching trade row
    with self._conn() as con:
        con.execute('''UPDATE trades SET price=?, qty=?, notes=?, account=COALESCE(?, account) WHERE order_id=? AND id=(SELECT MAX(id) FROM trades WHERE order_id=?)''',
                    (fill_price, filled_qty, notes, order_id, order_id))


def ensure_webhooks(self):
    with self._conn() as con:
        con.execute('''CREATE TABLE IF NOT EXISTS webhooks(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            event TEXT,
            url TEXT,
            secret TEXT,
            created_ts TEXT
        )''')
def register_webhook(self, event: str, url: str, secret: str = ""):
    self.ensure_webhooks()
    from datetime import datetime, timezone
    with self._conn() as con:
        con.execute('''INSERT INTO webhooks(event,url,secret,created_ts)
                       VALUES(?,?,?,?)''', (event, url, secret, datetime.now(timezone.utc).isoformat()))
def unregister_webhook(self, event: str, url: str):
    self.ensure_webhooks()
    with self._conn() as con:
        con.execute('''DELETE FROM webhooks WHERE event=? AND url=?''', (event, url))
def list_webhooks(self, event: str = None):
    self.ensure_webhooks()
    with self._conn() as con:
        if event:
            rows = con.execute('SELECT event,url,secret,created_ts FROM webhooks WHERE event=?', (event,)).fetchall()
        else:
            rows = con.execute('SELECT event,url,secret,created_ts FROM webhooks').fetchall()
    return [{"event": r[0], "url": r[1], "secret": r[2], "created_ts": r[3]} for r in rows]

        def _migrate_account(self):
            try:
                with self._conn() as con:
                    con.execute('ALTER TABLE trades ADD COLUMN account TEXT')
            except Exception:
                pass


def log_request(self, ts: str, ip: str, method: str, path: str, status: int, ms: int, account: str | None, api_key_hash: str | None):
    with self._conn() as con:
        con.execute('''INSERT INTO request_logs(ts,ip,method,path,status,ms,account,api_key_hash)
                       VALUES(?,?,?,?,?,?,?,?)''', (ts,ip,method,path,status,ms,account,api_key_hash))
