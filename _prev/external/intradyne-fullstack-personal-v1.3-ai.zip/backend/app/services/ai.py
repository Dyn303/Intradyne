
import csv, io, math
from pathlib import Path
from typing import List, Tuple

DATA_DIR = Path(__file__).resolve().parents[1] / "data" / "prices"
DATA_DIR.mkdir(parents=True, exist_ok=True)

def load_prices(symbol: str) -> List[float]:
    sym = symbol.upper()
    f = DATA_DIR / f"{sym}.csv"
    if not f.exists():
        return []
    closes = []
    with open(f, "r", encoding="utf-8") as fp:
        r = csv.DictReader(fp)
        for row in r:
            try:
                closes.append(float(row.get("close", 0)))
            except:
                continue
    return closes

def save_prices_csv(symbol: str, csv_text: str) -> int:
    sym = symbol.upper()
    f = DATA_DIR / f"{sym}.csv"
    # validate basic CSV
    reader = csv.DictReader(io.StringIO(csv_text))
    out = io.StringIO()
    w = csv.DictWriter(out, fieldnames=["date","close"])
    w.writeheader()
    count = 0
    for row in reader:
        if "close" not in row:
            continue
        try:
            c = float(row["close"])
        except:
            continue
        w.writerow({"date": row.get("date",""), "close": c})
        count += 1
    with open(f, "w", encoding="utf-8") as fp:
        fp.write(out.getvalue())
    return count

def ema(values: List[float], span: int) -> List[float]:
    if not values: return []
    k = 2 / (span + 1)
    ema_vals = [values[0]]
    for v in values[1:]:
        ema_vals.append(v * k + ema_vals[-1] * (1 - k))
    return ema_vals

def rsi(values: List[float], period: int=14) -> List[float]:
    if len(values) <= period: return [50]*len(values)
    gains = [0]; losses = [0]
    for i in range(1, len(values)):
        delta = values[i] - values[i-1]
        gains.append(max(0, delta))
        losses.append(max(0, -delta))
    def sma(arr, n, i):
        if i+1 < n: return None
        return sum(arr[i-n+1:i+1]) / n
    rsis = [50]*len(values)
    for i in range(len(values)):
        if i < period: continue
        avg_gain = sma(gains, period, i) or 0.0001
        avg_loss = sma(losses, period, i) or 0.0001
        rs = avg_gain / (avg_loss if avg_loss!=0 else 0.0001)
        rsis[i] = 100 - (100 / (1 + rs))
    return rsis

def ai_signal(symbol: str, qty: int=1) -> dict:
    closes = load_prices(symbol)
    if len(closes) < 30:
        # fallback: signal based on random tilt (demo only)
        side = "buy" if (hash(symbol) % 2 == 0) else "sell"
        return {"symbol": symbol.upper(), "side": side, "qty": qty, "reason": "fallback_random_due_to_short_history"}
    ema_fast = ema(closes, 12)
    ema_slow = ema(closes, 26)
    last_fast, last_slow = ema_fast[-1], ema_slow[-1]
    rs = rsi(closes, 14)[-1]
    if last_fast > last_slow and rs < 70:
        side = "buy"
    elif last_fast < last_slow and rs > 30:
        side = "sell"
    else:
        side = "hold"
    return {"symbol": symbol.upper(), "side": side, "qty": qty, "indicators": {"ema_fast": last_fast, "ema_slow": last_slow, "rsi": rs}}
