
from cryptography.fernet import Fernet, InvalidToken
from ..config import settings

# derive a key from settings.secret_key (must be 32 url-safe base64 bytes)
# simple deterministic derivation for personal use (NOT for production)
import base64, hashlib
_raw = hashlib.sha256(settings.secret_key.encode()).digest()
FERNET_KEY = base64.urlsafe_b64encode(_raw)
f = Fernet(FERNET_KEY)

def enc(s: str | None) -> str | None:
    if not s:
        return None
    return f.encrypt(s.encode()).decode()

def dec(s: str | None) -> str | None:
    if not s:
        return None
    try:
        return f.decrypt(s.encode()).decode()
    except InvalidToken:
        return None
