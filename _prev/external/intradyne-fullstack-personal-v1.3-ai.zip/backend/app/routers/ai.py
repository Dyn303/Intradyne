
from fastapi import APIRouter, UploadFile, File, Depends, HTTPException
from sqlalchemy.orm import Session
from ..db import get_db, Base, engine
from ..schemas import SignalIn, OrderOut
from ..models import Order
from ..services.ai import save_prices_csv, ai_signal
from ..services.broker import make_adapter
from ..services.shariah import screen_symbol
from ..services.risk import pretrade_ok
import uuid

router = APIRouter(prefix="/ai", tags=["ai"])
Base.metadata.create_all(bind=engine)

@router.post("/history/{symbol}")
async def upload_history(symbol: str, file: UploadFile = File(...)):
    text = (await file.read()).decode("utf-8")
    n = save_prices_csv(symbol, text)
    return {"symbol": symbol.upper(), "rows": n}

@router.get("/signal/{symbol}")
def get_ai_signal(symbol: str, qty: int = 1):
    sig = ai_signal(symbol, qty)
    return sig

@router.post("/autotrade/{symbol}", response_model=OrderOut)
def autotrade(symbol: str, qty: int = 1, db: Session = Depends(get_db)):
    sig = ai_signal(symbol, qty)
    if sig["side"] == "hold":
        raise HTTPException(status_code=400, detail="AI suggests HOLD")

    verdict, evidence = screen_symbol(symbol)
    if verdict != "PASS":
        raise HTTPException(status_code=400, detail=f"Shariah screen failed for {symbol}")

    ok, _ = pretrade_ok(db, {"symbol": symbol, "qty": qty})
    if not ok:
        raise HTTPException(status_code=400, detail="Risk check failed")

    order = Order(
        client_order_id=uuid.uuid4().hex[:16],
        symbol=symbol.upper(),
        side=sig["side"],
        qty=float(qty),
        state="submitted",
        broker="paper"
    )
    db.add(order); db.commit(); db.refresh(order)
    adapter = make_adapter("paper", {})
    adapter.submit(db, order); db.refresh(order)
    return {
        "id": order.id, "client_order_id": order.client_order_id, "symbol": order.symbol,
        "side": order.side, "qty": order.qty, "state": order.state, "price": order.price, "broker": order.broker
    }
