
# IntraDyne – Full‑Stack Personal Edition (No‑Code)
This package gives you a **local web app + API** you can run in minutes. Add your broker API key later from **Settings**.

## Requirements
- Docker & Docker Compose

## Quick Start
```bash
# 1) Copy env
cp backend/.env.example backend/.env
# 2) Start
docker compose up --build -d
# 3) Open UI
#   http://localhost:5173
# 4) Go to Settings and set broker (Paper by default). Add API key/secret later.
```

## What You Get
- **Backend (FastAPI)** on port 8080
  - `/settings/broker` – save broker name + API key/secret (encrypted locally)
  - `/trades/signal` – submit a paper order (with Shariah + risk checks)
  - `/portfolio/overview` – positions snapshot
- **Frontend (React/Vite)** on port 5173
  - Tabs: **Dashboard**, **Trades**, **Settings**

## Notes
- Data stored in `backend/intradyne.db` (SQLite).
- Secrets encrypted with a key derived from `SECRET_KEY` in `.env` (personal-use simple scheme).
- Paper trading fills instantly with synthetic prices. Live brokers can be wired later.


## v1.2 Upgrades
- **Kill Switch** (Admin → Settings) with backend enforcement.
- **Risk limit**: blocks orders exceeding max position % of equity (demo).
- **Reports**: export **orders.csv** from Dashboard.
- **Compliance**: upload/download **blacklist.csv**.
- **Equity curve** chart on Dashboard (demo metric).


## v1.3 Upgrades (AI)
- **AI Strategy (EMA+RSI)** with signal generation and **Auto-Trade** button (paper).
- **CSV price history upload** per symbol (columns: `date,close`). Sample data included for AAPL/MSFT/NVDA.
- New API: `/ai/history/{symbol}`, `/ai/signal/{symbol}`, `/ai/autotrade/{symbol}`.
- **AI tab in UI** to run signals without coding.
