
import React, { useEffect, useState } from 'react'
const API = import.meta.env.VITE_API_BASE || 'http://localhost:8080'
export default function KillSwitch(){
  const [state,setState]=useState('off')
  const refresh=()=>fetch(`${API}/admin/kill-switch`).then(r=>r.json()).then(j=>setState(j.kill_switch||'off'))
  useEffect(()=>{refresh()},[])
  const toggle=async()=>{
    const newState = state==='on'?'off':'on'
    await fetch(`${API}/admin/kill-switch?state=${newState}`,{method:'POST'})
    refresh()
  }
  return (<div style={{display:'flex', gap:10, alignItems:'center'}}>
    <div>Current: <b>{state.toUpperCase()}</b></div>
    <button onClick={toggle}>{state==='on'?'Turn OFF':'Turn ON'}</button>
  </div>)
}
