
import React, { useState } from 'react'
const API = import.meta.env.VITE_API_BASE || 'http://localhost:8080'

export default function Trades(){
  const [symbol, setSymbol] = useState('AAPL')
  const [side, setSide] = useState('buy')
  const [qty, setQty] = useState(1)
  const [result, setResult] = useState(null)
  const [error, setError] = useState(null)

  const send = async () => {
    setError(null); setResult(null)
    try{
      const r = await fetch(`${API}/trades/signal`, {
        method: 'POST',
        headers: {'Content-Type':'application/json'},
        body: JSON.stringify({symbol, side, qty:Number(qty)})
      })
      if(!r.ok){
        const j = await r.json()
        throw new Error(j.detail || 'Error')
      }
      const j = await r.json()
      setResult(j)
    }catch(e){
      setError(e.message)
    }
  }

  return (
    <div>
      <h3>Manual Trade (Paper)</h3>
      <div style={{display:'flex', gap:10, alignItems:'center'}}>
        <input value={symbol} onChange={e=>setSymbol(e.target.value)} placeholder="Symbol"/>
        <select value={side} onChange={e=>setSide(e.target.value)}>
          <option value="buy">Buy</option>
          <option value="sell">Sell</option>
        </select>
        <input type="number" step="1" min="1" value={qty} onChange={e=>setQty(e.target.value)} />
        <button onClick={send}>Submit</button>
      </div>
      {error && <div style={{color:'red', marginTop:10}}>Error: {error}</div>}
      {result && <pre style={{marginTop:10, background:'#f5f5f5', padding:10}}>{JSON.stringify(result,null,2)}</pre>}
    </div>
  )
}
