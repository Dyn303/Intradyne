
import React, { useState } from 'react'
const API = import.meta.env.VITE_API_BASE || 'http://localhost:8080'

export default function AIPage(){
  const [symbol, setSymbol] = useState('AAPL')
  const [qty, setQty] = useState(1)
  const [sig, setSig] = useState(null)
  const [msg, setMsg] = useState(null)
  const [file, setFile] = useState(null)

  const upload = async() => {
    if(!file) return
    const form = new FormData()
    form.append('file', file)
    const r = await fetch(`${API}/ai/history/${symbol}`, {method:'POST', body: form})
    const j = await r.json()
    setMsg(`Uploaded ${j.rows} rows for ${j.symbol}`)
    setFile(null)
  }
  const predict = async() => {
    const r = await fetch(`${API}/ai/signal/${symbol}?qty=${qty}`)
    const j = await r.json()
    setSig(j)
  }
  const autotrade = async() => {
    setMsg(null)
    const r = await fetch(`${API}/ai/autotrade/${symbol}?qty=${qty}`, {method:'POST'})
    const j = await r.json().catch(async()=>({error: (await r.json()).detail}))
    if(r.ok){ setMsg('Order placed.'); setSig(j) } else { setMsg('Error: ' + (j.detail || j.error)) }
  }

  return (<div>
    <h3>AI Strategy (EMA + RSI)</h3>
    <div style={{display:'flex', gap:10, alignItems:'center'}}>
      <input value={symbol} onChange={e=>setSymbol(e.target.value)} placeholder="Symbol"/>
      <input type="number" min="1" step="1" value={qty} onChange={e=>setQty(e.target.value)} />
      <button onClick={predict}>Generate Signal</button>
      <button onClick={autotrade}>Auto-Trade</button>
    </div>
    {msg && <div style={{marginTop:10}}>{msg}</div>}
    {sig && <pre style={{marginTop:10, background:'#f5f5f5', padding:10}}>{JSON.stringify(sig,null,2)}</pre>}

    <h4 style={{marginTop:20}}>Upload Price History (CSV)</h4>
    <div>CSV columns: <code>date, close</code></div>
    <input type="file" accept=".csv" onChange={e=>setFile(e.target.files[0])}/>
    <button onClick={upload}>Upload</button>
  </div>)
}
