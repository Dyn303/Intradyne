
# IntraDyne Lite v1.7 (Research Features)

Endpoints:
- POST /shariah/check?symbol=
- POST /sentiment/set?symbol=&score=
- GET  /sentiment/get?symbol=
- POST /strategy/toggle (JSON body with toggles)
- GET  /signals/preview?symbol=&timeframe=1h&ma_n=50
- GET  /strategy/suggest_qty?symbol=&risk_pct=0.01

Notes:
- This is a minimal skeleton to demonstrate research features. Integrate order routes and DB to enforce daily max loss and Shariah checks pre-trade.


## v1.7.4 — Live Readiness Upgrades
- **Daily PnL guard wired** to SQLite at `storage.sqlite_path` (default `/app/data/trades.sqlite`).
- **Ops endpoints**:
  - `GET /ops/ping` → sends Telegram/Email alert (env: TG_BOT_TOKEN, TG_CHAT_ID, SMTP_*).
  - `GET /ops/test_connectors?symbol=BTC/USDT` → quick connectivity+market data test.
  - `POST /ops/test_trade` → dry-run micro trade with all guards (set `dry_run=false` to attempt live integration).
- **Alerts** fire on: heartbeat ping, Shariah/sentiment blocks, daily-loss throttle.


## v1.7.5 — Live Connectors (CCXT / Alpaca / IBKR)
### Config examples (`config.yaml`)
```yaml
risk: { capital: 10000 }
storage: { sqlite_path: /app/data/trades.sqlite }
accounts:
  - id: ccxt-binance
    kind: ccxt
    exchange_id: binance
    apiKey: "YOUR_KEY"
    secret: "YOUR_SECRET"
    sandbox: true
    params: {}
  - id: alpaca-paper
    kind: alpaca
    key: "YOUR_KEY"
    secret: "YOUR_SECRET"
    base_url: "https://paper-api.alpaca.markets"
  - id: ibkr-paper
    kind: ibkr
    host: "127.0.0.1"
    port: 7497     # TWS paper
    clientId: 7
```

### New endpoints
- `GET  /orders/open?account=...&symbol=`
- `POST /orders/cancel?order_id=...&account=...&symbol=`

> Existing order routes in your app now use the real connector behind `_choose_conn()`. Bracket support is native on Alpaca; CCXT bracket is best-effort (TP limit + attempt SL). IBKR live bracket can be managed from TWS or extended via ib_insync.


## v1.7.6 — CCXT Virtual Brackets + IBKR OCA + Profiles
- **Virtual Bracket Watcher (for CCXT venues lacking native SL/TP):**
  - `POST /watcher/start` / `POST /watcher/stop`
  - `POST /watcher/register` with `{account,symbol,side,qty,tp,sl}`
  - Stores records in SQLite table `virtual_brackets` and monitors prices to close positions when TP/SL hit.
- **IBKR Brackets (OCA)** via `ib_insync`: parent order + TP (limit) + SL (stop) are linked via OCA group.
- **Profiles**: `POST /profiles/apply?name=scalper|swing|hybrid` or define `/app/profiles.yaml` to override defaults.

Example `profiles.yaml` override:
```yaml
scalper:
  atr_mult: 1.2
  risk_per_trade_pct: 0.004
hybrid:
  sentiment_gate: true
  min_sentiment: 0.1
```


## v1.7.7 — "Add All" (Analytics + Options + Mobile API + Full History)
- **Analytics**: `/analytics/summary`, `/analytics/trades?limit=`, `/analytics/equity.png?days=`
- **Options templates** (Shariah-allowed): `/options/covered_call`, `/options/protective_put` (build-only, not placing)
- **Mobile API**: `/mobile/summary`, `/mobile/trades/recent`
- **History packaged**: all external archives nested under `/_prev/external/`


## v1.7.8 — Options Placement (IBKR) + CSV Exports + Mobile OpenAPI
- **CSV exports**: `/analytics/trades.csv`, `/analytics/equity.csv`
- **IBKR Options** (placement for allowed templates):
  - `POST /options/place/covered_call` (fields: account, symbol, qty, strike, expiry 'YYYYMMDD')
  - `POST /options/place/protective_put` (fields as above)
- **Mobile OpenAPI**: `public/mobile-openapi-v1.7.8.yaml` for your mobile app team.


## v1.7.9 — Options OCA Exits + PnL Grouping + Latency + Signed URLs
- **Options exits (IBKR OCA)**: `POST /options/exits/oca` with `opt_type=CALL|PUT`, `side=long|short`, `contracts`, `strike`, `expiry`, `tp_price`, `sl_price`.
- **Trade logging**: `POST /trades/log` adds metadata (`strategy`, `profile`, `venue`).
- **PnL by group**: `GET /analytics/pnl_by?group=account|strategy|profile|venue`.
- **Latency**: auto-logged for key ops; `GET /analytics/latency?group=action|account&days=7`.
- **Mobile signed URLs**: `GET /mobile/signed_urls` → `/signed/equity.png` & `/signed/trades.csv` (requires `MOBILE_SIGNING_KEY` env).


## v1.8.0 — Deploy-Ready + Dashboards + Autostart
- **Dashboards**:
  - Profile/account summaries: `/analytics/profile/summary`, `/analytics/account/summary`
  - Equity PNGs: `/analytics/profile/equity.png`, `/analytics/account/equity.png`
- **Ops**:
  - `/healthz` endpoint, **WATCHER_AUTOSTART** and **PROFILE_DEFAULT** envs on startup.
- **Deployment tooling**:
  - `deploy/docker-compose.yml` for quick single-node runs.
  - **Helm chart** at `deploy/helm/intradyne-lite` (ConfigMap+PVC+Secret).
