# IntraDyne Lite Changelog

## v1.7.2 — 2025-09-04
- Heavy LTS repack: bundles prior Lite builds and all fullstack archives under `/_prev/`.
- Carries: v1.7.1 (base), v1.6 (Lite), fullstack v1.3–v1.9, and UX Blueprint.

## v1.7.3 — 2025-09-04
- Master bundle: added fullstack v1.3–v1.9 archives and UX blueprint under `/_prev/external/`.

## v1.7.4 — 2025-09-04
- Wired _daily_pnl to SQLite DB; added ops test & alerting (Telegram/SMTP).
