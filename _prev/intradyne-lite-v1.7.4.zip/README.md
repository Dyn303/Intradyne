
# IntraDyne Lite v1.7 (Research Features)

Endpoints:
- POST /shariah/check?symbol=
- POST /sentiment/set?symbol=&score=
- GET  /sentiment/get?symbol=
- POST /strategy/toggle (JSON body with toggles)
- GET  /signals/preview?symbol=&timeframe=1h&ma_n=50
- GET  /strategy/suggest_qty?symbol=&risk_pct=0.01

Notes:
- This is a minimal skeleton to demonstrate research features. Integrate order routes and DB to enforce daily max loss and Shariah checks pre-trade.


## v1.7.4 — Live Readiness Upgrades
- **Daily PnL guard wired** to SQLite at `storage.sqlite_path` (default `/app/data/trades.sqlite`).
- **Ops endpoints**:
  - `GET /ops/ping` → sends Telegram/Email alert (env: TG_BOT_TOKEN, TG_CHAT_ID, SMTP_*).
  - `GET /ops/test_connectors?symbol=BTC/USDT` → quick connectivity+market data test.
  - `POST /ops/test_trade` → dry-run micro trade with all guards (set `dry_run=false` to attempt live integration).
- **Alerts** fire on: heartbeat ping, Shariah/sentiment blocks, daily-loss throttle.
