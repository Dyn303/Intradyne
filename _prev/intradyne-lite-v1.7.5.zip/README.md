
# IntraDyne Lite v1.7 (Research Features)

Endpoints:
- POST /shariah/check?symbol=
- POST /sentiment/set?symbol=&score=
- GET  /sentiment/get?symbol=
- POST /strategy/toggle (JSON body with toggles)
- GET  /signals/preview?symbol=&timeframe=1h&ma_n=50
- GET  /strategy/suggest_qty?symbol=&risk_pct=0.01

Notes:
- This is a minimal skeleton to demonstrate research features. Integrate order routes and DB to enforce daily max loss and Shariah checks pre-trade.


## v1.7.4 — Live Readiness Upgrades
- **Daily PnL guard wired** to SQLite at `storage.sqlite_path` (default `/app/data/trades.sqlite`).
- **Ops endpoints**:
  - `GET /ops/ping` → sends Telegram/Email alert (env: TG_BOT_TOKEN, TG_CHAT_ID, SMTP_*).
  - `GET /ops/test_connectors?symbol=BTC/USDT` → quick connectivity+market data test.
  - `POST /ops/test_trade` → dry-run micro trade with all guards (set `dry_run=false` to attempt live integration).
- **Alerts** fire on: heartbeat ping, Shariah/sentiment blocks, daily-loss throttle.


## v1.7.5 — Live Connectors (CCXT / Alpaca / IBKR)
### Config examples (`config.yaml`)
```yaml
risk: { capital: 10000 }
storage: { sqlite_path: /app/data/trades.sqlite }
accounts:
  - id: ccxt-binance
    kind: ccxt
    exchange_id: binance
    apiKey: "YOUR_KEY"
    secret: "YOUR_SECRET"
    sandbox: true
    params: {}
  - id: alpaca-paper
    kind: alpaca
    key: "YOUR_KEY"
    secret: "YOUR_SECRET"
    base_url: "https://paper-api.alpaca.markets"
  - id: ibkr-paper
    kind: ibkr
    host: "127.0.0.1"
    port: 7497     # TWS paper
    clientId: 7
```

### New endpoints
- `GET  /orders/open?account=...&symbol=`
- `POST /orders/cancel?order_id=...&account=...&symbol=`

> Existing order routes in your app now use the real connector behind `_choose_conn()`. Bracket support is native on Alpaca; CCXT bracket is best-effort (TP limit + attempt SL). IBKR live bracket can be managed from TWS or extended via ib_insync.
