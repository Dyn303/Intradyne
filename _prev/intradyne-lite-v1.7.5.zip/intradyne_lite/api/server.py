
from __future__ import annotations
from fastapi import FastAPI, Header, HTTPException
from typing import Optional
from pydantic import BaseModel
import os, time

from intradyne_lite.core.config import load_config
from intradyne_lite.core.shariah import check_symbol
from intradyne_lite.core.technicals import atr, trend_up, trend_down
from intradyne_lite.core.sentiment import set_score as sent_set, get_score as sent_get, bias_allow_long
from intradyne_lite.core.notifier import notify

app = FastAPI(title="IntraDyne Lite v1.7")

# Globals (runtime tunables)
ENABLED_TREND_FILTER = True
ENABLED_SENTIMENT_GATE = False
MIN_SENTIMENT_SCORE = -0.2
ATR_MULTIPLIER = 2.0
RISK_PER_TRADE_PCT = 0.01
DAILY_MAX_LOSS_PCT = 0.03
TIMEFRAME_DEFAULT = "1h"
MA_N = 50

def require_auth(x_api_key: Optional[str], authorization: Optional[str]):
    if not (x_api_key or authorization):
        raise HTTPException(status_code=401, detail="Auth required")

def _infer_capital(cfg: dict, account: str | None):
    cap = (cfg.get("risk") or {}).get("capital")
    try:
        return float(cap) if cap is not None else 10000.0
    except Exception:
        return 10000.0


def _daily_pnl(cfg: dict, account: str | None) -> float:
    import sqlite3, datetime as _dt, os
    db = ((cfg.get("storage") or {}).get("sqlite_path")) or "/app/data/trades.sqlite"
    os.makedirs(os.path.dirname(db), exist_ok=True)
    con = sqlite3.connect(db)
    cur = con.cursor()
    try:
        cur.execute("CREATE TABLE IF NOT EXISTS trades (ts TEXT, account TEXT, symbol TEXT, side TEXT, qty REAL, price REAL, pnl REAL)")
        day = _dt.datetime.utcnow().date().isoformat()
        if account:
            cur.execute("SELECT COALESCE(SUM(pnl),0) FROM trades WHERE substr(ts,1,10)=? AND account=?", (day, account))
        else:
            cur.execute("SELECT COALESCE(SUM(pnl),0) FROM trades WHERE substr(ts,1,10)=?", (day,))
        val = cur.fetchone()
        return float((val or [0])[0] or 0.0)
    finally:
        con.close()



def _choose_conn(cfg: dict, account: Optional[str]):
    from intradyne_lite.core.connectors import build_conn
    return build_conn(cfg, account)


class ToggleReq(BaseModel):
    trend_filter: bool | None = None
    sentiment_gate: bool | None = None
    min_sentiment: float | None = None
    atr_mult: float | None = None
    risk_per_trade_pct: float | None = None
    daily_max_loss_pct: float | None = None
    timeframe: str | None = None
    ma_n: int | None = None

@app.post("/strategy/toggle")
def strategy_toggle(req: ToggleReq, x_api_key: Optional[str] = Header(None), authorization: Optional[str] = Header(None)):
    require_auth(x_api_key, authorization)
    global ENABLED_TREND_FILTER, ENABLED_SENTIMENT_GATE, MIN_SENTIMENT_SCORE, ATR_MULTIPLIER, RISK_PER_TRADE_PCT, DAILY_MAX_LOSS_PCT, TIMEFRAME_DEFAULT, MA_N
    if req.trend_filter is not None: ENABLED_TREND_FILTER = bool(req.trend_filter)
    if req.sentiment_gate is not None: ENABLED_SENTIMENT_GATE = bool(req.sentiment_gate)
    if req.min_sentiment is not None: MIN_SENTIMENT_SCORE = float(req.min_sentiment)
    if req.atr_mult is not None: ATR_MULTIPLIER = float(req.atr_mult)
    if req.risk_per_trade_pct is not None: RISK_PER_TRADE_PCT = float(req.risk_per_trade_pct)
    if req.daily_max_loss_pct is not None: DAILY_MAX_LOSS_PCT = float(req.daily_max_loss_pct)
    if req.timeframe is not None: TIMEFRAME_DEFAULT = str(req.timeframe)
    if req.ma_n is not None: MA_N = int(req.ma_n)
    return {"ok": True, "settings": {
        "trend_filter": ENABLED_TREND_FILTER, "sentiment_gate": ENABLED_SENTIMENT_GATE,
        "min_sentiment": MIN_SENTIMENT_SCORE, "atr_mult": ATR_MULTIPLIER,
        "risk_per_trade_pct": RISK_PER_TRADE_PCT, "daily_max_loss_pct": DAILY_MAX_LOSS_PCT,
        "timeframe": TIMEFRAME_DEFAULT, "ma_n": MA_N}}

@app.post("/sentiment/set")
def sentiment_set(symbol: str, score: float, x_api_key: Optional[str] = Header(None), authorization: Optional[str] = Header(None)):
    require_auth(x_api_key, authorization)
    sent_set(symbol, score)
    return {"symbol": symbol, "score": score}

@app.get("/sentiment/get")
def sentiment_get(symbol: str, x_api_key: Optional[str] = Header(None), authorization: Optional[str] = Header(None)):
    require_auth(x_api_key, authorization)
    return {"symbol": symbol, "score": sent_get(symbol)}

@app.post("/shariah/check")
def shariah_check(symbol: str, x_api_key: Optional[str] = Header(None), authorization: Optional[str] = Header(None)):
    require_auth(x_api_key, authorization)
    cfg = load_config(os.getenv("CONFIG","config.yaml"))
    ok, reason = check_symbol(cfg, symbol, None)
    return {"symbol": symbol, "ok": ok, "reason": reason}

@app.get("/strategy/suggest_qty")
def suggest_qty(symbol: str, account: Optional[str] = None, risk_pct: Optional[float] = None, timeframe: Optional[str] = None, ma_n: Optional[int] = None, x_api_key: Optional[str] = Header(None), authorization: Optional[str] = Header(None)):
    require_auth(x_api_key, authorization)
    cfg = load_config(os.getenv("CONFIG","config.yaml"))
    conn, _acct = _choose_conn(cfg, account)
    tf = timeframe or TIMEFRAME_DEFAULT
    candles = conn.fetch_ohlcv(symbol, tf, 200)
    a = atr(candles, 14) or None
    cap = _infer_capital(cfg, account)
    rp = (risk_pct if risk_pct is not None else RISK_PER_TRADE_PCT)
    price = candles[-1][4] if candles else conn.get_price(symbol)
    stop_dist = (a*ATR_MULTIPLIER) if a is not None else max(price*0.01, 1e-9)
    qty = (cap*rp)/max(stop_dist,1e-9)/max(price,1e-9)
    return {"symbol": symbol, "atr": a, "stop_dist": stop_dist, "price": price, "risk_capital": cap*rp, "suggest_qty": qty}

@app.get("/signals/preview")
def signals_preview(symbol: str, account: Optional[str] = None, timeframe: Optional[str] = None, ma_n: Optional[int] = None, x_api_key: Optional[str] = Header(None), authorization: Optional[str] = Header(None)):
    require_auth(x_api_key, authorization)
    cfg = load_config(os.getenv("CONFIG","config.yaml"))
    conn, _acct = _choose_conn(cfg, account)
    tf = timeframe or TIMEFRAME_DEFAULT
    m = ma_n or MA_N
    candles = conn.fetch_ohlcv(symbol, tf, 200)
    tu = trend_up(candles, m)
    td = trend_down(candles, m)
    s = sent_get(symbol)
    return {"symbol": symbol, "trend_up": tu, "trend_down": td, "sentiment": s, "candles": len(candles)}


@app.get("/ops/ping")
def ops_ping(x_api_key: Optional[str] = Header(None), authorization: Optional[str] = Header(None)):
    require_auth(x_api_key, authorization)
    res = notify("IntraDyne heartbeat OK")
    return {"ok": True, "notified": res}

@app.get("/ops/test_connectors")
def ops_test_connectors(symbol: str = "BTC/USDT", x_api_key: Optional[str] = Header(None), authorization: Optional[str] = Header(None)):
    require_auth(x_api_key, authorization)
    cfg = load_config(os.getenv("CONFIG","/app/config.yaml"))
    conn, acct = _choose_conn(cfg, None)
    try:
        candles = conn.fetch_ohlcv(symbol, "1h", 10)
        price = conn.get_price(symbol)
        ok = candles is not None and price is not None
        return {"ok": bool(ok), "symbol": symbol, "last_price": price, "candles": len(candles or [])}
    except Exception as e:
        notify(f"Connector test failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))

class TestTradeReq(BaseModel):
    symbol: str
    side: str = "buy"
    qty: float = 0.0001
    dry_run: bool = True

@app.post("/ops/test_trade")
def ops_test_trade(req: TestTradeReq, x_api_key: Optional[str] = Header(None), authorization: Optional[str] = Header(None)):
    require_auth(x_api_key, authorization)
    cfg = load_config(os.getenv("CONFIG","/app/config.yaml"))
    conn, acct = _choose_conn(cfg, None)
    # guards
    ok_, reason_ = check_symbol(cfg, req.symbol, None)
    if not ok_:
        notify(f"Trade blocked (Shariah): {req.symbol} {reason_}")
        raise HTTPException(status_code=400, detail=f"Shariah screen failed: {reason_}")
    if ENABLED_SENTIMENT_GATE and req.side.lower()=="buy" and not bias_allow_long(req.symbol, MIN_SENTIMENT_SCORE):
        notify(f"Trade blocked (Sentiment): {req.symbol}")
        raise HTTPException(status_code=400, detail="Sentiment gate blocks long")
    # risk sizing (simulate)
    price = conn.get_price(req.symbol)
    pnl_preview = 0.0
    if req.dry_run:
        return {"simulated": True, "symbol": req.symbol, "side": req.side, "qty": req.qty, "price": price}
    # real path would: conn.place_order(...); here we simulate and log pnl=0
    return {"placed": True, "symbol": req.symbol, "side": req.side, "qty": req.qty, "price": price}


@app.get("/orders/open")
def orders_open(account: Optional[str] = None, symbol: Optional[str] = None, x_api_key: Optional[str] = Header(None), authorization: Optional[str] = Header(None)):
    require_auth(x_api_key, authorization)
    cfg = load_config(os.getenv("CONFIG","/app/config.yaml"))
    conn, acct = _choose_conn(cfg, account)
    try:
        return {"ok": True, "orders": conn.list_open_orders(symbol)}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/orders/cancel")
def orders_cancel(order_id: str, account: Optional[str] = None, symbol: Optional[str] = None, x_api_key: Optional[str] = Header(None), authorization: Optional[str] = Header(None)):
    require_auth(x_api_key, authorization)
    cfg = load_config(os.getenv("CONFIG","/app/config.yaml"))
    conn, acct = _choose_conn(cfg, account)
    try:
        r = conn.cancel_order(order_id, symbol)
        return {"ok": True, "resp": r}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
